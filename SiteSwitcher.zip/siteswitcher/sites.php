<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Public JSON list of switchable sites, read by the mobile app.
 *
 * Returns only the host names of sites that are not locked. Disabled by
 * default: turn on "Publish site list for the mobile app" in the plugin settings.
 *
 * @package    local_siteswitcher
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('NO_MOODLE_COOKIES', true);
define('NO_DEBUG_DISPLAY', true);

require_once(__DIR__ . '/../../config.php');

if (!get_config('local_siteswitcher', 'enabled') || !get_config('local_siteswitcher', 'appendpoint')) {
    http_response_code(404);
    exit;
}

$hosts = [];
foreach (\local_siteswitcher\helper::get_sites() as $site) {
    if ($site['locked'] && !$site['current']) {
        continue; // Users cannot switch to locked sites, so the app does not need them.
    }
    $parts = parse_url($site['url']);
    if (empty($parts['scheme']) || strtolower($parts['scheme']) !== 'https' || empty($parts['host'])) {
        continue; // The app only renders https sites.
    }
    $hosts[strtolower($parts['host'])] = true;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=300');
header('X-Content-Type-Options: nosniff');
echo json_encode(['version' => 1, 'hosts' => array_keys($hosts)]);
