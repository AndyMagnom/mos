<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_siteswitcher;

/**
 * Helper functions.
 *
 * @package    local_siteswitcher
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class helper {
    /**
     * Decode the stored JSON into a list of sites.
     *
     * @param mixed $json Stored setting value.
     * @return array List of sites: title, url, current, locked, icon (manual), autoicon (detected).
     */
    public static function decode_sites($json): array {
        if (!is_string($json) || $json === '') {
            return [];
        }
        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return [];
        }
        $sites = [];
        foreach ($decoded as $item) {
            if (!is_array($item)) {
                continue;
            }
            $title = trim((string) ($item['title'] ?? ''));
            $url = trim((string) ($item['url'] ?? ''));
            if ($title === '' || $url === '') {
                continue;
            }
            $sites[] = [
                'title' => $title,
                'url' => $url,
                'current' => !empty($item['current']),
                'locked' => !empty($item['locked']),
                'icon' => trim((string) ($item['icon'] ?? '')),
                'autoicon' => trim((string) ($item['autoicon'] ?? '')),
            ];
        }
        return $sites;
    }

    /**
     * Get the configured sites.
     *
     * @return array List of sites.
     */
    public static function get_sites(): array {
        return self::decode_sites(get_config('local_siteswitcher', 'sites'));
    }

    /**
     * Find a site's favicon by reading the icon link in its page.
     *
     * Runs when the admin saves the site list, never when a visitor loads a page.
     * Uses Moodle's curl class, so Moodle's blocked hosts and ports rules apply.
     *
     * @param string $url Site URL.
     * @return string Absolute icon URL, or empty string if the site could not be read.
     */
    public static function discover_favicon(string $url): string {
        global $CFG;
        require_once($CFG->libdir . '/filelib.php');

        $curl = new \curl();
        $html = $curl->get($url, [], ['CURLOPT_TIMEOUT' => 6, 'CURLOPT_CONNECTTIMEOUT' => 4]);
        $info = $curl->get_info();
        if ($curl->get_errno() || !is_string($html) || $html === '' || (int) ($info['http_code'] ?? 0) >= 400) {
            return '';
        }
        $base = !empty($info['url']) ? $info['url'] : $url;

        $found = '';
        $previous = libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        if ($dom->loadHTML($html)) {
            foreach ($dom->getElementsByTagName('link') as $link) {
                $rels = preg_split('/\s+/', strtolower(trim($link->getAttribute('rel'))));
                $href = trim($link->getAttribute('href'));
                // Matches "icon" and "shortcut icon", but not "apple-touch-icon".
                if ($href !== '' && in_array('icon', $rels, true)) {
                    $found = self::resolve_url($base, $href);
                    break;
                }
            }
        }
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        if ($found === '') {
            // Page has no icon link: try the default location.
            $found = self::resolve_url($base, '/favicon.ico');
        }
        if (!preg_match('#^https?://#i', $found) || strlen($found) > 1000) {
            return '';
        }
        return $found;
    }

    /**
     * Turn a possibly relative link into an absolute URL.
     *
     * @param string $base Absolute URL of the page holding the link.
     * @param string $href Link value.
     * @return string Absolute URL, or empty string on failure.
     */
    public static function resolve_url(string $base, string $href): string {
        $b = parse_url($base);
        if (empty($b['scheme']) || empty($b['host']) || $href === '') {
            return '';
        }
        $origin = $b['scheme'] . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
        if (strpos($href, '//') === 0) {
            return $b['scheme'] . ':' . $href;
        }
        $h = parse_url($href);
        if ($h === false) {
            return '';
        }
        if (!empty($h['scheme'])) {
            return $href;
        }
        if ($href[0] === '/') {
            return $origin . $href;
        }
        $path = $b['path'] ?? '/';
        $dir = substr($path, 0, strrpos($path, '/') + 1);
        return $origin . $dir . $href;
    }
}
