<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_siteswitcher;

/**
 * Admin setting: editable list of sites, stored as JSON.
 *
 * @package    local_siteswitcher
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class admin_setting_sitelist extends \admin_setting {
    /**
     * Constructor.
     *
     * @param string $name Unique setting name (plugin/name).
     * @param string $visiblename Localised label.
     * @param string $description Localised description.
     * @param string $defaultsetting Default JSON.
     */
    public function __construct(string $name, string $visiblename, string $description, string $defaultsetting = '[]') {
        parent::__construct($name, $visiblename, $description, $defaultsetting);
    }

    /**
     * Return the current stored value.
     *
     * @return mixed
     */
    public function get_setting() {
        return $this->config_read($this->name);
    }

    /**
     * Convert submitted form data into rows.
     *
     * @param mixed $data Submitted array of parallel lists: title, url, icon, current, locked.
     * @return array List of [title, url, icon, current, locked].
     */
    protected function rows_from_input($data): array {
        if (!is_array($data) || !isset($data['title']) || !is_array($data['title'])) {
            return [];
        }
        $get = function (string $key) use ($data): array {
            return isset($data[$key]) && is_array($data[$key]) ? array_values($data[$key]) : [];
        };
        $urls = $get('url');
        $icons = $get('icon');
        $currents = $get('current');
        $lockeds = $get('locked');

        $rows = [];
        foreach (array_values($data['title']) as $i => $title) {
            $rows[] = [
                (string) $title,
                (string) ($urls[$i] ?? ''),
                (string) ($icons[$i] ?? ''),
                (string) ($currents[$i] ?? '0') === '1',
                (string) ($lockeds[$i] ?? '0') === '1',
            ];
        }
        return $rows;
    }

    /**
     * Validate and save the submitted list.
     *
     * @param mixed $data Submitted data.
     * @return string Empty string on success, error message otherwise.
     */
    public function write_setting($data) {
        // Detected icons from the previous save, reused if a site cannot be read now.
        $previousicons = [];
        foreach (helper::decode_sites($this->get_setting()) as $old) {
            $previousicons[$old['url']] = $old['autoicon'];
        }

        $clean = [];
        $hascurrent = false;
        foreach ($this->rows_from_input($data) as [$title, $url, $icon, $current, $locked]) {
            $title = trim(clean_param($title, PARAM_TEXT));
            $url = trim($url);
            $icon = trim($icon);
            if ($title === '' && $url === '' && $icon === '') {
                continue; // Ignore blank rows.
            }
            if ($title === '') {
                return get_string('error_notitle', 'local_siteswitcher');
            }
            $cleanurl = clean_param($url, PARAM_URL);
            if ($cleanurl === '' || !preg_match('#^https?://#i', $cleanurl)) {
                return get_string('error_badurl', 'local_siteswitcher', s($url));
            }
            $cleanicon = '';
            if ($icon !== '') {
                $cleanicon = clean_param($icon, PARAM_URL);
                if ($cleanicon === '' || !preg_match('#^https?://#i', $cleanicon)) {
                    return get_string('error_badicon', 'local_siteswitcher', s($icon));
                }
            }
            $autoicon = '';
            if ($cleanicon === '') {
                $autoicon = helper::discover_favicon($cleanurl);
                if ($autoicon === '' && isset($previousicons[$cleanurl])) {
                    $autoicon = $previousicons[$cleanurl];
                }
            }
            // Only one site can be the current one: the first marked wins.
            $iscurrent = $current && !$hascurrent;
            $hascurrent = $hascurrent || $iscurrent;
            $clean[] = [
                'title' => $title,
                'url' => $cleanurl,
                'current' => $iscurrent,
                'locked' => $locked,
                'icon' => $cleanicon,
                'autoicon' => $autoicon,
            ];
        }
        $saved = $this->config_write($this->name, json_encode($clean));
        return $saved ? '' : get_string('errorsetting', 'admin');
    }

    /**
     * Render the setting.
     *
     * @param mixed $data Current value (JSON string, or submitted array after a validation error).
     * @param string $query Admin search query.
     * @return string HTML.
     */
    public function output_html($data, $query = '') {
        global $OUTPUT;

        $rows = [];
        if (is_array($data)) {
            // Re-display what the admin submitted after a validation error.
            foreach ($this->rows_from_input($data) as [$title, $url, $icon, $current, $locked]) {
                $rows[] = [
                    'title' => $title,
                    'url' => $url,
                    'icon' => $icon,
                    'current' => $current,
                    'locked' => $locked,
                    'haspreview' => false,
                    'preview' => '',
                ];
            }
        } else {
            foreach (helper::decode_sites($data) as $site) {
                $preview = $site['icon'] !== '' ? $site['icon'] : $site['autoicon'];
                $rows[] = [
                    'title' => $site['title'],
                    'url' => $site['url'],
                    'icon' => $site['icon'],
                    'current' => $site['current'],
                    'locked' => $site['locked'],
                    'haspreview' => $preview !== '',
                    'preview' => $preview,
                ];
            }
        }

        $context = [
            'id' => $this->get_id(),
            'name' => $this->get_full_name(),
            'rows' => $rows,
        ];
        $element = $OUTPUT->render_from_template('local_siteswitcher/admin_sitelist', $context);

        return format_admin_setting($this, $this->visiblename, $element, $this->description, false, '', null, $query);
    }
}
