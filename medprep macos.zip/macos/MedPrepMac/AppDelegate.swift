import AppKit

@main @MainActor final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuItemValidation {
    private var controller: NSWindowController?
    func applicationDidFinishLaunching(_ notification: Notification) {
        CrashDiagnostics.shared.start(); SecurityNotices.shared.start()
        NSApp.setActivationPolicy(.regular)
        let menu = NSMenu()
        let appItem = NSMenuItem(); menu.addItem(appItem)
        let appMenu = NSMenu(); appItem.submenu = appMenu
        appMenu.addItem(withTitle: "About MedPrep", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(withTitle: "Enable Security Notifications", action: #selector(enableSecurityNotifications), keyEquivalent: "").target = self
        #if DEBUG
        let testingItem = NSMenuItem(title: "SECURITY TESTING — Debug only", action: nil, keyEquivalent: "")
        let testingMenu = NSMenu(title: "Security testing")
        testingItem.submenu = testingMenu; appMenu.addItem(testingItem)
        let explanation = NSMenuItem(title: "ON = protected. OFF = disabled. Restart after changes.", action: nil, keyEquivalent: "")
        explanation.isEnabled = false; testingMenu.addItem(explanation)
        for protection in AppConfig.MacSecurity.Protection.allCases {
            let item = NSMenuItem(title: protection.rawValue, action: #selector(toggleSecurityProtection(_:)), keyEquivalent: "")
            item.representedObject = protection.rawValue; item.target = self
            item.toolTip = "Click to switch ON / OFF. Quit and reopen the app to apply. Release always enables this protection."
            testingMenu.addItem(item)
        }
        testingMenu.addItem(.separator())
        testingMenu.addItem(withTitle: "RESTORE AppConfig DEFAULTS (restart)", action: #selector(restoreSecurityDefaults), keyEquivalent: "").target = self
        testingMenu.addItem(withTitle: "ENABLE ALL PROTECTIONS (restart)", action: #selector(enableAllSecurity), keyEquivalent: "").target = self
        testingMenu.addItem(withTitle: "DISABLE ALL LISTED PROTECTIONS (restart)", action: #selector(disableAllSecurity), keyEquivalent: "").target = self
        #endif
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Quit MedPrep", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        NSApp.mainMenu = menu
        let window = ProtectedWindow(contentRect: NSRect(x: 0, y: 0, width: 1120, height: 800),
            styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.retainProtection(.course)
        window.title = "MedPrep"
        #if DEBUG
        let disabled = AppConfig.MacSecurity.Protection.allCases.filter { !AppConfig.MacSecurity.enabled($0) }.count
        window.title += disabled == 0 ? " — DEBUG: all protections ON" : " — SECURITY TESTING: \(disabled) protections OFF"
        #endif
        window.minSize = NSSize(width: 720, height: 540)
        window.appearance = NSAppearance(named: .darkAqua)
        window.isRestorable = !AppConfig.MacSecurity.enabled(.stateRestoration); window.isReleasedWhenClosed = false
        window.contentViewController = BrowserController()
        controller = NSWindowController(window: window)
        window.center(); controller?.showWindow(nil); NSApp.activate(ignoringOtherApps: true)
        DispatchQueue.main.async { [weak self] in
            guard let window = self?.controller?.window, let notice = CrashDiagnostics.shared.takeNotice() else { return }
            let alert = NSAlert(); alert.messageText = "Previous MedPrep Session"; alert.informativeText = notice
            alert.addButton(withTitle: "OK"); alert.window.sharingType = AppConfig.MacSecurity.enabled(.windowCapture) ? .none : .readOnly
            alert.beginSheetModal(for: window, completionHandler: nil)
        }
    }
    @objc private func enableSecurityNotifications() { SecurityNotices.shared.enable() }
    #if DEBUG
    @objc private func toggleSecurityProtection(_ sender: NSMenuItem) {
        guard let raw = sender.representedObject as? String,
              let protection = AppConfig.MacSecurity.Protection(rawValue: raw) else { return }
        AppConfig.MacSecurity.save(!AppConfig.MacSecurity.saved(protection), for: protection)
    }
    @objc private func restoreSecurityDefaults() { AppConfig.MacSecurity.restoreDefaults() }
    @objc private func enableAllSecurity() {
        for protection in AppConfig.MacSecurity.Protection.allCases { AppConfig.MacSecurity.save(true, for: protection) }
    }
    @objc private func disableAllSecurity() {
        for protection in AppConfig.MacSecurity.Protection.allCases { AppConfig.MacSecurity.save(false, for: protection) }
    }
    #endif
    func validateMenuItem(_ item: NSMenuItem) -> Bool {
        #if DEBUG
        if let raw = item.representedObject as? String, let protection = AppConfig.MacSecurity.Protection(rawValue: raw) {
            let enabled = AppConfig.MacSecurity.saved(protection)
            item.state = enabled ? .on : .off
            item.title = (enabled ? "ON — " : "OFF — ") + protection.rawValue
        }
        #endif
        return true
    }
    func applicationWillTerminate(_ notification: Notification) { CrashDiagnostics.shared.finish() }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

// Reasons are per window and balanced independently. Never infer protection by
// reading sharingType: it is only a deterrent, and its getter can be stale.
@MainActor final class ProtectedWindow: NSWindow {
    enum Reason: Hashable { case course, media, dialog }
    private var reasons: [Reason: Int] = [:]
    func retainProtection(_ reason: Reason) { reasons[reason, default: 0] += 1; reapplyProtection() }
    func releaseProtection(_ reason: Reason) {
        if let count = reasons[reason], count > 1 { reasons[reason] = count - 1 }
        else { reasons.removeValue(forKey: reason) }
        reapplyProtection()
    }
    func reapplyProtection() { sharingType = reasons.isEmpty || !AppConfig.MacSecurity.enabled(.windowCapture) ? .readOnly : .none }
    override func becomeKey() { reapplyProtection(); super.becomeKey() }
}
