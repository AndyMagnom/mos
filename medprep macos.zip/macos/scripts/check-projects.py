#!/usr/bin/env python3
"""Portable source/project checks. These are not a Swift compiler or device test."""
import ast
import json
import pathlib
import plistlib
import re
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[2]
TOKEN = re.compile(r'\s+|//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|[{}()=;,]|[^\s{}()=;,]+', re.S)

def project(path):
    tokens = [m.group() for m in TOKEN.finditer(path.read_text())
              if not (m.group().isspace() or m.group().startswith(('//', '/*')))]
    offset = 0
    def value():
        nonlocal offset
        token = tokens[offset]; offset += 1
        if token == '{':
            result = {}
            while tokens[offset] != '}':
                key = value(); assert tokens[offset] == '='; offset += 1
                result[key] = value(); assert tokens[offset] == ';'; offset += 1
            offset += 1
            return result
        if token == '(':
            result = []
            while tokens[offset] != ')':
                result.append(value())
                if tokens[offset] == ',': offset += 1
            offset += 1
            return result
        return json.loads(token) if token.startswith('"') else token
    result = value()
    assert offset == len(tokens)
    return result

def mac_source(path, debug):
    # Evaluate only the conditional directives used by these task-owned files.
    result = []; stack = []; active = True
    for line in path.read_text().splitlines():
        text = line.strip()
        if text.startswith('#if '):
            conditions = {'os(macOS)': True, '!os(macOS)': False, 'DEBUG': debug}
            condition = conditions[text[4:]]
            stack.append((active, condition)); active = active and condition
        elif text == '#else':
            parent, condition = stack[-1]; active = parent and not condition
        elif text == '#endif':
            active, _ = stack.pop()
        elif active: result.append(line)
    assert not stack
    return '\n'.join(result)

for platform, name in [('ios', 'MedPrep'), ('macos', 'MedPrepMac')]:
    base = ROOT / platform
    parsed = project(base / f'{name}.xcodeproj/project.pbxproj')
    objects = parsed['objects']; assert parsed['rootObject'] in objects
    for identity, obj in objects.items():
        for field in ['fileRef', 'mainGroup', 'productReference', 'containerPortal', 'target', 'targetProxy', 'buildConfigurationList', 'baseConfigurationReference']:
            if field in obj: assert obj[field] in objects, (platform, identity, field)
        for field in ['children', 'files', 'buildPhases', 'targets', 'buildConfigurations', 'dependencies']:
            for ref in obj.get(field, []): assert ref in objects, (platform, identity, field, ref)
        if obj['isa'] == 'PBXFileReference' and obj.get('lastKnownFileType') == 'sourcecode.swift':
            if obj.get('sourceTree') == 'DERIVED_FILE_DIR':
                assert platform == 'macos' and obj['path'] == 'R7.swift'
                assert any('$(DERIVED_FILE_DIR)/R7.swift' in phase.get('outputPaths', []) for phase in objects.values())
            else:
                assert (base / obj['path']).is_file(), obj['path']
    for p in (base / name).rglob('*'):
        if p.suffix in ['.plist', '.entitlements', '.xcprivacy']: plistlib.loads(p.read_bytes())
    scheme = ET.parse(base / f'{name}.xcodeproj/xcshareddata/xcschemes/{name}.xcscheme')
    if platform == 'macos':
        assert scheme.getroot().find('TestAction').get('buildConfiguration') == 'Testing'
        assert scheme.getroot().find('ArchiveAction').get('buildConfiguration') == 'Release'
        for obj in objects.values():
            if obj['isa'] == 'XCBuildConfiguration':
                assert 'APP_ATTEST_ENVIRONMENT' not in obj['buildSettings']
                if obj['buildSettings'].get('PRODUCT_BUNDLE_IDENTIFIER') == 'com.med.prep.mac':
                    expected = {'Testing': 'NO', 'Debug': '$(MEDPREP_DEBUG_HARDENED_RUNTIME)', 'Release': 'YES'}[obj['name']]
                    assert obj['buildSettings']['ENABLE_HARDENED_RUNTIME'] == expected
                if obj['name'] == 'Release':
                    assert 'DEBUG' not in obj['buildSettings'].get('SWIFT_ACTIVE_COMPILATION_CONDITIONS', '')
    print(platform + ': project references, plists and scheme checked')

for debug in [True, False]:
    active = mac_source(ROOT / 'shared/DeviceIdentity.swift', debug)
    assert 'DCAppAttestService' not in active and 'import DeviceCheck' not in active
    assert 'mac_device_challenge' in active and 'verifyDeviceKey' in active
    gate = mac_source(ROOT / 'macos/MedPrepMac/SecurityGate.swift', debug)
    delegate = mac_source(ROOT / 'macos/MedPrepMac/AppDelegate.swift', debug)
    if not debug:
        assert 'toggleVirtualMachines' not in gate and 'toggleVirtualDisplay' not in delegate
        assert 'return true' in gate.split('static var detectVirtualMachines: Bool {')[1].split('}')[0]
print('Mac SDK-27 API exclusions and Release VM switch exclusions checked')
mac = plistlib.loads((ROOT / 'macos/MedPrepMac/Info.plist').read_bytes())
ios = plistlib.loads((ROOT / 'ios/MedPrep/Info.plist').read_bytes())
assert mac['NSAppTransportSecurity']['NSPinnedDomains'] == ios['NSAppTransportSecurity']['NSPinnedDomains']
assert mac['MedPrepDisplayPolicy'] == 'builtin' and mac['MedPrepVMDetectionRequired'] is True
assert 'AppAttestEnvironment' not in mac
entitlements = plistlib.loads((ROOT / 'macos/MedPrepMac/MedPrepMac.entitlements').read_bytes())
assert 'com.apple.developer.devicecheck.appattest-environment' not in entitlements
ast.parse((ROOT / 'macos/scripts/verify-release.py').read_text())
debug_info = plistlib.loads((ROOT / 'macos/MedPrepMac/Info-Debug.plist').read_bytes())
assert 'NSPinnedDomains' not in debug_info['NSAppTransportSecurity']
assert debug_info['MedPrepDebugPinnedDomains'] == mac['NSAppTransportSecurity']['NSPinnedDomains']
config = mac_source(ROOT / 'shared/AppConfig.swift', False)
assert 'return launched' not in config and 'UserDefaults.standard.set(enabled' not in config
assert 'return true' in config.split('static func enabled(_ protection: Protection) -> Bool {')[1].split('}')[0]
release_delegate = mac_source(ROOT / 'macos/MedPrepMac/AppDelegate.swift', False)
assert 'toggleSecurityProtection' not in release_delegate and 'disableAllSecurity' not in release_delegate and 'restoreSecurityDefaults' not in release_delegate
parsed = project(ROOT / 'macos/MedPrepMac.xcodeproj/project.pbxproj')
for obj in parsed['objects'].values():
    settings = obj.get('buildSettings', {})
    if 'INFOPLIST_FILE' in settings:
        assert settings['INFOPLIST_FILE'] == ('MedPrepMac/Info.plist' if obj['name'] == 'Release' else 'MedPrepMac/Info-Debug.plist')
print('Debug testing controls excluded from Release; Debug pins and build configuration checked')
print('Pins, built-in-only policy and release audit syntax checked; native build/device tests still required')

config_text = (ROOT / 'shared/AppConfig.swift').read_text()
protections = re.findall(r'case (\w+) = "', config_text.split('enum Protection: String, CaseIterable {')[1].split('        }')[0])
assert len(protections) == 31 and len(set(protections)) == len(protections)
source_text = '\n'.join(p.read_text() for p in (ROOT / 'macos/MedPrepMac').glob('*.swift')) + (ROOT / 'shared/DeviceIdentity.swift').read_text() + (ROOT / 'shared/PinnedTrust.swift').read_text()
for protection in protections:
    assert '.' + protection + ': true' in config_text, protection
    assert re.search(r'(?:enabled|on)\(\.' + protection + r'\)', source_text + config_text.split('enum Network {')[1]), protection
xcconfig = (ROOT / 'macos/DebugSecurity.xcconfig').read_text()
for setting in ['MEDPREP_ENCODE_SECURITY_STRINGS', 'MEDPREP_DEBUG_HARDENED_RUNTIME', 'MEDPREP_DEBUG_STRIP_SYMBOLS']:
    assert re.search(r'^' + setting + r' = YES$', xcconfig, re.M)
assert 'MEDPREP_DEBUG_INJECT_DEBUG_ENTITLEMENTS = NO' in xcconfig
assert 'MEDPREP_DEBUG_APP_ENTITLEMENTS = MedPrepMac/MedPrepMac.entitlements' in xcconfig
assert 'environment["CONFIGURATION"] != "Release" && environment["MEDPREP_ENCODE_SECURITY_STRINGS"] == "NO"' in (ROOT / 'macos/scripts/generate-security-strings.swift').read_text()
print('All 31 Debug options have secure defaults and runtime consumers; build options checked')
