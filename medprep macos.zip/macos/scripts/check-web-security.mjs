// Execute the actual injected script with minimal DOM doubles; no native WebKit claim.
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import assert from 'node:assert/strict';
const file = new URL('../MedPrepMac/BrowserController.swift', import.meta.url);
const swift = readFileSync(file, 'utf8').split('private static var restrictions: String {')[1];
const template = swift.match(/return """\n([\s\S]*?)\n    """/)[1];
const names = ['textSelection', 'clipboard', 'contextMenus', 'dragAndDrop', 'printingSharing', 'autofill', 'nativeMedia'];
let checks = 0;
function scenario(options) {
    const listeners = new Map(); const state = { css: 0, pauses: 0, messages: [] };
    const field = { spellcheck: true, setAttribute(name, value) { this[name] = value; } };
    const media = { autoplay: true, pause() { state.pauses++; }, setAttribute() {} };
    function HTMLMediaElement() {}
    const originalPlay = function () { return Promise.resolve('normal playback'); };
    HTMLMediaElement.prototype.play = originalPlay;
    const navigator = { share: () => 'shared', clipboard: { write: () => 'copied', writeText: () => 'copied' } };
    const window = { print: () => 'printed', webkit: { messageHandlers: { protectedMedia: { postMessage(message) { state.messages.push(message); } } } } };
    const document = {
        documentElement: { appendChild(element) { element.isConnected = true; state.css++; } },
        createElement() { return { isConnected: false }; },
        querySelectorAll(selector) { return selector === 'input,textarea' ? [field] : [media]; },
        addEventListener(name, callback) { listeners.set(name, [...(listeners.get(name) ?? []), callback]); },
    };
    const source = template.replace(/\\\(on\(\.(\w+)\)\)/g, (_, name) => String(options[name]));
    assert(!source.includes('\\(on('));
    runInNewContext(source, { document, window, navigator, HTMLMediaElement, MutationObserver: class { observe() {} } });
    const event = (name, selector) => {
        let prevented = false;
        const item = { currentSrc: 'https://test.medpreparation.com/file', src: 'https://test.medpreparation.com/file' };
        const value = { target: { closest(value) { return value === selector ? item : null; } },
            preventDefault() { prevented = true; }, stopImmediatePropagation() {} };
        for (const callback of listeners.get(name) ?? []) callback(value);
        return prevented;
    };
    return { state, field, media, navigator, window, HTMLMediaElement, originalPlay, event };
}
const allOn = Object.fromEntries(names.map(name => [name, true]));
const allOff = Object.fromEntries(names.map(name => [name, false]));
const protectedPage = scenario(allOn);
assert.equal(protectedPage.state.css, 1); checks++;
for (const event of ['copy', 'cut', 'contextmenu', 'dragstart']) { assert.equal(protectedPage.event(event), true); checks++; }
assert.equal(protectedPage.window.print(), undefined); checks++;
assert.equal(protectedPage.field.autocomplete, 'off'); checks++;
assert.equal(protectedPage.media.autoplay, false); checks++;
assert.equal(protectedPage.event('click', 'img'), true); checks++;
await assert.rejects(protectedPage.HTMLMediaElement.prototype.play()); checks++;
const unprotectedPage = scenario(allOff);
assert.equal(unprotectedPage.state.css, 0); checks++;
for (const event of ['copy', 'cut', 'contextmenu', 'dragstart']) { assert.equal(unprotectedPage.event(event), false); checks++; }
assert.equal(unprotectedPage.window.print(), 'printed'); checks++;
assert.equal(unprotectedPage.navigator.clipboard.writeText(), 'copied'); checks++;
assert.equal(unprotectedPage.navigator.share(), 'shared'); checks++;
assert.equal(unprotectedPage.field.spellcheck, true); checks++;
assert.equal(unprotectedPage.state.pauses, 0); checks++;
assert.equal(unprotectedPage.HTMLMediaElement.prototype.play, unprotectedPage.originalPlay); checks++;
assert.equal(unprotectedPage.event('click', 'img'), false); checks++;
for (const name of names) {
    const page = scenario({ ...allOn, [name]: false });
    if (name === 'textSelection') assert.equal(page.state.css, 0);
    if (name === 'clipboard') assert.equal(page.event('copy'), false);
    if (name === 'contextMenus') assert.equal(page.event('contextmenu'), false);
    if (name === 'dragAndDrop') assert.equal(page.event('dragstart'), false);
    if (name === 'printingSharing') assert.equal(page.window.print(), 'printed');
    if (name === 'autofill') assert.equal(page.field.spellcheck, true);
    if (name === 'nativeMedia') assert.equal(page.HTMLMediaElement.prototype.play, page.originalPlay);
    checks++;
}
console.log(`${checks} injected web-security checks passed (DOM doubles; native WebKit still untested).`);
