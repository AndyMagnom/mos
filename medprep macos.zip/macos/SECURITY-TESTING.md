# Security testing — macOS Debug and Moodle

All protections default to **ON**. **ON protects; OFF disables the named check.**
Use a disposable staging Moodle site. These controls are for testing, not claims
that capture or modification can be prevented on every device.

## 1. Mac: click the switches

Build and launch **Debug**, then open **MedPrep → SECURITY TESTING — Debug only**.
Every row explicitly says **ON** or **OFF**. Click a row to change it. Use
**ENABLE ALL PROTECTIONS** or **DISABLE ALL LISTED PROTECTIONS** for bulk changes.
**Quit and reopen MedPrep after changes.** Preferences are frozen at startup so a
page/media request cannot change security policy halfway through a transition.
The Debug window title shows how many protections are OFF. Release has no testing
menu and always enables these protections, regardless of saved Debug preferences.

To test a VM: turn **Block virtual machines / emulators OFF** and
**Block external displays and mirroring OFF**, then restart.

Source defaults are grouped in `../shared/AppConfig.swift`, under
`AppConfig.MacSecurity.debugDefaults`: **true = ON; false = OFF**. Menu preferences
override source defaults. Use RESTORE AppConfig DEFAULTS to use edited source defaults; ENABLE ALL explicitly turns every protection ON.

| Debug switch | What OFF does |
| --- | --- |
| Block virtual machines / emulators | Permit detected VMs/emulators. |
| Block external displays and mirroring | Permit external, multiple and mirrored displays, including a VM display. |
| Block recognized recording applications | Permit recognized recording-capable applications to remain running. |
| Block attached debuggers | Skip the attached-debugger check. OS signing entitlements may still prevent attachment. |
| Block injected-library environment variables | Skip DYLD injection-environment checks. |
| Block Frida and known hook libraries | Skip the known instrumentation-library scan. |
| Verify application signature and signing team | Skip expected-signing-team / running-signature validation. |
| Require safe entitlements and Hardened Runtime | Skip safe-entitlement / Hardened Runtime validation, not the actual OS enforcement. |
| Verify executable and bundle resources | Skip periodic executable / signed-resource validation. |
| Verify current / backup server public-key pins | Skip the app SPKI pins. Valid HTTPS CA, hostname and expiry remain required. |
| Hide content and stop playback when inactive | Leave content and playback available when the app loses focus. Sleep still cancels active operations. |
| Exclude windows from older capture methods | Use capturable windows instead of the older sharingType deterrent. |
| Exclude native media pixels from capture | Allow submitted native media pixels to be captured. |
| Block content text selection | Allow web text selection; copying requires the copying switch OFF too. |
| Block copying / cutting and clear clipboard | Allow web copy/cut/clipboard writes and stop clearing the system clipboard. |
| Block right-click menus | Allow normal WebKit right-click menus. |
| Block dragging content out | Remove the web drag-start blocker. |
| Block web printing, sharing and downloads | Remove app web print/share/download blockers. OS sandbox, WebKit download handling and server restrictions may still apply; this does not add export UI. |
| Disable keyboard autocomplete and spellcheck | Stop overriding form autocomplete, autocorrect and spellcheck. |
| Route media through the protected native viewer | Allow normal inline WebKit media; stop intercepting image/PDF/media links. |
| Show visible account / device watermark | Hide the visible account/device watermark. |
| Embed experimental hidden image marker | Stop adding the experimental low-bit image marker. |
| Send security-event reports to Moodle | Do not send the app security-event reports. |
| Block Web Inspector | Allow Web Inspector on macOS 13.3+. |
| Keep web content and network caches off disk | Use persistent WK storage and permit normal network caches. Server Cache-Control: no-store is still respected; logout/security cleanup remains active. |
| Block website camera / microphone access | Let WebKit request camera/microphone permission. OS entitlements and user approval remain required. |
| Block media AirPlay / external playback | Allow the normal external-playback flags; the native sample-buffer pipeline does not automatically gain an AirPlay output. |
| Keep content out of window state restoration | Allow normal window restoration eligibility; this does not add serialization of sensitive content. |
| Refresh policy and device proof automatically | Stop automatic policy polling, proof renewal and client freshness timers. Server bearer expiration/revocation is still enforced. |
| Persist device key / UUID in device-only Keychain | Use per-origin signing keys and a UUID in memory only. Restarting creates a new testing identity. Existing Keychain identity is not deleted. |
| Collect Hardware UUID metadata | Omit Hardware UUID metadata; device identity still uses its signing key. |

## 2. Mac: build-time security options

Open **macos/DebugSecurity.xcconfig** in Xcode. Each option has a plain-English
comment and enabled default. Rebuild after editing:

| Option | Default | Disable / test value |
| --- | --- | --- |
| Selected-string encoding | `MEDPREP_ENCODE_SECURITY_STRINGS = YES` | `NO` generates plaintext constants for Debug/Testing only. Release always encrypts. |
| OS Hardened Runtime | `MEDPREP_DEBUG_HARDENED_RUNTIME = YES` | `NO`; also turn OFF its runtime validation. |
| Executable / Swift symbol stripping | `MEDPREP_DEBUG_STRIP_SYMBOLS = YES` | `NO`. |
| Debug-entitlement injection | `MEDPREP_DEBUG_INJECT_DEBUG_ENTITLEMENTS = NO` | `YES` permits Xcode's debug entitlements; turn OFF debugger / entitlement checks, then enable Debug executable in Edit Scheme → Run. |
| OS App Sandbox | `MEDPREP_DEBUG_APP_ENTITLEMENTS = MedPrepMac/MedPrepMac.entitlements` | `MedPrepMac/MedPrepMac-Unrestricted-Debug.entitlements` removes the sandbox for Debug. |

An in-app switch cannot remove OS-enforced sandboxing, library validation or
signing capabilities. Use these build options for those tests. Never export Debug
or Testing. Testing intentionally permits XCTest injection; Release does not use
this xcconfig and keeps its existing signing, sandbox and hardening settings.

## 3. Moodle: server testing switches

Install **LockGuard_v3_11_3_apple.zip** and complete Moodle's browser upgrade.
Go to **Site administration → Lock Guard → Settings**. Enable **Native macOS app**
first. In **SECURITY TESTING — macOS server controls**:

1. Check **ENABLE ONE-HOUR MAC SECURITY TESTING**, then save.
2. Uncheck a **PROTECTION** row to turn that protection OFF, then save.
3. Quit/reopen the Debug app to obtain a bearer under the new policy.

Every protection checkbox defaults to checked/ON. Unchecked/OFF only has an effect
within the active one-hour window. The page shows ACTIVE or INACTIVE status.
To start another hour, save testing OFF, then save it ON. Turning testing OFF,
changing any override, or reaching the deadline invalidates testing bearers and
outstanding challenges. Normal protections resume automatically at expiry.

| Server protection | What OFF does during the active window |
| --- | --- |
| Minimum app build | Accept any positive app build. |
| Mac device-key signature | Permit unsigned test claims in an isolated testing identity namespace. Does not authenticate a production device identity. |
| Device registration, device/browser limits and device blocks | Bypass the existing device-rule population check for native Mac bearers. These related rules are controlled together; account ownership and suspension/deletion remain enforced. |
| Verification challenge rate | Remove the 120/IP/minute limit for Mac challenges. |
| Two-minute challenge expiry | Extend challenge lifetime to the testing window; nonce consumption remains single-use. |
| Five-minute bearer expiry | Extend bearer lifetime to the testing window. Turn automatic refresh OFF in the Debug app to exercise this. |
| Capture-report bearer revocation | Log events without revoking this native bearer. Other score/ban settings are independent. |

The testing section links to existing **Enable plugin**, **Restrict sign-in to the
app**, **Security score** and **Automatic banning** settings. Those existing
settings are site-wide and do not expire: restore them separately after tests.
The new Mac overrides do not change iOS/Android/Windows policies. Disabling Mac
signature verification deliberately removes device authenticity in staging;
Moodle login, account ownership, HTTPS, strict input validation and single-use
nonces remain mandatory. No request header/body can enable these overrides.

## 4. Verification and limits

Portable project checks verify all 31 defaults/consumers, Release exclusion of
runtime overrides, Debug/Release pin plists, and build configuration. Backend
tests (206 checks) cover defaults, expiry, policy changes, unsigned-key isolation, normal
signature restoration, unchanged iOS policy, ownership/suspension and locks.
The actual injected web script also passes 29 DOM-double checks for all-ON, all-OFF and individual controls. Native XCTest sources include default/frozen-preference tests. No Xcode compiler,
Mac UI, real Moodle database or physical capture test has run in this Linux
workspace. Run those checks on your Mac/staging server before distributing.
