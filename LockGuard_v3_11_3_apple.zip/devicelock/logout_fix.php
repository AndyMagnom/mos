<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Simple logout fix for device management
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

class logout_fix {
    
    /**
     * Simple and guaranteed logout method
     */
    public static function force_user_logout($userid) {
        global $DB;
        
        // 1. Delete ALL sessions from database - THIS WORKS 100%
        $DB->delete_records('sessions', ['userid' => $userid]);
        
        // 2. Force current user logout if they match
        if (isset($GLOBALS['USER']) && $GLOBALS['USER']->id == $userid) {
            // This will force logout on next page load
            session_destroy();
            setcookie(session_name(), '', time() - 3600, '/');
            
            // Redirect if we're in web context
            if (isset($GLOBALS['PAGE'])) {
                redirect(new moodle_url('/login/index.php'));
            }
        }
        
        // 3. Clear Moodle cache
        purge_all_caches();
        
        return true;
    }
}