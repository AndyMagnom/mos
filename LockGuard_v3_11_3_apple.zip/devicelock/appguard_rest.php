<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * App Guard REST endpoint - receives device security events from the
 * custom app (Windows, Android, Mac, ...) and writes them into the
 * plugin's own Security & Error Logs (same table/UI as every other
 * Lock Guard event).
 *
 * POST /auth/devicelock/appguard_rest.php
 * JSON body: {
 *   "type": "screenshot_attempt" | "screen_recording_detected" |
 *           "dev_options_detected" | "usb_debugging_detected" |
 *           "wireless_debugging_detected" | "emulator_detected" |
 *           "audio_capture_detected" | "mic_guard_unavailable" |
 *           "mic_contended",
 *   "details": "...", "device": "...", "app_version": "...", "ts": 1234567890
 * }
 *
 * Authentication (either one):
 *   1. A valid Moodle session (the app is a WebView and the user is
 *      logged in) - the event is attributed to that user.
 *   2. An X-App-Key (or X-AppGuard-Key) header matching ANY key in the
 *      "App keys" setting - used when no session exists yet (e.g. the
 *      app blocked an emulator before login). The event is stored
 *      without user attribution.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

header('Content-Type: application/json; charset=utf-8');

function auth_devicelock_appguard_respond(int $code, array $body): void {
    http_response_code($code);
    echo json_encode($body);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    auth_devicelock_appguard_respond(405, ['ok' => false, 'error' => 'POST only']);
}

if (!auth_devicelock_appguard_enabled() && !get_config('auth_devicelock', 'enabled')) {
    auth_devicelock_appguard_respond(403, ['ok' => false, 'error' => 'App Guard is disabled on this site']);
}

$input = file_get_contents('php://input', false, null, 0, 65537);
if (strlen($input) > 65536) {
    auth_devicelock_appguard_respond(413, ['ok' => false, 'error' => 'Request too large']);
}
$body = json_decode($input ?: '', true);
if (!is_array($body)) {
    auth_devicelock_appguard_respond(400, ['ok' => false, 'error' => 'Invalid JSON body']);
}

$allowedtypes = [
    'screenshot_attempt',
    'screen_recording_detected',
    'dev_options_detected',
    'usb_debugging_detected',
    'wireless_debugging_detected',
    'emulator_detected',
    'audio_capture_detected',
    'mic_guard_unavailable',
    'mic_contended',
    // Windows app (MedPrep) event types
    'vm_detected',
    'debugger_detected',
    'dev_mode_detected',
    'test_signing_detected',
    'remote_session_detected',
    'virtual_display_detected',
    'capture_tool_detected',
    'external_display_detected',
    'device_integrity_failed',
    'recorder_suspected',
];
$type = clean_param($body['type'] ?? '', PARAM_ALPHANUMEXT);
if (!in_array($type, $allowedtypes, true)) {
    auth_devicelock_appguard_respond(400, ['ok' => false, 'error' => 'Unknown event type']);
}

// --- Authentication ---------------------------------------------------------

$offender = null;
require_once(__DIR__ . '/classes/local/ios_identity.php');
$iossession = \auth_devicelock\local\ios_identity::session();
if (\auth_devicelock\local\ios_identity::is_request() && !$iossession) {
    auth_devicelock_appguard_respond(401, ['ok' => false, 'error' => 'Verified Apple device required']);
}
if ($iossession && !empty($iossession['userid'])) {
    // The bearer was bound to this account by Moodle, never by client JSON.
    $offender = $DB->get_record('user', ['id' => $iossession['userid']]);
} else if (isloggedin() && !isguestuser()) {
    $offender = $USER;
} else if (!$iossession) {
    // v3.4.5: any of the configured App keys is accepted (one per line in
    // the "App keys" setting), so each app build can carry its own key.
    // The key can arrive as an X-App-Key or X-AppGuard-Key header, or in
    // the JSON body as "app_key" for clients that cannot set headers.
    $provided = (string)($_SERVER['HTTP_X_APP_KEY'] ?? '');
    if ($provided === '') {
        $provided = (string)($_SERVER['HTTP_X_APPGUARD_KEY'] ?? '');
    }
    if ($provided === '') {
        $provided = (string)($body['app_key'] ?? '');
    }
    if (!auth_devicelock_appguard_key_valid($provided)) {
        auth_devicelock_appguard_respond(401, ['ok' => false, 'error' => 'Not authenticated']);
    }
}

// Invalidate the authenticated capture bearer before telemetry throttling/logging.
// A stopped-recording event does not revoke a healthy replacement session.
$sessionrevoked = $iossession && \auth_devicelock\local\ios_identity::revoke_for_capture(
    $type, $body['capture_active'] ?? null);

// --- Rate limiting (per session, per minute) --------------------------------

$limit = (int)(get_config('auth_devicelock', 'appguard_ratelimit') ?: 60);
$now = time();
if (!isset($SESSION->auth_devicelock_appguard_window) || $SESSION->auth_devicelock_appguard_window < $now - 60) {
    $SESSION->auth_devicelock_appguard_window = $now;
    $SESSION->auth_devicelock_appguard_count = 0;
}
if ($SESSION->auth_devicelock_appguard_count >= $limit) {
    auth_devicelock_appguard_respond(429, ['ok' => false, 'error' => 'Rate limit exceeded']);
}
$SESSION->auth_devicelock_appguard_count++;

// --- Store the event into the plugin's own Security & Error Logs -----------

$other = [
    'details'     => clean_param((string)($body['details'] ?? ''), PARAM_TEXT),
    'device'      => clean_param((string)($body['device'] ?? ''), PARAM_TEXT),
    'app_version' => clean_param((string)($body['app_version'] ?? ''), PARAM_TEXT),
    'native_session_revoked' => (bool)$sessionrevoked,
    'source'      => $iossession ? (($iossession['platform'] ?? 'ios') === 'macos' ?
        (!empty($iossession['testingPolicy']) ? 'macos_testing' : 'native_device_key') : 'apple_attest') : ($offender ? 'session' : 'appkey'),
];

$fingerprint = $iossession ? $iossession['fingerprint'] : 'system';
if ($offender) {
    try {
        $fp = auth_devicelock_get_current_fingerprint();
        if (!empty($fp)) {
            $fingerprint = $fp;
        }
    } catch (\Throwable $t) {
        /* keep 'system' */
    }
}

device_manager::log_action($offender ? (int)$offender->id : 0, $fingerprint, $type, $other);

// --- Notify site administrators ----------------------------------------------

if (get_config('auth_devicelock', 'appguard_notifyadmins')) {
    $throttleseconds = 60 * (int)(get_config('auth_devicelock', 'appguard_notifythrottle') ?: 0);

    if ($offender) {
        $lastnotified = (int)get_user_preferences('auth_devicelock_appguard_lastnotify', 0, $offender);
    } else {
        $lastnotified = (int)get_config('auth_devicelock', 'appguard_anon_lastnotify');
    }

    if ($now - $lastnotified >= $throttleseconds) {
        if ($offender) {
            set_user_preference('auth_devicelock_appguard_lastnotify', $now, $offender);
        } else {
            set_config('appguard_anon_lastnotify', $now, 'auth_devicelock');
        }
        auth_devicelock_appguard_notify_admins($offender, $type, $other);
    }
}

auth_devicelock_appguard_respond(200, ['ok' => true, 'logged' => true, 'native_session_revoked' => (bool)$sessionrevoked]);
