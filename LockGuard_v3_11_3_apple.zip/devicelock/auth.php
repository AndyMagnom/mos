<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Authentication plugin for Lock Guard - COMPLETE FIX
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/authlib.php');
require_once(__DIR__ . '/device_manager.php');
require_once(__DIR__ . '/lib.php');
require_once(__DIR__ . '/classes/local/ios_identity.php');
require_once(__DIR__ . '/locallib.php');

/**
 * Lock Guard authentication plugin - COMPLETE FIX
 */
class auth_plugin_devicelock extends auth_plugin_base {

    /**
     * Constructor
     */
    public function __construct() {
        $this->authtype = 'devicelock';
        $this->config = get_config('auth_devicelock');
        
        // Ensure devicelock is in Moodle's enabled auth plugins list
        if (!empty($this->config->enabled)) {
            auth_devicelock_ensure_enabled();
        }
    }

    /**
     * Returns true if the username and password work
     * Handles users from any auth method, case-insensitivity, and email logins
     */
    public function user_login($username, $password) {
        global $CFG, $DB, $SESSION;
        
        // Ensure devicelock is registered in Moodle's enabled auth plugins list
        auth_devicelock_ensure_enabled();
        
        $cleanusername = trim($username);
        $lowerusername = core_text::strtolower($cleanusername);
        
        // 1. Fetch user securely (case-insensitive username, email login, active user)
        $user = $DB->get_record_select('user', "LOWER(username) = ? AND mnethostid = ? AND deleted = 0", [$lowerusername, $CFG->mnet_localhost_id]);
        if (!$user && !empty($CFG->authloginviaemail)) {
            $user = $DB->get_record_select('user', "LOWER(email) = ? AND mnethostid = ? AND deleted = 0", [$lowerusername, $CFG->mnet_localhost_id]);
        }
        if (!$user) {
            $user = $DB->get_record_select('user', "LOWER(username) = ? AND deleted = 0", [$lowerusername]);
        }
        if (!$user) {
            return false; // User not found
        }
        
        // 2. Validate internal password hashes safely
        // This is exactly how Moodle's core manual plugin operates.
        if (!validate_internal_user_password($user, $password)) {
            return false; // Password mismatch
        }

        // CRITICAL FIX: Unconfirmed users must verify their email first via standard self-registration
        // Devicelock must NEVER authenticate or register an unconfirmed account.
        if (empty($user->confirmed)) {
            return false;
        }
        
        // Safety fallback: if database tables do not exist yet (e.g. during installation), allow login
        if (!auth_devicelock_tables_exist()) {
            return true;
        }

        
        // If plugin disabled, allow
        if (empty($this->config->enabled)) {
            return true;
        }
        
        // Check if user should be restricted
        if (!$this->should_restrict_user($user)) {
            return true;
        }

        // ================================================
        // APP GUARD: block the sign-in itself for restricted users not
        // coming from the app. This runs BEFORE any device/browser-limit
        // logic below, so a blocked browser sign-in never consumes a
        // device or browser slot - it is simply refused, exactly like a
        // wrong password would be.
        // ================================================
        if (auth_devicelock_appguard_enabled() && !auth_devicelock_appguard_is_app_request()) {
            if (method_exists('device_manager', 'log_action')) {
                device_manager::log_action($user->id, 'system', 'web_browser_sign_in_blocked', [
                    'details' => 'Sign-in from outside the app - credential check refused.',
                    'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
                    'ip' => getremoteaddr(),
                ]);
            }
            auth_devicelock_appguard_set_notice_cookie();
            $blockedmsg = trim((string)get_config('auth_devicelock', 'appguard_blockedmessage'));
            $SESSION->loginerrormsg = $blockedmsg !== '' ? $blockedmsg
                : 'This account can only sign in through the official app. Please use the app to sign in.';
            return false;
        }

        // ================================================
        // NEW: Auto-migrate user if setting is enabled (strictly confirmed
        // users only, and only once they actually hold the student role -
        // not just because their email got confirmed)
        // ================================================
        if (!empty($this->config->automigrate) && $user->auth !== 'devicelock' && !empty($user->confirmed)
                && self::user_has_student_role_static($user->id)) {
            $this->migrate_user_to_devicelock($user->id);
        }
        // BUG FIX: this method uses $fingerprint throughout (passed to every
        // log_action() call below) but never actually assigned it - it was
        // silently NULL, and inserting NULL into the NOT NULL
        // device_fingerprint column is exactly what threw "Error writing to
        // database" every time a blocked login tried to log itself.
        $fingerprint = $this->generate_fingerprint();
        $legacy_fingerprint = $this->generate_legacy_fingerprint();
        
        // ================================================
        // CRITICAL FIX: Check if this device has been blocked
        // This prevents blocked devices from logging in
        // ================================================
        
        // Find matching device allowing multi-browser tokens (login event)
        $device = $this->find_device_for_user($user->id, true);
        
        // If device was recognized on this machine, but browser limit was exceeded, block immediately
        if ($device && !empty($device->browser_limit_exceeded)) {

            return false;
        }

        // If device exists but is not active, block login
        if ($device && $device->status !== 'active') {
            $SESSION->loginerrormsg = get_string('deviceblockedmessage', 'auth_devicelock');
            
            // Log the blocked login attempt
            if (method_exists('device_manager', 'log_action')) {
                device_manager::log_action($user->id, $fingerprint, 'blocked_device_login_attempt', [
                    'timestamp' => time(),
                    'ip' => getremoteaddr(),
                    'device_status' => $device->status
                ]);
            }
            
            return false;
        }
        
        // Check if user or device has a blocking flag
        if (method_exists('device_manager', 'check_device_logout_flag')) {
            // If user account is globally blocked by admin flag
            if (device_manager::check_device_logout_flag($user->id, 'blocked_all')) {
                $SESSION->auth_devicelock_device_blocked = true;
                $SESSION->loginerrormsg = get_string('deviceblockedmessage', 'auth_devicelock');
                return false;
            }

            // If device is active, clean up any stale session logout flags on disk and ensure not blocked
            if ($device && $device->status === 'active') {
                device_manager::check_device_logout_flag($user->id, $fingerprint);
                unset($SESSION->auth_devicelock_device_blocked);
                unset($SESSION->auth_devicelock_blocked_fingerprint);
            } else if (!$device) {
                // If device is not registered yet, consume any old leftover flag for this browser fingerprint
                device_manager::check_device_logout_flag($user->id, $fingerprint);
            }
        }
        
        // Check if device is allowed (exists and is active)
        if ($device && $device->status === 'active') {
            // BUG FIX: an already-registered device used to keep working
            // forever regardless of the limit being lowered afterwards -
            // e.g. limit set to 2, both devices register, admin lowers it
            // to 1, and both devices could still log in indefinitely,
            // because this branch never re-checked the limit at all, only
            // the "register a brand-new device" branch below did.
            //
            // Re-rank this user's active devices by registration order
            // (oldest first) and only the first $maxdevices of them stay
            // valid - deterministic and stable even if the user alternates
            // between devices, unlike ranking by last-used time.
            $maxdevices = auth_devicelock_get_user_device_limit($user->id);
            $activedevices = $DB->get_records_select(
                'auth_devicelock_devices',
                'userid = :rankuserid AND status = :rankstatus',
                ['rankuserid' => $user->id, 'rankstatus' => 'active'],
                'id ASC',
                'id'
            );
            $devicerank = 0;
            $rankcounter = 0;
            foreach ($activedevices as $activedevice) {
                $rankcounter++;
                if ((int)$activedevice->id === (int)$device->id) {
                    $devicerank = $rankcounter;
                    break;
                }
            }
            if ($maxdevices <= 0 || ($devicerank > 0 && $devicerank > $maxdevices)) {
                $SESSION->loginerrormsg = get_string('devicenotallowed', 'auth_devicelock');
                if (method_exists('device_manager', 'log_action')) {
                    device_manager::log_action($user->id, $fingerprint, 'login_blocked_limit', [
                        'reason' => 'limit_lowered_below_existing_device',
                        'device_id' => $device->id,
                        'device_rank' => $devicerank,
                        'max' => $maxdevices,
                        'timestamp' => time(),
                        'ip' => getremoteaddr()
                    ]);
                }
                return false;
            }

            // Verify browser limit on this authorized device
            $current_ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
            if (function_exists('auth_devicelock_can_use_browser_on_device') && !auth_devicelock_can_use_browser_on_device($device, $current_ua)) {
                $maxb = auth_devicelock_get_user_browser_limit($user->id);
                $SESSION->loginerrormsg = get_string('browserlimitreached', 'auth_devicelock', $maxb);
                if (method_exists('device_manager', 'log_action')) {
                    device_manager::log_action($user->id, $fingerprint, 'browser_limit_reached', [
                        'device_id' => $device->id,
                        'max_browsers' => $maxb,
                        'timestamp' => time(),
                        'ip' => getremoteaddr()
                    ]);
                }
                return false;
            }

            // Check if this is after a reset
            if (device_manager::has_reset_notification($user->id)) {
                // Set EXACT message for user about reset
                $SESSION->auth_devicelock_reset_message = "Device resets have been performed on this account.";
                device_manager::clear_reset_notification($user->id);
            }
            return true;
        }
        
        // Device not registered - check if we can register it.
        // Feature 3: use per-user override if set, else fall back to global limit.
        $maxdevices = auth_devicelock_get_user_device_limit($user->id);
        $currentcount = device_manager::get_active_device_count($user->id);
        
        // ALWAYS ALLOW FIRST DEVICE - unless the admin has set the limit to
        // 0, which deliberately means no device should ever be allowed.
        if ($currentcount == 0 && $maxdevices > 0) {
            // Store EXACT message for first device registration to be rendered post-login
            $SESSION->auth_devicelock_first_device_message = "Your device has been registered. You log in from the same device and browser each time, and you cannot change the device. If any problems arise, contact the administrator.";
            return true;
        }
        
        // Check device limit
        if ($currentcount >= $maxdevices) {
            $SESSION->loginerrormsg = get_string('devicenotallowed', 'auth_devicelock');
            // Log the blocked attempt
            if (method_exists('device_manager', 'log_action')) {
                device_manager::log_action($user->id, $fingerprint, 'login_blocked_limit', [
                    'current' => $currentcount,
                    'max' => $maxdevices,
                    'timestamp' => time(),
                    'ip' => getremoteaddr()
                ]);
            }
            return false;
        }
        
        // Check auto-register
        if (!empty($this->config->autoregister)) {
            $SESSION->auth_devicelock_second_device_message = "You have been logged in from a second device and it has been registered. Contact support if there are any problems.";
            return true;
        }
        
        // Block login
        $SESSION->loginerrormsg = get_string('devicenotallowed', 'auth_devicelock');
        return false;
    }

    /**
     * Pre user_login hook - surfaces the ban message + reason on the login
     * screen.
     *
     * This is called by authenticate_user_login() right after the user
     * object has been built and BEFORE Moodle's own suspended-account
     * rejection. That ordering matters: banning a user also suspends the
     * account, and Moodle returns AUTH_LOGIN_SUSPENDED before any auth
     * plugin's user_login()/user_authenticated_hook() can run - so the ban
     * check in user_authenticated_hook() below was dead code for banned
     * users and all they ever saw was the generic
     * "Invalid login, please try again".
     *
     * Setting $SESSION->loginerrormsg here mirrors how Moodle core surfaces
     * the account-lockout message: login/index.php picks it up and renders
     * it in the login form error box instead of the generic message.
     *
     * @param stdClass $user The complete user record about to be verified.
     */
    public function pre_user_login_hook(&$user) {
        global $SESSION;

        if (empty($user) || empty($user->id)) {
            return;
        }

        $ban = $this->check_user_ban($user);
        if (!$ban) {
            return;
        }

        // Only reveal the ban message (and its reason) when the submitted
        // password is actually correct. This mirrors the post-password ban
        // check in user_authenticated_hook() below and stops arbitrary
        // username probing from discovering who is banned and why.
        $submitted = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : null;
        if ($submitted === null || !validate_internal_user_password($user, $submitted)) {
            return;
        }

        if (!empty($SESSION)) {
            $SESSION->loginerrormsg = $ban->message;
        }
    }

    /**
     * After authentication - Track session for device
     * MODIFIED: Handles users from any auth method
     */
    public function user_authenticated_hook(&$user, $username, $password) {
        global $SESSION, $DB;
        
        if (empty($DB) || !auth_devicelock_tables_exist()) {
            return;
        }

        // ================================================
        // NEW: Ban check. Runs even when the plugin is
        // disabled - a ban is a security action and must
        // persist regardless of the device-lock feature
        // being on or off.
        // NOTE: because banning also suspends the account,
        // this hook is normally NOT reached (Moodle rejects
        // suspended users inside authenticate_user_login()
        // before the auth hooks run - see pre_user_login_hook
        // above for where the ban message is actually shown).
        // It stays as a safety net for bans whose account was
        // later un-suspended in the DB without lifting the
        // ban: the login is aborted here and the ban message
        // + reason is still shown on the login page.
        // ================================================
        $ban = $this->check_user_ban($user);
        if ($ban) {
            require_logout();
            // After require_logout(), $SESSION points at the fresh
            // new session; login/index.php picks up loginerrormsg and
            // renders it in the login form error box (see also
            // pre_loginpage_hook()).
            $SESSION->loginerrormsg = $ban->message;
            // Abort the login itself: marking the in-memory user as
            // suspended makes authenticate_user_login() bail out with
            // AUTH_LOGIN_SUSPENDED right after this hook returns, so
            // login/index.php can never reach complete_user_login() and
            // re-admit a banned user whose DB record is not suspended.
            $user->suspended = 1;
            return;
        }

        
        if (empty($this->config->enabled)) {
            return;
        }
        
        if (empty($user->confirmed)) {
            return;
        }

        // Never register device or auto-migrate during signup or email confirmation
        $req_uri = $_SERVER['REQUEST_URI'] ?? '';
        if (strpos($req_uri, 'confirm.php') !== false || strpos($req_uri, 'signup.php') !== false) {
            return;
        }
        
        if (!$this->should_restrict_user($user)) {
            return;
        }
        
        // ================================================
        // NEW: Auto-migrate user if setting is enabled (strictly confirmed
        // users only, and only once they actually hold the student role)
        // ================================================
        if (!empty($this->config->automigrate) && $user->auth !== 'devicelock' && !empty($user->confirmed)
                && self::user_has_student_role_static($user->id)) {
            $this->migrate_user_to_devicelock($user->id);
        }
        
        $fingerprint = $this->generate_fingerprint();
        $deviceinfo = auth_devicelock_get_device_info();
        
        // ================================================
        // Check if this device was just blocked
        // If so, force immediate logout
        // ================================================
        if (!empty($SESSION->auth_devicelock_device_blocked)) {
            // Force logout immediately
            require_logout();
            
            // Clear the session
            if (isset($SESSION)) {
                unset($SESSION->auth_devicelock_device_blocked);
                unset($SESSION->auth_devicelock_blocked_fingerprint);
            }
            
            // Don't proceed with device registration
            return;
        }
        
        // Check if device exists using multi-browser linking (login event)
        $device = $this->find_device_for_user($user->id, true);

        
        if ($device && $device->status === 'active') {
            // Update last login
            $device->last_login = time();
            $device->ip_address = getremoteaddr();
            $DB->update_record('auth_devicelock_devices', $device);
            
            // Log the login event with device details
            if (method_exists('device_manager', 'log_action')) {
                device_manager::log_action($user->id, $fingerprint, 'device_login', [
                    'device_id' => $device->id,
                    'timestamp' => time(),
                    'ip' => getremoteaddr(),
                    'platform' => $deviceinfo['platform'] ?? ($device->platform ?? 'unknown'),
                    'screen_resolution' => $deviceinfo['screen_resolution'] ?? ($device->screen_resolution ?? 'unknown'),
                    'browser_language' => $deviceinfo['browser_language'] ?? ($device->browser_language ?? 'unknown'),
                    'gpu' => $deviceinfo['gpu'] ?? 'unknown',
                    'cpu_cores' => $deviceinfo['cpu_cores'] ?? 'unknown'
                ]);
            }
            
            // Show reset message if it exists
            if (!empty($SESSION->auth_devicelock_reset_message)) {
                \core\notification::info($SESSION->auth_devicelock_reset_message);
                unset($SESSION->auth_devicelock_reset_message);
            }
        } else if (!$device) {
            // Register new device
            $deviceid = device_manager::register_device($user->id, $fingerprint, $deviceinfo);
            if ($deviceid) {
                // Messages are deliberately postponed to everypage_hook to survive Moodle session regeneration
                // They are tracked in $SESSION->auth_devicelock_first_device_message and second_device_message
                if (!empty($SESSION->auth_devicelock_reset_message)) {
                    // Reset message is less critical, but we'll queue it
                    $SESSION->auth_devicelock_pending_reset_msg = $SESSION->auth_devicelock_reset_message;
                    unset($SESSION->auth_devicelock_reset_message);
                }
            }
        }
    }
    
    /**
     * NEW: Migrate user to devicelock authentication method
     * CHANGED: from private to public to allow access from admin_devices.php
     * 
     * @param int $userid User ID to migrate
     * @return bool Success
     */
    public function migrate_user_to_devicelock($userid, $killsessions = false) {
        global $DB, $USER;
        
        // Ensure devicelock is registered in Moodle's enabled auth plugins list
        auth_devicelock_ensure_enabled();

        $user = $DB->get_record('user', ['id' => $userid]);
        if (!$user) {
            return false;
        }

        // CRITICAL: Unconfirmed accounts must NEVER be switched to devicelock.
        // They must remain on Email-based self-registration until verified.
        if (empty($user->confirmed)) {
            return false;
        }

        // Don't migrate if user is excluded
        if ($this->should_restrict_user($user) === false) {
            return false;
        }
        
        $oldauth = $user->auth;

        // Update user's auth method to devicelock
        $user->auth = 'devicelock';
        $DB->update_record('user', $user);
        
        if (!empty($USER) && $USER->id == $userid) {
            $USER->auth = 'devicelock';
        }
        
        // Only reset devices and kill sessions if explicitly requested (e.g. admin manual migration)
        // During auto-migration upon login, we MUST NOT kill the active login session!
        if ($killsessions) {
            device_manager::reset_user_devices($userid);
        }
        
        // Log the migration
        if (method_exists('device_manager', 'log_action')) {
            device_manager::log_action($userid, 'system', 'auth_method_migrated', [
                'timestamp' => time(),
                'from_auth' => $oldauth,
                'to_auth' => 'devicelock'
            ]);
        }
        
        return true;
    }
    
    /**
     * NEW: Check if user can be migrated
     * 
     * @param int $userid User ID
     * @return bool True if migratable
     */
    public function can_migrate_user($userid) {
        global $DB;
        
        $user = $DB->get_record('user', ['id' => $userid]);
        if (!$user) {
            return false;
        }
        
        // Skip if already using devicelock
        if ($user->auth === 'devicelock') {
            return false;
        }

        // CRITICAL: Unconfirmed accounts must NEVER be migrated.
        // They must remain on Email-based self-registration until verified.
        if (empty($user->confirmed)) {
            return false;
        }
        
        // Skip excluded users
        if ($this->should_restrict_user($user) === false) {
            return false;
        }
        
        return true;
    }

    /**
     * Check if user should be restricted
     * MODIFIED: Now static to be callable from other classes
     */
    public static function should_restrict_user_static($user) {
        if (\auth_devicelock\local\macos_testing::disabled('device_rules')) {
            $native = \auth_devicelock\local\ios_identity::session();
            if ($native && ($native['platform'] ?? '') === 'macos' &&
                \auth_devicelock\local\ios_identity::permits_user($native, (int)$user->id)) { return false; }
        }
        $config = get_config('auth_devicelock');
        
        if (isguestuser($user->id)) {
            return false;
        }
        
        // ================================================
        // NEW: Bypass restrictions for unconfirmed users
        // ================================================
        if (empty($user->confirmed)) {
            return false;
        }
        
        // ================================================
        // v3.8.0: role-based exclusion. The old separate
        // exclude-admins / exclude-teachers checkboxes were
        // replaced by one multi-select list of roles (plus a
        // pseudo-entry for the site administrators).
        // ================================================
        $excludedroles = isset($config->excludedroles) ? (string)$config->excludedroles : '';
        if ($excludedroles !== '') {
            $excluded = array_filter(array_map('trim', explode(',', $excludedroles)), function ($v) {
                return $v !== '';
            });
            if (!empty($excluded)) {
                // Site administrators pseudo-entry.
                if (in_array('admin', $excluded, true) && is_siteadmin($user->id)) {
                    return false;
                }
                // Any selected role held in ANY context across the site.
                $roleids = array_values(array_filter(array_map('intval', $excluded), function ($v) {
                    return $v > 0;
                }));
                if (!empty($roleids)) {
                    global $DB;
                    list($roleinsql, $roleparams) = $DB->get_in_or_equal($roleids, SQL_PARAMS_NAMED, 'exr', true);
                    $roleparams['exu'] = $user->id;
                    $held = $DB->record_exists_sql(
                        "SELECT 1
                           FROM {role_assignments} ra
                          WHERE ra.userid = :exu AND ra.roleid " . $roleinsql,
                        $roleparams
                    );
                    if ($held) {
                        return false;
                    }
                }
            }
        }
        
        return true;
    }

    /**
     * Check whether a user currently holds the 'student' role in any context
     * (site-wide or in any course). Used to gate AUTO-migration only, so a
     * newly self-registered/confirmed account isn't switched to devicelock
     * auth before the school has actually enrolled them as a student -
     * enrolment/role assignment can happen well after email confirmation
     * (manual approval, a separate enrolment step, etc.), and migrating too
     * early was causing issues for accounts still in that in-between state.
     * Manual admin-triggered migration is unaffected by this check.
     *
     * @param int $userid User ID
     * @return bool True if the user has the student role somewhere
     */
    public static function user_has_student_role_static($userid) {
        global $DB;

        $sql = "SELECT DISTINCT r.shortname
                  FROM {role_assignments} ra
                  JOIN {role} r ON ra.roleid = r.id
                 WHERE ra.userid = ?";
        if ($roles = $DB->get_records_sql($sql, [$userid])) {
            foreach ($roles as $role) {
                if ($role->shortname === 'student') {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Check if user should be restricted (instance method)
     */
    private function should_restrict_user($user) {
        return self::should_restrict_user_static($user);
    }
    
    /**
     * Check if the given user has an active ban.
     *
     * Returns the ban record (with a formatted "message" field) if an
     * active (status="active") ban exists, or null otherwise. The
     * message is built from the configurable "ban_message" setting
     * plus the optional stored reason, formatted as:
     *     [ban_message]
     *     Reason: [reason]   (only when reason is non-empty)
     *
     * @param stdClass $user User object (must have ->id)
     * @return stdClass|null Ban record with ->message set, or null
     */
    private function check_user_ban($user) {
        global $DB;
        
        if (empty($user) || empty($user->id)) {
            return null;
        }
        
        // Bail out silently if the bans table does not exist yet
        // (e.g. plugin not yet upgraded). Keeps login working during
        // upgrades instead of fatal-erroring on the missing table.
        $dbman = $DB->get_manager();
        if (!$dbman->table_exists('auth_devicelock_bans')) {
            return null;
        }
        
        // IGNORE_MULTIPLE: if an admin somehow created two active
        // bans for the same user, the first one found is enough to
        // block the login - we do not need to distinguish them here.
        $ban = $DB->get_record('auth_devicelock_bans', array(
            'userid' => $user->id,
            'status' => 'active',
        ), '*', IGNORE_MULTIPLE);
        
        if (!$ban) {
            return null;
        }
        
        // Build the message: configured ban_message + optional reason.
        $config = get_config('auth_devicelock');
        $banmsg = !empty($config->ban_message)
            ? trim((string)$config->ban_message)
            : '';
        if ($banmsg === '') {
            $banmsg = get_string('ban_message_default', 'auth_devicelock');
        }
        $reason = isset($ban->reason) ? trim((string)$ban->reason) : '';
        if ($reason !== '') {
            $ban->message = $banmsg . "\n" . get_string('ban_reason_prefix', 'auth_devicelock') . ' ' . $reason;
        } else {
            $ban->message = $banmsg;
        }
        
        return $ban;
    }
    
    /**
     * Primary fingerprint is now the unique UUID token stored in the browser
     */
    private function generate_fingerprint() {
        return auth_devicelock_get_current_fingerprint();
    }

    /**
     * Find matching device using persistent token or hardware fallback
     */
    private function find_device_for_user($userid, $is_login = false) {
        return auth_devicelock_find_device_for_user($userid, $is_login);
    }


    /**
     * Generate legacy fingerprint for seamless migration
     */
    private function generate_legacy_fingerprint() {
        return auth_devicelock_generate_legacy_fingerprint();
    }
    
    /**
     * Get device info
     */
    private function get_device_info() {
        return auth_devicelock_get_device_info();
    }
    
    /**
     * Hook for login page
     */
    public function loginpage_hook() {
        global $PAGE, $SESSION;
        // Attested Apple clients use native proofs, never canvas/audio fingerprints.
        if (!\auth_devicelock\local\ios_identity::is_request()) {
            $PAGE->requires->js_call_amd('auth_devicelock/fingerprint', 'init');
        }

        // Check if incoming visitor is using a revoked browser token (e.g. after a browser reset)
        $curr_token = optional_param('auth_devicelock_token', '', PARAM_RAW);
        if (empty($curr_token) && !empty($_COOKIE['auth_devicelock_token'])) {
            $curr_token = clean_param($_COOKIE['auth_devicelock_token'], PARAM_RAW);
        }
        if (!empty($curr_token) && class_exists('device_manager') && device_manager::is_token_revoked($curr_token)) {
            if (!headers_sent()) {
                setcookie('auth_devicelock_token', '', time() - 3600, '/');
                setcookie('auth_devicelock_hw', '', time() - 3600, '/');
                setcookie('auth_devicelock_fallback', '', time() - 3600, '/');
            }
            if (!empty($SESSION)) {
                unset($SESSION->auth_devicelock_token);
            }
            $PAGE->requires->js_init_code("
                try {
                    localStorage.removeItem('auth_devicelock_token');
                    sessionStorage.removeItem('auth_devicelock_token');
                } catch(e) {}
            ");
        }
    }
    
    /**
     * Show error on login page
     */
    public function pre_loginpage_hook() {
        global $SESSION;

        // Check if visitor has a revoked browser token (e.g. after a browser reset)
        $curr_token = optional_param('auth_devicelock_token', '', PARAM_RAW);
        if (empty($curr_token) && !empty($_COOKIE['auth_devicelock_token'])) {
            $curr_token = clean_param($_COOKIE['auth_devicelock_token'], PARAM_RAW);
        }
        if (!empty($curr_token) && class_exists('device_manager') && device_manager::is_token_revoked($curr_token)) {
            if (!headers_sent()) {
                setcookie('auth_devicelock_token', '', time() - 3600, '/');
                setcookie('auth_devicelock_hw', '', time() - 3600, '/');
                setcookie('auth_devicelock_fallback', '', time() - 3600, '/');
            }
            if (!empty($SESSION)) {
                unset($SESSION->auth_devicelock_token);
            }
        }
        
        $is_blocked = optional_param('auth_devicelock_blocked', 0, PARAM_INT) || !empty($SESSION->auth_devicelock_device_blocked);
        if ($is_blocked) {
            \core\notification::error(get_string('deviceblockedmessage', 'auth_devicelock'));
            unset($SESSION->auth_devicelock_device_blocked);
            unset($SESSION->auth_devicelock_blocked_fingerprint);
        }
        
        // Show regular login error
        if (!empty($SESSION->loginerrormsg)) {
            if (!$is_blocked || $SESSION->loginerrormsg !== get_string('deviceblockedmessage', 'auth_devicelock')) {
                // Notifications render clean HTML: turn the plain-text line
                // break used in the ban message into a real <br> so the ban
                // reason shows on its own line. clean_text() inside
                // \core\notification keeps this safe.
                $loginerrmsg = str_replace("\n", '<br>', $SESSION->loginerrormsg);
                \core\notification::error($loginerrmsg);
            }
            unset($SESSION->loginerrormsg);
        }
    }
    
    /**
     * Hook for every page load - Check if current device should be logged out
     */
    public function everypage_hook() {
        global $USER, $SESSION, $DB;
        
        // 1. If currently on signup page, bypass all devicelock restrictions
        $req_uri = $_SERVER['REQUEST_URI'] ?? '';
        if (strpos($req_uri, 'signup.php') !== false) {
            return;
        }

        // 2. Email Confirmation Handling:
        // When user clicks the confirmation link in their email (e.g. Gmail app),
        // Moodle's confirm.php sets confirmed = 1 and calls complete_user_login.
        // We MUST NOT register the email browser/webview.
        // Force logout and redirect cleanly to /login/index.php.
        if (strpos($req_uri, 'confirm.php') !== false) {
            if (!empty($USER->id) && !isguestuser($USER->id)) {
                require_logout();
                \core\notification::success(get_string('emailconfirmed_login_intro', 'auth_devicelock'));
                redirect(new moodle_url('/login/index.php'));
            }
            return;
        }

        if (empty($DB) || !auth_devicelock_tables_exist()) {
            return;
        }

        
        if (empty($this->config->enabled)) {
            return;
        }
        
        if (isguestuser() || empty($USER->id)) {
            return;
        }

        // 3. Client-Side Browser Data Wipe Handler:
        // If an admin executed "Reset All Browsers" or "Reset Browser", wipe client tokens & cookies
        if (class_exists('device_manager') && device_manager::has_browser_wipe_flag($USER->id)) {
            if (!headers_sent()) {
                setcookie('auth_devicelock_token', '', time() - 3600, '/');
                setcookie('auth_devicelock_hw', '', time() - 3600, '/');
                setcookie('auth_devicelock_fallback', '', time() - 3600, '/');
            }
            if (!empty($SESSION)) {
                unset($SESSION->auth_devicelock_token);
            }
            device_manager::clear_browser_wipe_flag($USER->id);
            global $PAGE;
            $PAGE->requires->js_init_code("
                try {
                    localStorage.removeItem('auth_devicelock_token');
                    sessionStorage.removeItem('auth_devicelock_token');
                } catch(e) {}
            ");
        }
        
        // ================================================
        // NEW: Check if user is using wrong auth method and auto-migrate if
        // enabled (confirmed users who actually hold the student role only)
        // ================================================
        if (!empty($this->config->automigrate) && $USER->auth !== 'devicelock' && !empty($USER->confirmed)
                && self::user_has_student_role_static($USER->id)) {
            if ($this->can_migrate_user($USER->id)) {
                $this->migrate_user_to_devicelock($USER->id);
            }
        }
        
        if (!$this->should_restrict_user($USER)) {
            return;
        }
        
        // Render pending notifications strictly on page load to survive redirect destruction!
        if (!empty($SESSION->auth_devicelock_first_device_message)) {
            \core\notification::success($SESSION->auth_devicelock_first_device_message);
            unset($SESSION->auth_devicelock_first_device_message);
        }
        if (!empty($SESSION->auth_devicelock_second_device_message)) {
            \core\notification::success($SESSION->auth_devicelock_second_device_message);
            unset($SESSION->auth_devicelock_second_device_message);
        }
        if (!empty($SESSION->auth_devicelock_pending_reset_msg)) {
            \core\notification::info($SESSION->auth_devicelock_pending_reset_msg);
            unset($SESSION->auth_devicelock_pending_reset_msg);
        }
        
        // Show prominent instructions if user logged in with an admin-generated temporary password
        if (!empty($USER->id) && get_user_preferences('auth_devicelock_temp_pass', 0, $USER->id)) {
            global $PAGE;
            $is_change_pwd_page = (strpos($_SERVER['REQUEST_URI'] ?? '', 'change_password.php') !== false) ||
                                  (isset($PAGE->url) && strpos($PAGE->url->get_path(), 'change_password.php') !== false);

            if ($is_change_pwd_page) {
                \core\notification::warning(get_string('temppassword_user_notice', 'auth_devicelock'));

                // Add helper badge next to the 'Current password' field label so user is not confused
                $helptxt = get_string('temppassword_current_help', 'auth_devicelock');
                $js = "
                    (function() {
                        function applyTempPassHint() {
                            var pwdInput = document.getElementById('id_password');
                            var pwdLabel = document.querySelector('label[for=\"id_password\"]');
                            if (pwdLabel && !document.getElementById('auth_devicelock_temppass_hint')) {
                                var hint = document.createElement('span');
                                hint.id = 'auth_devicelock_temppass_hint';
                                hint.className = 'badge badge-info text-info ml-2 mr-2 p-1 font-weight-bold';
                                hint.style.fontSize = '85%';
                                hint.style.backgroundColor = '#e0f2fe';
                                hint.style.border = '1px solid #0284c7';
                                hint.style.borderRadius = '4px';
                                hint.innerHTML = '<i class=\"fa fa-info-circle\"></i> " . addslashes_js($helptxt) . "';
                                pwdLabel.appendChild(hint);
                            }
                            if (pwdInput && !pwdInput.getAttribute('data-hint-set')) {
                                pwdInput.setAttribute('placeholder', '" . addslashes_js($helptxt) . "');
                                pwdInput.setAttribute('data-hint-set', '1');
                            }
                        }
                        if (document.readyState === 'loading') {
                            document.addEventListener('DOMContentLoaded', applyTempPassHint);
                        } else {
                            applyTempPassHint();
                        }
                    })();
                ";
                $PAGE->requires->js_init_code($js);
            } else if (empty($SESSION->auth_devicelock_temp_pass_notified)) {
                \core\notification::warning(get_string('temppassword_user_notice', 'auth_devicelock'));
                $SESSION->auth_devicelock_temp_pass_notified = true;
            }
        }
        
        // Generate fingerprint for current device
        $fingerprint = $this->generate_fingerprint();
        $legacy_fingerprint = $this->generate_legacy_fingerprint();
        
        // Check if device exists using multi-browser linking (routine page view check)
        $device = $this->find_device_for_user($USER->id, false);

        
        // A verified Apple install still needs an authorized account registration.
        // A failed concurrent/over-limit registration must never leave a usable login.
        if (!$device && \auth_devicelock\local\ios_identity::is_request()) {
            require_logout();
            redirect(new moodle_url('/login/index.php', ['auth_devicelock_blocked' => 1]));
        }

        // If device exists but is not active, force logout immediately
        if ($device && $device->status !== 'active') {
            require_logout();
            redirect(new moodle_url('/login/index.php', ['auth_devicelock_blocked' => 1]));
        }
        
        // Check if admin has set a blocked notice preference for this user
        if (get_user_preferences('auth_devicelock_blocked_notice', 0, $USER->id)) {
            unset_user_preference('auth_devicelock_blocked_notice', $USER->id);
            require_logout();
            redirect(new moodle_url('/login/index.php', ['auth_devicelock_blocked' => 1]));
        }
        
        // Check if this device has a logout flag
        if (method_exists('device_manager', 'check_device_logout_flag')) {
            if (device_manager::check_device_logout_flag($USER->id, 'blocked_all')) {
                require_logout();
                redirect(new moodle_url('/login/index.php', ['auth_devicelock_blocked' => 1]));
            }
            if (!$device || $device->status !== 'active') {
                if (device_manager::check_device_logout_flag($USER->id, $fingerprint) ||
                    device_manager::check_device_logout_flag($USER->id, $legacy_fingerprint)) {
                    // This device was blocked - force immediate logout
                    require_logout();
                    redirect(new moodle_url('/login/index.php', ['auth_devicelock_blocked' => 1]));
                }
            }
        }
    }

    // Required methods
    public function is_internal() { return true; }
    public function prevent_local_passwords() { return false; }
    public function can_change_password() { return true; }
    public function is_can_change_password() { return true; }
    public function change_password_url() { return null; }
    public function can_reset_password() { return true; }
    public function user_update_password($user, $newpassword) {
        unset_user_preference('auth_devicelock_temp_pass', $user->id);
        if (isset($GLOBALS['SESSION'])) {
            unset($GLOBALS['SESSION']->auth_devicelock_temp_pass_notified);
        }
        if (method_exists('device_manager', 'log_action')) {
            device_manager::log_action($user->id, 'system', 'password_changed', [
                'timestamp' => time(),
                'ip' => getremoteaddr()
            ]);
        }
        return update_internal_user_password($user, $newpassword);
    }
    public function can_be_manually_set() { return true; }
    public function is_configured() { return true; }
    public function config_changed() { purge_all_caches(); }
    public function can_edit_profile() { return true; }
    public function can_edit_preferences() { return true; }
}