<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026101408; // v3.10.0: fixed the fuzzy-search "Mixed types of sql query parameters!!" crash (a literal '?' inside the REPLACE chain), admins now appear in the User Directory when "Show site admins" is enabled (was hard-hidden by id > 2), ONE Browser Login row per real login (was 4-5), full activity tracking: logout / Dashboard / My courses / section views, wildcard catch-all for every other *_viewed event, footer-time page-view logging with legacy-callback fallback, and button-click tracking
$plugin->requires  = 2025041400; // Moodle 5.0.0 - supports Moodle 5.0 and 5.1
$plugin->component = 'auth_devicelock';
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = '3.11.3-apple';
$plugin->supported = [500, 510]; // Moodle 5.0 - 5.1