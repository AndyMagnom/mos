\# Lock Guard Plugin for Moodle



This plugin restricts users to login from specific registered devices only, enhancing security by preventing unauthorized access from unknown devices.



\## Features



\- Restricts each user account to registered devices only

\- Automatically registers the first device used for login

\- Configurable maximum devices per user

\- Exclude any chosen roles (including administrators) from restrictions

\- Professional admin dashboard for device management

\- Detailed device information and logs

\- Anti-spoof device fingerprinting

\- **App Guard**: restrict sign-in to a custom app instead of a browser, plus device security event reporting (see Changelog 3.0.0 below for details)



\## Installation



1\. Copy the plugin folder to `/auth/devicelock/` in your Moodle installation

2\. Log in as administrator and go to Site Administration > Notifications

3\. Follow the installation prompts

4\. Enable the plugin in Site Administration > Plugins > Authentication > Manage authentication

5\. Configure the plugin settings



\## Configuration



\### Plugin Settings

\- \*\*Enable Lock Guard\*\*: Turn the plugin on/off

\- \*\*Maximum devices per user\*\*: Set how many devices each user can register (default: 1)

\- \*\*Exclude administrators\*\*: Do not apply restrictions to site administrators

\- \*\*Exclude teachers\*\*: Do not apply restrictions to teachers

\- \*\*Auto-register first device\*\*: Automatically register the first device a user logs in from



\### Admin Dashboard

Access the device management dashboard at: `/auth/devicelock/admin\_devices.php`



Features:

\- View all users and their registered devices

\- Block/unblock specific devices

\- Reset all devices for a user

\- Search users by email or name

\- View detailed device information



\## How It Works



1\. When a user logs in for the first time, their device is automatically registered

2\. The plugin creates a unique fingerprint of the device using:

&nbsp;  - Browser/device information

&nbsp;  - Screen resolution

&nbsp;  - Timezone

&nbsp;  - Hardware information

&nbsp;  - Browser language

3\. On subsequent logins, the plugin checks if the device is registered

4\. If not registered and the user has reached their device limit, login is blocked

5\. Admins can manage devices through the admin dashboard



\## Troubleshooting



\### Device Not Registering

1\. Make sure JavaScript is enabled in the browser

2\. Check browser console for errors

3\. Verify the plugin is enabled in settings

4\. Check that auto-register is enabled



\### Login Issues

1\. Check if the user has reached their device limit

2\. Verify the device isn't blocked in admin dashboard

3\. Check plugin logs for errors



\## Support



For support and issues, please check:

1\. Plugin settings are correctly configured

2\. Database tables are properly installed

3\. User has appropriate permissions



\## Changelog
\### Version 3.10.0 - fuzzy search crash fixed, admins visible, complete activity tracking

\- **Fixed: the advanced (fuzzy) search crashed with "Mixed types of sql query parameters!!".** The punctuation-stripping SQL used by the fuzzy strategies contained a literal REPLACE(..., '?', '') call, and Moodle's database layer counts every "?" in the SQL string (even inside quotes) - mixing it with the named :placeholders of the same query is a fatal error. The "?" is no longer stripped inside the SQL (it is still stripped from the typed search term, which is what actually matters), so the fuzzy search now runs instead of erroring. All other search behaviour is unchanged.

\- **Fixed: the main admin account now appears in the User Directory when "Show site admins in the User Directory" is enabled.** The directory queries hard-coded "user id > 2", which always hid the primary administrator account (user id 2 - the very account the setting was meant to reveal). Only the guest account (id 1) is unconditionally hidden now; every administrator (primary admin included) follows the setting in the User Directory, the type-filter chips, the pagination, "Select All", the CSV exports, the "Users Not Using Plugin" tab and the dashboard KPI.

\- **Fixed: one login produces exactly ONE "Browser Login" log row (was 4-5).** The login flow legitimately calls the browser recorder several times per sign-in (during credential validation, after authentication and from the logged-in event observer - twice), and each call used to write its own log row. A browser now logs at most once per 60 seconds: the first call records the login, every duplicate call in the same request stays silent. The usage counter on the device no longer inflates per login either.

\- **New: user logouts are logged.** "User Logout" rows (with username and full name) now close the session story - Moodle's own Logs report shows "User logged out" and the plugin's log finally mirrors it for manual logouts, session expirations and admin-forced logouts alike.

\- **New: Dashboard, My courses and course Section views are logged.** New "Dashboard Viewed", "My Courses Viewed" and "Section Viewed" events (with course, section number and section title for sections) capture the pages the admin found missing compared to Moodle's standard Logs report.

\- **New: catch-all observer for every other "..._viewed" event.** Any view event from any component - calendar, blog entries, messages, notifications, search results, badges, glossary entries, book chapters, wiki and lesson pages, question banks, competencies, the content bank, course information pages and more - is now recorded as a "Page Viewed" row carrying the event's own name (e.g. "Discussion viewed") and URL. Pages with a dedicated observer are skipped, so nothing is logged twice.

\- **Changed: generic page views are now written at footer time, with a self-healing fallback.** The page-view logger captures the page at header time but writes the row in the footer, after every event of the request has fired - so a course page whose Moodle event triggers late (course_viewed fires at the end of /course/view.php) produces ONE row (the event row), never both. On sites where the modern output hook dispatch never ran (observed on Moodle 5.0/5.1, which left the v3.6.0 page logger dead), a legacy lib.php callback now performs the same capture/write pair - Moodle automatically ignores the legacy callback whenever the modern hook registration is live, so the two can never double-fire.

\- **New: button clicks are tracked.** The footer beacon now reports every button the user presses (buttons, submit/reset inputs, role=button controls) as a "Button Clicked" row with the button's label, its type, the form action (when it belongs to a form) and the page it was clicked on. Internal link clicks stay unreported - the destination page logs its own view - but external links keep being reported as before. A 1-second same-button debounce keeps noisy double-firing widgets from flooding the log.

\- **Note for upgraders:** the new observers and the wildcard catch-all start working right after the upgrade; existing log rows are untouched. If you had the "Activity logging" master switch disabled, nothing is tracked until you enable it.

\- **Fixed: the lists in log Full Details were rendered empty.** The v3.8.0 renderer validated the affected-user / enrolled-course / role lists without ever collecting their items, so "Courses Changed", "Roles Changed", "Bulk Change Course", "Bulk Change Role", "Bulk Deletion", "Bulk Ban", "Bulk Unban" and "Bulk Users Created" events all showed empty list boxes and count chips of 0 even though the data was correctly stored. One-line root cause, one-line fix: the validation loop now collects each valid item, so every list (affected users, enrolled / un-enrolled courses, roles added / removed) actually displays, and the condensed chips show the real counts.

\- **Changed: \"Admin User: 2\" is now \"Admin User ID: 2\" plus the admin's username.** The number was the numeric Moodle user ID of the administrator who performed the action - it is now labelled \"Admin User ID\" for clarity, and new log entries also record the acting admin's username (\"Admin Username: admin\") next to the existing admin name and email. Old log rows keep their stored details and simply display with the clearer label.

\- **New: search by role.** Typing a role such as \"teacher\" in the User Directory search (and the Users Not Using Plugin search) now lists every user holding that role anywhere on the site - the term is matched against role names, shortnames and archetypes (so \"teacher\" also finds editing teachers). Role search is always available, in both classic and advanced search modes, and also works inside multi-word queries.

\- **New: \"Advanced (fuzzy) user search\" setting (off by default).** When enabled, the user search also finds results that do not match 100%: every word of the query can appear in a different field (\"bulk user 64\" finds \"bulkuser.64\"), punctuation and spaces are ignored when comparing (\"bulk-user 64\" finds \"bulkuser.64\"), and single typos are matched by an automatic second pass that only runs when the strict search finds nothing (\"buluser 64\" still finds \"bulkuser.64\", while \"bulk user 64\" keeps returning exactly the right user and not every near-miss). Some admins prefer the precise classic search - keep the setting off for the exact v3.8.0 behaviour, on for recall.

\- **New: \"Show site admins in the User Directory\" setting (off by default).** Site administrator accounts are now hidden from the User Directory, the Users Not Using Plugin list, their search results, the type-filter chip counts and the CSV exports unless this setting is enabled. Administrators remain directly reachable by URL and are never affected by any protection or bulk action.

\- **Changed: the user search boxes now advertise what they search.** The placeholder text mentions the new role search (\"...role (e.g. teacher)...)\" and is translatable (English and Arabic ships with this release).

\### Version 3.8.0 - event-observer activity logging, Change Course / Change Role, excluded roles

\- **Fixed: user activity is now recorded through Moodle's event system.** The v3.6.0 page-view hook did not fire on some sites, so course views, activity views, profiles, participants, grades, the course catalog and user tours never appeared in the Activity & Security Logs even though Moodle's own Logs report showed them. Lock Guard now registers observers for the same core events Moodle logs (course viewed, course module viewed, user profile viewed, participants viewed, course category viewed, grade report viewed, user tour started/ended), so those events are captured reliably on every Moodle 5.0/5.1 site. The existing page-view logger stays as an extra fallback for pages that fire no event (dashboards, generic pages, file downloads, external link clicks), and a per-request guard prevents double-logging the same page view.

\- **New: affected users in bulk log details.** The "Bulk Users Created", "Bulk Ban" and "Bulk Unban" log entries now include the full list of affected accounts in their Full Details - expand the event row to see every user (full name, username, email).

\- **Changed: Bulk Deletion is one grouped log entry.** Deleting many users at once now writes a single "Bulk Deletion" event that lists every deleted account in its Full Details, instead of one separate row per user.

\- **New: "Change Course" in the user action menu.** Enrol the user into courses or un-enroll them from courses in one place: every course shows a checkbox (courses the user is already enrolled in are pre-checked) plus its own duration in days, and one "Enrol as role" selector (default: Student) covers the enrolment. Unchecking a course un-enrolls the user; checking a course enrolls them (or updates the existing enrolment) with the chosen days and role.

\- **New: "Change Course" in the bulk actions.** The same course picker for many users at once: every course starts unchecked, and whatever you check (with its days and role) completely REPLACES the current course enrolments of every selected user - they end up enrolled in exactly the checked courses and un-enrolled from all others.

\- **New: "Change Role" in the user action menu.** Change the user's site-level (system) roles: roles already assigned to the user are pre-checked; uncheck to remove, check to assign. Course-level role assignments are not affected.

\- **New: "Change Role" in the bulk actions.** Every role starts unchecked, and the roles you check completely REPLACE the site-level roles of every selected user.

\- **Changed: "Exclude administrators" and "Exclude teachers" replaced by an "Excluded roles" multi-select.** Pick any combination of existing roles (the list includes every role on the site plus a dedicated "Administrators (site admins)" entry). Users holding any selected role are excluded from the device restrictions. Your previous exclude-admins/exclude-teachers choices are migrated automatically when you upgrade.


\### Version 3.7.0 - User Directory selection & page size, adjustable auto-ban threshold

\- **Changed: "Select All" in the User Directory now really selects ALL users** \- every user matching the current search, type filter and score band, across every page, not just the rows on the current page. Users on other pages are submitted as hidden selections, and the count badge always shows the true total.

\- **New: "Select Visible" button** between "Select All" and "Clear Selection" \- selects only the users shown on the current page (the old Select All behaviour). Unchecking the header checkbox now also clears any invisible cross-page selections, so nothing is ever submitted behind your back.

\- **New: users-per-page control** next to the User Directory pagination: choose 10 / 20 / 50 / 100 / 250 or press "Show All" to load every user on one page. The choice is temporary \- it is never saved, and a plain refresh or a page change returns to the default of 20 per page.

\- **New: adjustable Auto-ban threshold.** The "Auto-ban at 0%" setting is now "Auto-ban low scores" plus an "Auto-ban threshold (%)" setting (0\-100): raise it to 20 and every user whose score falls to 20% or below is banned automatically, with the reason "Security score reached 20%" on the login screen. Saving either setting immediately auto-bans every existing user already at or below the new threshold (site administrators are never auto-banned). The default of 0 keeps the previous behaviour exactly.


\### Version 3.6.0 - full user-activity logging, log display overhaul

\- **New: full user-activity logging.** The logs tab is now "Activity & Security Logs" and records everything a user does \- every page they open, courses and activities they view, profiles, grades, files they access, and even external links they click \- not just security events. Activity events wear light outlined badges, never affect the security score, and get their own retention setting (default 30 days).

\- **New settings**: Track user activity (on by default), track site administrators (off by default), and activity retention in days.

\- **Log display overhaul**: detail labels fixed (GPU, CPU, CPU Cores, Device ID, IP, Password Length), the full-details panel now lays out every key and value on a proper aligned grid with clear spacing, booleans show as Yes/No, timestamps as human dates, fingerprints are shown in full (no longer cut in half), and supporting gray text was darkened for readability.

\### Version 3.5.1 - upgrade fix, violation list document

\- **Fixed: coding error during the 3.5.0 upgrade** ("Key fk_userscore_userid collides with index userid specified in table auth_devicelock_user_scores"). The new score table defined both a foreign key on userid and a separate unique index on userid - Moodle 5.x's XMLDB refuses an index that covers exactly the same field as a key, and the upgrade stopped before the table was created. The table now uses a single foreign-unique key, which still guarantees one score row per user (and still blocks duplicates). Nothing else changed: no data was lost, the table was never created on the failed run, so simply replace the plugin folder with this version and re-run the upgrade from Site Administration > Notifications.

\- **Changed: the install.xml schema uses the same single foreign-unique key** for the score table, so fresh installs and upgraded sites end up with the identical structure (fresh installs of 3.5.0 did not crash, but they created a second, redundant unique index on userid next to the key).

\- **New: docs/score_violations.html** - the complete Security Score violation list (all 27 violations, grouped by category with their exact point values, score bands, regain rules and settings) as a standalone HTML page you can open in any browser, print or share. It is included in the plugin package.

\### Version 3.5.0 - persistent Security Score, Moodle 5.0 + 5.1 support

\- **New: the Security Score is now a real, persistent score.** Every account starts at 100% the moment it is created, and each detected violation lowers it by a fixed amount. Login & device violations: blocked login on an unregistered device -10, blocked device login attempt -10, unexpected device login -12, device limit reached -6, browser limit reached -6, login blocked by a limit -8, web sign-in blocked by App Guard -4, device blocked by an admin -5. Admin sanctions: account suspended -15, user banned -40. App Guard (Android app): screenshot attempt -15, screen recording detected -20, developer options detected -20, USB debugging detected -18, wireless debugging detected -18, emulator detected -25, audio capture detected -15, mic guard unavailable -8, mic contended -10. App Guard (Windows app): virtual machine detected -25, debugger detected -20, developer mode detected -20, test signing detected -18, remote session detected -12, virtual display detected -15, capture tool detected -15, recorder suspected -15. The full list is also shown on the plugin's settings page. Every violation's log entry now records the before/after score, and the score-history sparkline reflects real score changes.

\- **New: Regain score setting.** After the last violation the user slowly regains points: you configure how many points (default 5) and the interval - anything from seconds to months (default 1 day; a month counts as 30 days). The regain timer restarts from zero on ANY new violation (or a manual decrease), so a user who keeps violating never regains a single point until they stay clean for the whole interval. Regains are applied by a once-a-minute scheduled task (make sure Moodle cron is running) and each regain is written to the Security & Error Logs as its own styled event.

\- **New: Auto-ban at 0% setting.** When enabled and a user's score reaches 0% (from violations or a manual decrease), the user is banned automatically - exactly like a manual ban: the account is suspended, all sessions are killed, and the reason "Security score reached 0%" is shown on the login screen. Site administrators are never auto-banned.

\- **New: "Change Score" in the user action menu** (and a matching button on the user details page). Increase, decrease, set an exact value, or reset to 100% - with an optional reason that is recorded in the log. The same form lets you give an individual user their own custom regain rate (points + interval, seconds to months) instead of the global one. A manual decrease is treated like a sanction (it restarts the regain timer and counts as a violation); increases and exact sets do not touch the timer.

\- **New: "Reset Score" bulk action** in the User Directory - select any number of users and reset their score to 100% in one click. Violation counters and regain timers are cleared too.

\- **Changed: score display is now a percentage** (e.g. "85% - Good") everywhere: the User Directory Score column, the user details header, the CSV export and the weekly snapshot email. The dashboard Security Score Distribution chart and the band filters (Excellent / Good / Fair / At Risk / Critical) read the stored scores directly. "Recalculate All Scores" now creates any missing score rows (at 100%) and applies every due regain.

\- **Changed: Moodle 5.0 and 5.1 are both officially supported.** The plugin now declares Moodle 5.0.0 as its minimum version and the 5.0-5.1 branch range. Verified against real Moodle 5.0 and 5.1 core sources: the login ban-reason mechanism (pre_user_login_hook), every icon mapping the plugin uses (including the new Change Score icon), the user-created event, the scheduled-task and admin-settings APIs are identical on both versions.

\- On upgrade, every existing user is seeded with a clean 100% - the new score model starts now (past log activity is not re-computed into the score).

\- English and Arabic language packs updated with the new strings.
\### Version 3.4.5 - multiple App Guard markers & keys, underscore clean-up

\- **New: App Guard supports multiple User-Agent markers AND multiple App keys.** The "App User-Agent marker" and "App key" settings became "App User-Agent markers" and "App keys", edited as a friendly row-per-value list: one input per value plus an empty row ready for the next, an "Add another" button, a remove button per row, a show/hide eye toggle on key rows, and multi-line pastes split across rows automatically. A request counts as the app when its User-Agent contains ANY listed marker, and a request carrying ANY listed key (X-App-Key / X-AppGuard-Key header) is accepted \- so each app build (Android, Windows, ...) can have its own marker and its own key, and a single compromised key can be revoked by removing just its line. Values are stored one per line in the SAME settings as before, so an already-configured single marker/key keeps working unchanged, and the appguard_rest.php event endpoint accepts every listed key too (header or JSON body "app_key").
\- **Fixed: raw underscored event names in the User Directory "Log" column tooltip.** Actions without a hand-written tooltip (e.g. "quick_create_user on 08 Oct 2026...") showed the raw snake_case action name. Every such action now gets its human-readable label, semantic icon and colour from the same shared action map the log badges use \- unknown/future actions are humanised automatically ("some_new_event" -> "Some New Event").
\- **Changed: the small grey "auth_devicelock | setting_name" technical identifier line under each setting label is hidden on the plugin's settings page.** That line is standard Moodle admin markup (shown for every plugin), but it read as yet another set of underscore strings. The hiding rule is scoped strictly to this plugin's setting IDs and injected only on this page \- no other admin page is affected.

\### Version 3.4.4 - user creation polish, expandable log details

\- **New: First name / Last name fields on Quick Create User and Bulk Create Users.** Choose the names yourself, or tick the new "Auto-generate" checkbox to fill a random realistic name pair (a different pair for every user in a bulk batch).
\- **Fixed: Bulk Create no longer "skips" users when similar accounts already exist.** The numbering is advanced past every existing username/email BEFORE the batch runs (e.g. after an earlier batch created user1..user5, the next batch simply starts at user6), so the requested number of accounts is always created. A friendly notice tells you where the numbering started instead of the alarming "skipped" message.
\- **New: log events are expandable.** In every log view (Security & Error Logs, per-user Security History, both Audit Timelines) click an event row \- or its "Show all" link \- to expand the full, untruncated details. Long values (user agents, fingerprints, notes) are no longer cut off; click again to collapse.
\- **Redesigned: User Directory filter chips.** The All Users / Banned / Unbanned / Blocked / Active chips were restyled with custom pill styles: type-coloured icons, live counts, and a solid accent colour when active \- rendering identically on Bootstrap 4 and Bootstrap 5.
\- **Improved: the "Accounts created" card now shows each account name** in its own column, and the CSV download / "Copy all" output includes it too.
\- English and Arabic language packs updated with the new strings.

\### Version 3.4.3 - Moodle 5.x (Bootstrap 5) compatibility pass, directory polish

\- **Fixed: search-bar buttons detached on Moodle 5.x.** Moodle 5.x themes run Bootstrap 5, which removed the `.input-group-prepend` / `.input-group-append` wrappers the search bars used - so the magnifier and the clear button floated away from the input with gaps and rounded corners. All four search bars (Device Inventory, User Directory, Users Not Using Plugin, Security & Error Logs) now place the magnifier (submit) and the **\u00d7** (clear) as direct children of the input group, with plugin CSS that keeps them attached and correctly rounded on *both* Bootstrap 4 (Moodle 4.x) and Bootstrap 5 (Moodle 5.x). The Device Inventory tab also lost its separate "Apply Filter" button - the magnifier searches and the status dropdown applies immediately.
\- **Fixed: banned user rows.** The whole row is now tinted one solid red (with a red accent on the leading edge) instead of the old patchwork that painted individual `<div>`s inside the cells and left a weird overlay over the name and the action buttons. The "Banned" badge also gets proper spacing after the user's name (inside the flex row the old whitespace collapsed to nothing, so the badge hugged the name).
\- **New: User Directory type filter chips.** A chip row under the search bar filters the directory by user type: All Users, Banned, Unbanned, Blocked (site access) and Active - each chip shows a live count that respects the current search, the chips combine with search text and the security-score band filter, and they are preserved by search, export, pagination and the bulk-action form.
\- **New: created-account credentials are now shown after Quick / Bulk Create.** After creating user(s), a "Accounts created" card appears once on the User Directory tab listing every created username, email and password (auto-generated ones included), with a per-row copy button, a "Copy all (CSV)" button and a "Download CSV" link (UTF-8 BOM for Excel). This matters because Moodle stores passwords hashed - this one card is the only moment the plaintext values are available - and because bulk numbering jumps over existing accounts, so the exact usernames/passwords used could not be guessed before.
\- **Changed: the user-count badge now reads "N users"** instead of "N website users" (empty-state texts also dropped the word "website").
\- **Changed: the Security Snapshot toolbar button is now solid** (matching the other buttons beside it) instead of outline.
\- **Fixed: "Generate Temporary Password" and "Change Password" menu icons.** Both used the `i/key` pix icon, which is excluded from Moodle's FontAwesome map and renders as an old raster GIF that clashed with the crisp vector glyphs used by every other item in the action menu. They now use `i/grading` (magic wand) and `t/unlocked` (open padlock) - proper FontAwesome vector icons that match the rest of the menu.
\- English and Arabic language packs gained the new strings (filter chips + created-accounts card).

\### Version 3.4.2 - log styling, dashboard + search bar clean-up

\- **Fixed: unstyled log events.** Some Security & Error Log rows (User Banned / Unbanned, Quick User Created, Bulk Users Created, password changes, details copied, deletions, log clears...) rendered as raw snake_case text in a plain grey badge. All four log views (global Security & Error Logs, the per-user Security History table, and the per-user / per-device Audit Timelines) now render every event through one shared badge helper with a proper colour, icon and human-readable label - and any *unknown/future* action automatically falls back to a humanised label (e.g. "some_new_event" -> "Some New Event") so no row can ever look unstyled again.
\- **Improved: log Details column.** The raw "key: value | key: value" dump is now rendered as neat chips - a highlighted admin badge, humanised key labels ("total_browsers_seen" -> "Total Browsers Seen"), Yes/No instead of 1/0 for is_* flags, long values (user agents etc.) truncated with the full text on hover, and redundant keys (timestamp, ip) hidden since they already have their own columns. The per-user/per-device Audit Timelines show the same styled chips instead of a raw JSON dump.
\- **Changed: "Security Activity Trends" card removed from the dashboard** (the 7/30-day mini bar charts). The weekly Security Snapshot page keeps its own trend summary.
\- **Changed: "Audit & Investigation Hub" card removed from the dashboard** (the three "audit trilogy" launcher cards). The three views themselves are untouched and still open from their usual places: Security & Error Logs from the tab bar, Per-User Timeline from any user row, Per-Device Timeline from any device row.
\- **Changed: redesigned search bars (User Directory, Users Not Using Plugin, Security & Error Logs).** The magnifier is now a proper button *inside* the search bar that runs the search - the separate full-width "Search Users" / "Search Logs" button underneath is gone. The clear **×** now lives inside the search bar itself (appears as soon as you type, or when a search/filter is active) instead of being a separate button - clicking it clears the text and resets the results. On the logs tab the event-type dropdown stays next to the search bar.
\- **Improved: complete event-type filter.** The filter dropdowns (logs tab + both audit timelines) now also list User Banned/Unbanned, Bulk Ban/Unban, Quick User Created, Bulk Users Created, Password Changed, Password Reset Completed, User Migrated (single/bulk), Auth Changed (Bulk), Email Sent (Bulk) and User Browsers Reset.
\- English and Arabic language packs cleaned up (unused trend/hub strings removed).

\### Version 3.4.1 - ban reason on login screen, admin UI clean-up

\- **Fixed: the ban reason never appeared on the login screen.** Banning a user also suspends the account, and Moodle rejects suspended accounts inside `authenticate_user_login()` *before* any authentication-plugin hook runs - so the plugin's ban-message code was never reached and a banned user only ever saw the generic "Invalid login, please try again". The ban message (with the stored reason) is now surfaced through `pre_user_login_hook()` - the same mechanism Moodle core uses for the account-lockout message - and is shown in the login form's error box once the correct password is entered. A wrong password keeps showing the generic error, so ban status/reasons cannot be probed.
\- **Fixed: latent ban bypass.** If a ban existed whose account had later been un-suspended in the database without lifting the ban, `user_authenticated_hook()` logged the user out but did not abort the login, so `login/index.php` logged the banned user straight back in. The hook now marks the in-memory user suspended so `authenticate_user_login()` returns false and the login is properly refused (the ban message is still shown).
\- **Changed: "Import Users (CSV)" removed from the UI.** Both the global-toolbar button and the collapsible upload card on the User Directory tab are gone (the import action handlers remain in the code but are no longer linked from anywhere). Use "Quick Create User" / "Bulk Create Users" instead.
\- **Changed: "Quick Create User" and "Bulk Create Users" moved into the User Directory.** The two buttons now live in the User Directory card header, next to the website-user-count badge, instead of the global toolbar at the top of the page - so account creation happens right where the user list is.
\- **New: translatable ban text.** New language strings for the default ban message ("You are banned from using this site!") and the "Reason:" prefix (English + Arabic) - the login-screen ban message now follows the site language when no custom message is configured.

\### Version 3.4.0 - course enrolment, bulk-create fix, required-field validation

\- **New: Enrol new users into existing courses.** Both "Quick Create User" and "Bulk Create Users" now have an "Enrol in courses" section with a searchable course list (select all / none), a course role picker (Student by default) and an optional enrolment duration in days (0 = unlimited). Enrolment uses the standard Manual enrolment plugin - a manual instance is found, re-enabled or created per course as needed, and results are reported via notifications.
\- **Fixed: Bulk Create Users always reported "Skipped" and created nothing.** Generated usernames used the format `base#1`, but Moodle only allows letters, numbers, dot, dash, underscore and @ in usernames, so `user_create_user()` threw `invalidusername` for every single account and the batch silently counted them as skipped. The numbering is now `base1, base2, ...` and the username base is validated before anything is created.
\- **Fixed: silent failures.** Any user-creation error during bulk create is now collected and shown to the admin (first 5 reasons) instead of being swallowed as a "skipped" count. If nothing at all could be created, a clear error notification is shown.
\- **Improved: numbering continues past conflicts.** If `student5` already exists, the bulk tool now jumps to the next free number instead of returning fewer accounts than requested.
\- **New: required-field enforcement.** In both Quick Create and Bulk Create, a field can no longer be left empty while its "Auto-generate" checkbox is unchecked - the browser blocks submission and highlights the field (and the server double-checks and returns a per-field error message listing exactly which fields are missing).
\- **Improved: input validation.** Usernames and username bases are checked against Moodle's allowed characters, and generated email addresses are validated before any account is created, with clear error messages.
\- English and Arabic language packs updated.

\### Version 3.2.0 - Windows app support

\- **New: `appguard_whoami.php`.** Returns the signed-in user's id, name and username (own data only, session-authenticated, app requests only while App Guard is on) so the Windows app can draw a per-student watermark.

\- **App Guard accepts the Windows app's event types**: `vm_detected`, `debugger_detected`, `dev_mode_detected`, `test_signing_detected`, `remote_session_detected`, `virtual_display_detected`, `capture_tool_detected`, `recorder_suspected`. Before this, the merged plugin answered 400 to them. They show in Security & Error Logs and the event-type filter.




\### Version 3.1.1 - three login/device-limit bugs fixed

\- **Fixed: "Error writing to database" on a blocked login.** `user_login()` used `$fingerprint` in every blocked-login log entry but never actually assigned it in that method - it was silently `NULL`, and the `device_fingerprint` column is `NOT NULL`, so the very first blocked login threw a DB write exception instead of showing a normal "device not allowed" message. This affected every blocked-login log point in that method (limit reached, browser limit reached, blocked device), not only the device-limit case.

\- **Fixed: setting "Maximum devices" to 0 still allowed one device.** Two separate places silently floored 0 up to 1: the config reader used `?: 1` (0 is falsy in PHP, so it was treated as "not set"), and both device-registration code paths had an unconditional "always allow the first device" rule that never checked the limit at all. 0 now means exactly what it says - no device, including the first one, is ever allowed.

\- **Fixed: lowering the limit below an already-registered device count did nothing.** Set the limit to 2, both devices register, then lower it to 1 - both devices kept working indefinitely, because only the "register a brand-new device" code path checked the limit; an already-recognized device skipped the check entirely. Every login now re-ranks the user's active devices by registration order and only the first N (N = current limit) continue to work - the rest are blocked and logged, even though they registered successfully before the limit was lowered.



\### Version 3.1.0

\- **Renamed to "Lock Guard"** everywhere a display name or doc-comment referred to "Single Device Login" as the plugin's name (lang `pluginname`, README, page headings, admin notifications, source comments). The technical component name (`auth_devicelock`, table names, function prefixes, the `/auth/devicelock/` folder) is unchanged on purpose - renaming that would mean a full uninstall/reinstall and lose every stored device, log, and setting. "App Guard" keeps its own name too, as the sign-in-restriction feature inside Lock Guard.

\- **New top-bar tab**: Site administration now has a "Lock Guard" tab next to General/Users/Courses/Plugins/Server/etc., with Dashboard and quick links (Security & Error Logs, User Directory) under it. Built with a subcategory on purpose - Moodle silently folds a plugin's admin category into the "General" tab unless it has at least one child that is itself a category, not just leaf pages.

\- **Settings reordered**: Dashboard button first, then a new "Single Device Login" heading grouping the original device/browser-limit settings (including Migration Information and Email Templates), then "App Guard", then the Danger Zone purge button last.

\- **Fixed**: the Security & Error Logs event-type dropdown showed "Device &amp; account" literally instead of "Device & account" - it was HTML-escaped twice (the source string already had `&amp;`, then the output code escaped it again).

\- **Fixed**: the "Migration Information" settings block showed its `<ul>/<li>` markup as literal text instead of a bullet list. Moodle's settings-heading renderer treats an indented, multi-line string as a preformatted/code block; rewritten as a single unindented line.

\- **Clarified**: "App key" was labelled "optional hardening", which undersold it - it's optional for hardening the sign-in check, but REQUIRED for the app to report security violations while no one is logged in (there is no other way for an anonymous request to authenticate to `appguard_rest.php`). The setting description now says this plainly.



\### Version 3.0.0 - App Guard merged in

App Guard (formerly a separate `local_appguard` plugin) is now built into Lock Guard. **Do not install the old AppGuard.zip alongside this** - if `local_appguard` is already on the site, uninstall it first (Plugins -> Uninstall plugins) to avoid two sets of observers/hooks reacting to the same logins.

What it does:

\- **App-only sign-in**: restricted users (the same population the device limit already applies to - students, minus any excluded admins/teachers) can only sign in through your custom app (Windows/Android/Mac/...). A browser sign-in is refused at the credential check for devicelock-auth users, or terminated on the spot otherwise (any auth method, or a session that already existed before this was turned on). Off by default - turn on under Settings -> App Guard once your app is distributed.

\- **One restricted population, not two**: App Guard does not have its own separate role list. It reuses `should_restrict_user_static()`, the exact same check the device limit uses, so there is nothing to keep in sync between "who gets the device limit" and "who is app-only".

\- **App recognition**: a configurable User-Agent marker (default `AppGuard`) your app sends in its WebView user-agent, plus an optional shared "App key" header (`X-App-Key` / `X-AppGuard-Key`) for stronger verification a browser cannot spoof.

\- **Device security events**: a new endpoint, `POST /auth/devicelock/appguard_rest.php`, accepts JSON events from the app (`emulator_detected`, `screenshot_attempt`, `screen_recording_detected`, `dev_options_detected`, `usb_debugging_detected`, `wireless_debugging_detected`, `audio_capture_detected`, `mic_guard_unavailable`, `mic_contended`). Authenticated either by an active Moodle session or the App key header (for pre-login events). Optional admin popup + email notification, throttleable.

\- **Everything lands in the existing Security & Error Logs tab** - no separate log store. The tab now also has an **event-type dropdown filter** (grouped: Device & account / App Guard) alongside the existing text search, so you can isolate one exact event type.

\- **Web-service tokens** of restricted users are swept every minute by a new scheduled task, closing the gap for tokens issued through `/login/token.php` (the official Moodle app, or any other API client) that a sign-in-time check cannot reach.

\- **`maxbrowsers` interaction fixed**: once App Guard is restricting a user to the app, the browser-family limit is automatically skipped for that user - a real second browser is already impossible for them, so counting the app's own re-registrations (reinstall, cleared app storage) as "new browsers" could only cause false lockouts, never add security. `maxbrowsers` still applies normally to anyone App Guard does not restrict.

\- **`maxdevices` needs no change** - it already does exactly what's needed for "same account on a PC and a phone": set it to 2. A PC and a phone have different hardware, so they are always counted as separate devices whether the sign-in came from a browser or, now, the app.



\### Version 2.4.1

\- Auto-migrate (the automatic switch to Lock Guard auth on login) now also requires the user to actually hold the student role somewhere on the site, not just have a confirmed email. Fixes auto-migration firing on accounts that are confirmed but not yet enrolled/assigned as a student. Manual admin-triggered migration ("Migrate to Plugin" button) is unaffected — it still only requires a confirmed, non-excluded account.



\### Version 2.4.0

\- "Change Password" now asks first: auto-generate a password, or enter a custom one (with confirm field, checked against site password policy).

\- Both "Change Password" (auto mode) and "Generate Temporary Password" now let the admin pick the generated password's length (site minimum to 64 characters) before it's created.



\### Version 2.3.1

\- Shortened the admin-generated password (dropped the long hex suffix added in 2.3.0, back to a short prefix+symbol+number shape, still generated with random_int()).

\- Added: "Change Password" admin action, next to Generate Temporary Password. Sets a real permanent password for the user — no forced change prompt, no single-use login.



\### Version 2.3.0 (Security hardening)

\- Fixed: device token from the login form could override an already-registered device's token (identity spoofing). Cookie/session now takes priority over POST.

\- Fixed: ajax.php accepted requests with no session key at all; sesskey is now mandatory.

\- Fixed: hardware-based device matching could match two different physical machines that merely shared an IP/subnet and screen resolution (e.g. a computer lab); now requires a genuine hardware signal (canvas hash, or GPU+screen together).

\- Fixed: temporary passwords were generated with rand() and had very low entropy; now uses random_int()/random_bytes().

\- Fixed: password reset token comparison now uses hash_equals() (timing-safe).

\- Fixed: several admin dashboard pages echoed user full names without escaping.

\- Removed: debug.php, fix.php, repair.php, test.php, testRes.php, test_sesskey.php, quick_check.php, a stray production error_log, and a dead duplicate session_manager.php that were bundled into the plugin by mistake.



\### Version 1.0.5

\- Fixed first device registration issue

\- Fixed confirmation loop in admin dashboard

\- Improved error handling

\- Enhanced device fingerprinting



\### Version 1.0.4

\- Initial stable release

\- Basic device registration and management

\- Admin dashboard

\- Multi-language support

