<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Device Manager - PERMANENT FIX: Block device logs out ONLY that device
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
require_once(__DIR__ . '/classes/local/ios_identity.php');

/**
 * Device Manager Class - PERMANENT SOLUTION
 */
class device_manager {
    
    /**
     * Reset all devices for a user - DELETE ALL and logout ALL
     */
    public static function reset_user_devices($userid) {
        global $DB, $CFG;
        
        // Ensure devicelock is enabled in Moodle
        if (function_exists('auth_devicelock_ensure_enabled')) {
            auth_devicelock_ensure_enabled();
        }
        
        // 1. DELETE ALL DEVICES FROM DATABASE
        $DB->delete_records('auth_devicelock_devices', ['userid' => $userid]);
        
        // 2. Delete all session tracking for this user
        if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
            $DB->delete_records('auth_devicelock_session_tracking', ['userid' => $userid]);
        }
        
        // 3. Clear any device logout flags on disk for this user
        $logoutdir = $CFG->dataroot . '/devicelock_logout_flags';
        if (is_dir($logoutdir)) {
            $flags = glob($logoutdir . '/logout_' . $userid . '_*.flag');
            if ($flags) {
                foreach ($flags as $flag) {
                    @unlink($flag);
                }
            }
        }
        
        // 4. Set reset notification
        self::set_user_reset_notification($userid);
        
        // 5. FORCE LOGOUT FROM ALL DEVICES
        self::force_logout_user($userid);
        
        // 6. Log the action
        self::log_action($userid, 'system', 'reset_all_devices', [
            'timestamp' => time(),
            'admin_user' => isset($USER) ? $USER->id : 0,
            'admin_email' => !empty($USER->email) ? $USER->email : '',
            'admin_name' => !empty($USER) ? fullname($USER) : '',
            'ip' => getremoteaddr()
        ]);
        
        // 7. Send templated email notification (Feature 1)
        if (function_exists('auth_devicelock_send_template_email')) {
            auth_devicelock_send_template_email($userid, 'reset', [
                'ip'         => getremoteaddr(),
                'devicename' => get_string('unknown', 'auth_devicelock'),
            ]);
        }
        
        return true;
    }
    
    /**
     * Reset all browsers for a user - Clears browser data, wipes client storage tokens, and terminates sessions,
     * while RETAINING all device records in auth_devicelock_devices.
     * Browsers re-register upon next login on the same devices.
     *
     * @param int $userid
     * @return bool
     */
    public static function reset_user_browsers($userid) {
        global $DB, $CFG, $USER;

        $devices = $DB->get_records('auth_devicelock_devices', ['userid' => $userid]);
        $revoked_tokens = [];
        if (!empty($devices)) {
            foreach ($devices as $device) {
                $info = !empty($device->device_info) ? @json_decode($device->device_info, true) : [];
                if (!is_array($info)) {
                    $info = [];
                }
                if (!empty($info['browser_tokens']) && is_array($info['browser_tokens'])) {
                    $revoked_tokens = array_merge($revoked_tokens, $info['browser_tokens']);
                }
                if (!empty($device->device_fingerprint)) {
                    $revoked_tokens[] = $device->device_fingerprint;
                }

                // 1. Wipe browser collections on this device and persist revoked tokens
                $existing_revoked = !empty($info['revoked_tokens']) && is_array($info['revoked_tokens']) ? $info['revoked_tokens'] : [];
                $info['revoked_tokens'] = array_slice(array_values(array_unique(array_merge($existing_revoked, $revoked_tokens))), -50);
                $info['browsers_used'] = [];
                $info['browser_tokens'] = [];

                // 2. Set device_fingerprint to stable hardware hash to decouple from old browser token
                $hw_hash = $info['hw_hash'] ?? ('hw_' . md5($device->id . '_' . $device->screen_resolution . '_' . $device->platform));
                // Apple device identity is server-attested, never a browser hash.
                if (!\auth_devicelock\local\ios_identity::is_apple_fingerprint($device->device_fingerprint)) {
                    $device->device_fingerprint = $hw_hash;
                }
                $device->user_agent = ''; // Clear UA so fallback does not restore old browser family
                $device->device_info = json_encode($info);
                $DB->update_record('auth_devicelock_devices', $device);
            }
        }

        // 3. Delete session tracking for this user
        if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
            $DB->delete_records('auth_devicelock_session_tracking', ['userid' => $userid]);
        }

        // 4. Clear any device logout flags on disk for this user
        $logoutdir = $CFG->dataroot . '/devicelock_logout_flags';
        if (is_dir($logoutdir)) {
            $flags = glob($logoutdir . '/logout_' . $userid . '_*.flag');
            if ($flags) {
                foreach ($flags as $flag) {
                    @unlink($flag);
                }
            }
        }

        // 5. Flag client-side browser data wipe for all revoked tokens & user
        self::flag_browser_wipe($userid, $revoked_tokens);

        // 6. Log out user from all active sessions / browsers
        \core\session\manager::kill_user_sessions($userid);

        // 7. Log the action
        self::log_action($userid, 'system', 'reset_user_browsers', [
            'timestamp' => time(),
            'admin_user' => isset($USER) ? $USER->id : 0,
            'admin_email' => !empty($USER->email) ? $USER->email : '',
            'admin_name' => !empty($USER) ? fullname($USER) : '',
            'revoked_tokens_count' => count(array_unique($revoked_tokens)),
            'ip' => getremoteaddr()
        ]);

        return true;
    }

    /**
     * Reset browsers for a specific device - Logs out all browsers linked ONLY to this device,
     * leaving other devices and their sessions unaffected.
     * RETAINS the device record in auth_devicelock_devices and allows browsers to re-register upon next login.
     *
     * @param int $deviceid
     * @return bool
     */
    public static function reset_device_browsers($deviceid) {
        global $DB, $CFG, $USER;

        $device = $DB->get_record('auth_devicelock_devices', ['id' => $deviceid]);
        if (!$device) {
            return false;
        }

        $userid = $device->userid;
        $primary_fp = $device->device_fingerprint;
        $deviceip = $device->ip_address;

        $info = !empty($device->device_info) ? @json_decode($device->device_info, true) : [];
        if (!is_array($info)) {
            $info = [];
        }

        // Collect all tokens associated with this specific device
        $device_tokens = [$primary_fp];
        if (!empty($info['browser_tokens']) && is_array($info['browser_tokens'])) {
            $device_tokens = array_unique(array_merge($device_tokens, $info['browser_tokens']));
        }

        // Clear registered browsers on this device while retaining hardware identity and device record
        $existing_revoked = !empty($info['revoked_tokens']) && is_array($info['revoked_tokens']) ? $info['revoked_tokens'] : [];
        $info['revoked_tokens'] = array_slice(array_values(array_unique(array_merge($existing_revoked, $device_tokens))), -50);
        $info['browsers_used'] = [];
        $info['browser_tokens'] = [];

        // Decouple old browser token from device_fingerprint: reset to stable hardware hash
        $hw_hash = $info['hw_hash'] ?? ('hw_' . md5($device->id . '_' . $device->screen_resolution . '_' . $device->platform));
        // Apple device identity is server-attested, never a browser hash.
        if (!\auth_devicelock\local\ios_identity::is_apple_fingerprint($device->device_fingerprint)) {
            $device->device_fingerprint = $hw_hash;
        }
        $device->user_agent = ''; // Clear UA so fallback does not restore old browser family
        $device->device_info = json_encode($info);
        $DB->update_record('auth_devicelock_devices', $device);

        // 1. Terminate tracked sessions belonging ONLY to this device
        if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
            list($insql, $inparams) = $DB->get_in_or_equal($device_tokens, SQL_PARAMS_NAMED);
            $inparams['userid'] = $userid;
            $trackings = $DB->get_records_select('auth_devicelock_session_tracking', "userid = :userid AND device_fingerprint $insql", $inparams);
            if (!empty($trackings)) {
                foreach ($trackings as $tr) {
                    if (!empty($tr->session_id)) {
                        \core\session\manager::kill_session($tr->session_id);
                    }
                }
            }
            $DB->delete_records_select('auth_devicelock_session_tracking', "userid = :userid AND device_fingerprint $insql", $inparams);
        }

        // 2. Clear any lingering logout flags for this device
        $logoutdir = $CFG->dataroot . '/devicelock_logout_flags';
        if (is_dir($logoutdir)) {
            foreach ($device_tokens as $token) {
                $flagfile = $logoutdir . '/logout_' . $userid . '_' . md5($token) . '.flag';
                if (file_exists($flagfile)) {
                    @unlink($flagfile);
                }
            }
        }

        // 3. Flag client-side browser data wipe for revoked tokens
        self::flag_browser_wipe($userid, $device_tokens);

        // 4. Session isolation check:
        // Find other active devices for this user
        $other_devices = $DB->get_records_select('auth_devicelock_devices', 'userid = ? AND id != ? AND status = ?', [$userid, $device->id, 'active']);
        if (empty($other_devices)) {
            // No other active devices exist for this user, so any active session belongs to this device
            \core\session\manager::kill_user_sessions($userid);
        } else {
            // Other devices exist! Only kill sessions matching this device's unique IP if different from other devices
            $other_ips = array_filter(array_column($other_devices, 'ip_address'));
            if (!empty($deviceip) && !in_array($deviceip, $other_ips)) {
                $sessions = $DB->get_records('sessions', ['userid' => $userid, 'lastip' => $deviceip]);
                foreach ($sessions as $session) {
                    \core\session\manager::kill_session($session->sid);
                }
            }
        }

        // 5. Log the action
        self::log_action($userid, $primary_fp, 'reset_device_browsers', [
            'device_id' => $deviceid,
            'timestamp' => time(),
            'admin_user' => isset($USER) ? $USER->id : 0,
            'admin_email' => !empty($USER->email) ? $USER->email : '',
            'admin_name' => !empty($USER) ? fullname($USER) : '',
            'revoked_tokens' => $device_tokens,
            'ip' => getremoteaddr()
        ]);

        return true;
    }
    
    /**
     * Block a specific device - FIXED: Works exactly like reset_user_devices but for ONE device
     * This uses the same reliable method as reset_user_devices()
     * 
     * @param int $deviceid Device ID
     * @return bool Success
     */
    public static function block_specific_device($deviceid) {
        global $DB;
        
        // Get device info before deleting
        $device = $DB->get_record('auth_devicelock_devices', ['id' => $deviceid]);
        if (!$device) {
            return false;
        }
        
        $userid = $device->userid;
        $fingerprint = $device->device_fingerprint;
        $deviceip = $device->ip_address;
        $deviceuseragent = $device->user_agent;
        
        // ================================================
        // STEP 1: DELETE ONLY THE SPECIFIC DEVICE (like reset_user_devices but for one device)
        // ================================================
        $DB->delete_records('auth_devicelock_devices', ['id' => $deviceid]);
        
        // ================================================
        // STEP 2: DELETE SESSION TRACKING FOR THIS SPECIFIC DEVICE
        // ================================================
        if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
            $DB->delete_records('auth_devicelock_session_tracking', [
                'userid' => $userid,
                'device_fingerprint' => $fingerprint
            ]);
        }
        
        // ================================================
        // STEP 3: FIND AND DELETE ONLY THE SESSION FOR THIS SPECIFIC DEVICE
        // This is the key - we need to identify which session belongs to this device
        // ================================================
        
        // Method 1: Try to find session by matching IP address and user agent
        $sessions = $DB->get_records('sessions', ['userid' => $userid]);
        $sessiondeleted = false;
        
        foreach ($sessions as $session) {
            $match = false;
            
            // Match by IP address if available
            if (!empty($deviceip) && $session->lastip === $deviceip) {
                $match = true;
            }
            
            // Match by user agent if IP doesn't match
            if (!$match && !empty($deviceuseragent) && !empty($session->user_agent)) {
                // Check if user agents are similar (same browser, same OS)
                if (self::compare_user_agents($deviceuseragent, $session->user_agent)) {
                    $match = true;
                }
            }
            
            if ($match) {
                // Delete this specific session
                self::delete_specific_session($session->id, $session->sid);
                $sessiondeleted = true;
                break;
            }
        }
        
        // Method 2: If we couldn't find the session, create a logout flag for this specific device
        if (!$sessiondeleted) {
            self::create_device_logout_flag($userid, $fingerprint);
        }
        
        // ================================================
        // STEP 4: Log the action (exactly like reset_user_devices)
        // ================================================
        self::log_action($userid, $fingerprint, 'device_blocked', [
            'device_id' => $deviceid,
            'timestamp' => time(),
            'admin_user' => isset($USER) ? $USER->id : 0,
            'admin_email' => !empty($USER->email) ? $USER->email : '',
            'admin_name' => !empty($USER) ? fullname($USER) : '',
            'ip' => getremoteaddr(),
            'device_ip' => $deviceip,
            'session_terminated' => $sessiondeleted ? 'immediate' : 'via_flag'
        ]);
        
        // Notify user about device block via template email (Feature 1)
        $devicename = trim(($device->platform ?? '') . ' ' . ($device->screen_resolution ?? '')) ?: get_string('unknown', 'auth_devicelock');
        if (function_exists('auth_devicelock_send_template_email')) {
            auth_devicelock_send_template_email($userid, 'blocked', [
                'ip'         => $deviceip,
                'devicename' => $devicename,
            ]);
        }
        
        error_log("DeviceManager: Device {$deviceid} blocked successfully at " . date('Y-m-d H:i:s'));
        
        return true;
    }
    
    /**
     * Toggles a device's status between 'active' and 'blocked'.
     *
     * @param int $deviceid Device ID to toggle.
     * @return bool True on success.
     */
    public static function toggle_device_status($deviceid) {
        global $DB, $USER;
        
        $device = $DB->get_record('auth_devicelock_devices', ['id' => $deviceid]);
        if (!$device) {
            return false;
        }

        $newstatus = ($device->status === 'active') ? 'blocked' : 'active';
        $device->status = $newstatus;
        $DB->update_record('auth_devicelock_devices', $device);

        // If we are blocking the device, terminate its active session immediately.
        if ($newstatus === 'blocked') {
            $userid = $device->userid;
            $fingerprint = $device->device_fingerprint;
            $deviceip = $device->ip_address;
            $deviceuseragent = $device->user_agent;
            
            // 1. Terminate user sessions immediately in Moodle core.
            $remaining_active = $DB->count_records('auth_devicelock_devices', ['userid' => $userid, 'status' => 'active']);
            if ($remaining_active == 0) {
                \core\session\manager::kill_user_sessions($userid);
            } else {
                $sessions = $DB->get_records('sessions', ['userid' => $userid]);
                foreach ($sessions as $session) {
                    $match = false;
                    if (!empty($deviceip) && $session->lastip === $deviceip) {
                        $match = true;
                    }
                    if (!$match && !empty($deviceuseragent) && !empty($session->user_agent)) {
                        if (self::compare_user_agents($deviceuseragent, $session->user_agent)) {
                            $match = true;
                        }
                    }
                    if ($match) {
                        self::delete_specific_session($session->id, $session->sid);
                    }
                }
            }
            
            // 2. Remove session tracking
            if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
                $DB->delete_records('auth_devicelock_session_tracking', [
                    'userid' => $userid,
                    'device_fingerprint' => $fingerprint
                ]);
            }
            
            // 3. Create device logout flag on disk
            self::create_device_logout_flag($userid, $fingerprint);
            if ($remaining_active == 0) {
                self::create_device_logout_flag($userid, 'blocked_all');
            }
            
            // Set user preference to ensure notice is shown
            set_user_preference('auth_devicelock_blocked_notice', 1, $userid);
            
            // Send template email when blocking.
            if (function_exists('auth_devicelock_send_template_email')) {
                $devicename = trim(($device->platform ?? '') . ' ' . ($device->screen_resolution ?? '')) ?: get_string('unknown', 'auth_devicelock');
                auth_devicelock_send_template_email($userid, 'blocked', [
                    'ip'         => $deviceip,
                    'devicename' => $devicename,
                ]);
            }
            self::log_action($userid, $fingerprint, 'device_status_blocked', [
                'device_id' => $deviceid,
                'admin_user' => isset($USER) ? $USER->id : 0,
                'admin_email' => !empty($USER->email) ? $USER->email : '',
                'admin_name' => !empty($USER) ? fullname($USER) : ''
            ]);
        } else {
            self::log_action($device->userid, $device->device_fingerprint, 'device_status_active', [
                'device_id' => $deviceid,
                'admin_user' => isset($USER) ? $USER->id : 0,
                'admin_email' => !empty($USER->email) ? $USER->email : '',
                'admin_name' => !empty($USER) ? fullname($USER) : ''
            ]);
        }
        
        return true;
    }
    
    /**
     * Compare two user agents to see if they're from the same browser/device
     * 
     * @param string $ua1 First user agent
     * @param string $ua2 Second user agent
     * @return bool True if they match
     */
    private static function compare_user_agents($ua1, $ua2) {
        if (empty($ua1) || empty($ua2)) {
            return false;
        }
        
        // Extract browser and OS fingerprints
        $patterns = [
            '/(Chrome|Firefox|Safari|Edge|Opera|MSIE|Trident)\/[\d\.]+/',
            '/(Windows NT|Mac OS X|Linux|Android|iPhone|iPad|CPU OS)/'
        ];
        
        $fingerprint1 = '';
        $fingerprint2 = '';
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $ua1, $matches)) {
                $fingerprint1 .= $matches[0];
            }
            if (preg_match($pattern, $ua2, $matches)) {
                $fingerprint2 .= $matches[0];
            }
        }
        
        return $fingerprint1 === $fingerprint2;
    }
    
    private static function delete_specific_session($sessionid, $sidsession) {
        // Safely terminate session using Moodle core session manager API
        \core\session\manager::kill_session($sidsession);
    }
    
    /**
     * Block device (alias for block_specific_device)
     */
    public static function block_device($deviceid) {
        return self::block_specific_device($deviceid);
    }
    
    /**
     * Create a logout flag for specific device
     * This will be checked on next page load
     * 
     * @param int $userid User ID
     * @param string $fingerprint Device fingerprint
     * @return bool Success
     */
    private static function create_device_logout_flag($userid, $fingerprint) {
        global $CFG;
        
        $logoutdir = $CFG->dataroot . '/devicelock_logout_flags';
        if (!is_dir($logoutdir)) {
            @mkdir($logoutdir, 0777, true);
        }
        
        $flagfile = $logoutdir . '/logout_' . $userid . '_' . md5($fingerprint) . '.flag';
        @file_put_contents($flagfile, json_encode([
            'userid' => $userid,
            'fingerprint' => $fingerprint,
            'created' => time(),
            'expires' => time() + 86400 // 24 hours expiry
        ]));
        
        return true;
    }
    
    /**
     * Check and process device logout flags
     * 
     * @param int $userid User ID
     * @param string $fingerprint Current device fingerprint
     * @return bool True if should logout
     */
    public static function check_device_logout_flag($userid, $fingerprint) {
        global $CFG;
        
        $logoutdir = $CFG->dataroot . '/devicelock_logout_flags';
        $flagfile = $logoutdir . '/logout_' . $userid . '_' . md5($fingerprint) . '.flag';
        
        if (file_exists($flagfile)) {
            $data = @json_decode(file_get_contents($flagfile), true);
            
            // Check if expired
            if ($data && isset($data['expires']) && time() > $data['expires']) {
                @unlink($flagfile);
                return false;
            }
            
            // This device should be logged out
            @unlink($flagfile);
            return true;
        }
        
        return false;
    }
    
    /**
     * Set reset notification for user
     */
    private static function set_user_reset_notification($userid) {
        global $CFG;
        
        $resetdir = $CFG->dataroot . '/devicelock_resets';
        if (!is_dir($resetdir)) {
            @mkdir($resetdir, 0777, true);
        }
        
        $resetfile = $resetdir . '/reset_' . $userid . '.flag';
        @file_put_contents($resetfile, time());
        
        return true;
    }
    
    /**
     * Check if user has reset notification
     */
    public static function has_reset_notification($userid) {
        global $CFG;
        
        $resetdir = $CFG->dataroot . '/devicelock_resets';
        $resetfile = $resetdir . '/reset_' . $userid . '.flag';
        
        return file_exists($resetfile);
    }
    
    /**
     * Clear reset notification for user
     */
    public static function clear_reset_notification($userid) {
        global $CFG;
        
        $resetdir = $CFG->dataroot . '/devicelock_resets';
        $resetfile = $resetdir . '/reset_' . $userid . '.flag';
        
        if (file_exists($resetfile)) {
            @unlink($resetfile);
        }
        
        return true;
    }
    
    /**
     * Flag browser data wipe for a user and list of revoked tokens.
     * Instructs client browsers on next contact to wipe localStorage and cookies.
     *
     * @param int $userid
     * @param array $tokens
     * @return bool
     */
    public static function flag_browser_wipe($userid, array $tokens = []) {
        global $CFG;
        $tokens = array_unique(array_filter($tokens));
        $wipedir = $CFG->dataroot . '/devicelock_wipe_flags';
        if (!is_dir($wipedir)) {
            @mkdir($wipedir, 0777, true);
        }
        
        $wipefile = $wipedir . '/wipe_user_' . $userid . '.flag';
        $existing = file_exists($wipefile) ? @json_decode(file_get_contents($wipefile), true) : [];
        if (!is_array($existing)) {
            $existing = [];
        }
        $existing_tokens = $existing['tokens'] ?? [];
        $combined = array_unique(array_merge($existing_tokens, $tokens));
        @file_put_contents($wipefile, json_encode([
            'userid' => $userid,
            'time' => time(),
            'tokens' => $combined,
            'expires' => time() + (86400 * 7) // Keep active for 7 days
        ]));
        
        // Also register per-token revocation flags for instantaneous lookup
        foreach ($tokens as $token) {
            if (!empty($token) && strlen($token) >= 8) {
                $tokenfile = $wipedir . '/revoked_' . md5($token) . '.flag';
                @file_put_contents($tokenfile, json_encode([
                    'token' => $token,
                    'userid' => $userid,
                    'time' => time(),
                    'expires' => time() + (86400 * 7)
                ]));
            }
        }
        
        set_user_preference('auth_devicelock_wipe_browsers', time(), $userid);
        return true;
    }

    /**
     * Check if a specific browser token was revoked in a browser reset action.
     *
     * @param string $token
     * @return bool True if revoked
     */
    public static function is_token_revoked($token) {
        global $CFG, $DB;
        if (empty($token) || strlen($token) < 8) {
            return false;
        }
        $wipedir = $CFG->dataroot . '/devicelock_wipe_flags';
        $tokenfile = $wipedir . '/revoked_' . md5($token) . '.flag';
        if (file_exists($tokenfile)) {
            $data = @json_decode(file_get_contents($tokenfile), true);
            if ($data && isset($data['expires']) && time() > $data['expires']) {
                @unlink($tokenfile);
                return false;
            }
            return true;
        }
        // Database check fallback: ensure revoked tokens are recognized even if disk files are wiped
        if (!empty($DB) && $DB->get_manager()->table_exists('auth_devicelock_devices')) {
            $clean_token = clean_param($token, PARAM_ALPHANUMEXT);
            if (!empty($clean_token)) {
                $sql = "SELECT id FROM {auth_devicelock_devices} WHERE " . $DB->sql_like('device_info', ':tokpattern');
                if ($DB->record_exists_sql($sql, ['tokpattern' => '%"revoked_tokens"%' . $clean_token . '%'])) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check if a user or browser token has a pending client-side wipe order.
     *
     * @param int $userid
     * @param string $token
     * @return bool
     */
    public static function has_browser_wipe_flag($userid, $token = '') {
        global $CFG;
        if (!empty($token) && self::is_token_revoked($token)) {
            return true;
        }
        if (!empty($userid)) {
            if (get_user_preferences('auth_devicelock_wipe_browsers', 0, $userid)) {
                return true;
            }
            $wipedir = $CFG->dataroot . '/devicelock_wipe_flags';
            $wipefile = $wipedir . '/wipe_user_' . $userid . '.flag';
            if (file_exists($wipefile)) {
                $data = @json_decode(file_get_contents($wipefile), true);
                if ($data && isset($data['expires']) && time() > $data['expires']) {
                    @unlink($wipefile);
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Clear the client browser wipe flag once browser data has been wiped.
     *
     * @param int $userid
     * @param string $token
     * @return bool
     */
    public static function clear_browser_wipe_flag($userid, $token = '') {
        global $CFG;
        $wipedir = $CFG->dataroot . '/devicelock_wipe_flags';
        if (!empty($token)) {
            $tokenfile = $wipedir . '/revoked_' . md5($token) . '.flag';
            if (file_exists($tokenfile)) {
                @unlink($tokenfile);
            }
        }
        if (!empty($userid)) {
            unset_user_preference('auth_devicelock_wipe_browsers', $userid);
            $wipefile = $wipedir . '/wipe_user_' . $userid . '.flag';
            if (file_exists($wipefile)) {
                @unlink($wipefile);
            }
        }
        return true;
    }

    /**
     * Automatically delete old log records using dual retention.
     *
     * Security events (any action NOT starting with "activity") are pruned after
     * $max_age_seconds (default: 3 weeks = 21 days = 1,814,400 seconds).
     *
     * User-activity events (v3.6.0, action starting with "activity") follow their
     * own retention: the 'activitylog_retention' setting in days (default 30;
     * 0 = keep activity events forever).
     *
     * @param int $max_age_seconds Default: 1814400 (3 weeks)
     * @return int Number of deleted log rows
     */
    public static function cleanup_old_logs($max_age_seconds = 1814400) {
        global $DB;

        if (!$DB->get_manager()->table_exists('auth_devicelock_logs')) {
            return 0;
        }

        $cutoff = time() - (int)$max_age_seconds;
        $deleted = 0;

        try {
            // Security events: prune every non-activity action older than the cutoff.
            $notactlike = $DB->sql_like('action', ':lgcl_notact', true, true, true);
            $deleted = $DB->count_records_select('auth_devicelock_logs',
                $notactlike . ' AND timestamp < :lgcl_cut', ['lgcl_cut' => $cutoff, 'lgcl_notact' => 'activity%']);
            if ($deleted > 0) {
                $DB->delete_records_select('auth_devicelock_logs',
                    $notactlike . ' AND timestamp < :lgcl_cut', ['lgcl_cut' => $cutoff, 'lgcl_notact' => 'activity%']);
            }

            // Activity events (v3.6.0): separate retention; 0 days = keep forever.
            $activitydays = get_config('auth_devicelock', 'activitylog_retention');
            if ($activitydays === false || $activitydays === '') {
                // Setting was never saved: use the default 30-day retention.
                $activitydays = 30;
            }
            $activitydays = (int)$activitydays;
            if ($activitydays > 0) {
                $activitycutoff = time() - ($activitydays * 86400);
                $actlike = $DB->sql_like('action', ':lgcl_act', true, true, false);
                $actdeleted = $DB->count_records_select('auth_devicelock_logs',
                    $actlike . ' AND timestamp < :lgcl_actcut', ['lgcl_actcut' => $activitycutoff, 'lgcl_act' => 'activity%']);
                if ($actdeleted > 0) {
                    $DB->delete_records_select('auth_devicelock_logs',
                        $actlike . ' AND timestamp < :lgcl_actcut', ['lgcl_actcut' => $activitycutoff, 'lgcl_act' => 'activity%']);
                    $deleted += $actdeleted;
                }
            }
        } catch (\Exception $e) {
            debugging('Error cleaning up auth_devicelock logs: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }

        // Clean up stale flag files on disk (older than 24 hours)
        self::cleanup_flag_files();

        return $deleted;
    }

    /**
     * Clean up expired flag files from dataroot to keep filesystem tidy.
     */
    public static function cleanup_flag_files() {
        global $CFG;

        $dirs = [
            $CFG->dataroot . '/devicelock_logout_flags',
            $CFG->dataroot . '/devicelock_resets',
            $CFG->dataroot . '/devicelock_wipe_flags'
        ];

        $now = time();
        foreach ($dirs as $dir) {
            if (is_dir($dir)) {
                $files = glob($dir . '/*.flag');
                if ($files) {
                    foreach ($files as $file) {
                        if (is_file($file)) {
                            // If file is older than 7 days, remove it
                            if (($now - filemtime($file)) > (86400 * 7)) {
                                @unlink($file);
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Check if device is allowed
     */
    public static function is_device_allowed($userid, $fingerprint) {
        global $DB;
        
        if (!get_config('auth_devicelock', 'enabled')) {
            return true;
        }
        
        // FIRST: Check if this device has a logout flag
        if (self::check_device_logout_flag($userid, $fingerprint)) {
            return false;
        }
        
        // THEN: Check if device exists in database
        $device = $DB->get_record('auth_devicelock_devices', [
            'userid' => $userid,
            'device_fingerprint' => $fingerprint
        ]);
        
        if (!$device) {
            return false;
        }
        
        // Check if device is active
        if ($device->status !== 'active') {
            return false;
        }
        
        return true;
    }
    
    /**
     * Register a new device
     */
    public static function register_device($userid, $fingerprint, $deviceinfo = []) {
        global $DB;
        require_once(__DIR__ . '/classes/local/ios_identity.php');
        if (\auth_devicelock\local\ios_identity::is_apple_fingerprint($fingerprint)) {
            $verified = \auth_devicelock\local\ios_identity::session();
            if (!$verified || !\auth_devicelock\local\ios_identity::permits_user($verified, (int)$userid) || !hash_equals($verified['fingerprint'], $fingerprint)) { return false; }
        }
        // Serialize the count-and-insert invariant for all clients of one account.
        $lock = \core\lock\lock_config::get_lock_factory('auth_devicelock_registration')
            ->get_lock('user_' . (int)$userid, 10);
        if (!$lock) { return false; }
        try {
            
            // 1. Check if device matches an existing device record via multi-factor matching
            if (function_exists('auth_devicelock_find_device_for_user')) {
                $matched = auth_devicelock_find_device_for_user($userid);
                if ($matched) {
                    if ($matched->status !== 'active' || !empty($matched->browser_limit_exceeded)) {
                        return false;
                    }
                    return $matched->id;
                }
            }
            
            // Check if device already exists by exact fingerprint
            $existing = $DB->get_record('auth_devicelock_devices', [
                'userid' => $userid,
                'device_fingerprint' => $fingerprint
            ]);
            
            if ($existing) {
                // Check if existing device is blocked
                if ($existing->status !== 'active') {
                    return false;
                }
                
                $existing->last_login = time();
                $existing->user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
                $existing->ip_address = getremoteaddr();
                $DB->update_record('auth_devicelock_devices', $existing);
                
                self::log_action($userid, $fingerprint, 'device_login', [
                    'device_id' => $existing->id,
                    'timestamp' => time(),
                    'ip' => getremoteaddr(),
                    'platform' => $deviceinfo['platform'] ?? ($existing->platform ?? 'unknown'),
                    'screen_resolution' => $deviceinfo['screen_resolution'] ?? ($existing->screen_resolution ?? 'unknown'),
                    'browser_language' => $deviceinfo['browser_language'] ?? ($existing->browser_language ?? 'unknown'),
                    'gpu' => $deviceinfo['gpu'] ?? 'unknown',
                    'cpu_cores' => $deviceinfo['cpu_cores'] ?? 'unknown'
                ]);
                
                return $existing->id;
            }
            
            $maxdevices = auth_devicelock_get_user_device_limit($userid);
            $currentcount = $DB->count_records('auth_devicelock_devices', [
                'userid' => $userid,
                'status' => 'active'
            ]);
            
            if ($currentcount == 0 && $maxdevices > 0) {
                // Allow first device - unless the limit is 0, which deliberately
                // means no device should ever be allowed.
            } elseif ($currentcount >= $maxdevices) {
                self::log_action($userid, $fingerprint, 'device_limit_reached', [
                    'current_count' => $currentcount,
                    'max_allowed' => $maxdevices,
                    'timestamp' => time(),
                    'ip' => getremoteaddr()
                ]);
                return false;
            }
            
            $device = new stdClass();
            $device->userid = $userid;
            $device->device_fingerprint = $fingerprint;
            $device->device_info = json_encode($deviceinfo);
            $device->status = 'active';
            $device->last_login = time();
            $device->created_at = time();
            $device->user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $device->screen_resolution = $deviceinfo['screen_resolution'] ?? '';
            $device->platform = $deviceinfo['platform'] ?? '';
            $device->browser_language = $deviceinfo['browser_language'] ?? '';
            $device->ip_address = getremoteaddr();
            
            try {
                $deviceid = $DB->insert_record('auth_devicelock_devices', $device);
            } catch (\dml_write_exception $e) {
                // Concurrent registration race condition safety: fetch existing record if already inserted
                $existing = $DB->get_record('auth_devicelock_devices', [
                    'userid' => $userid,
                    'device_fingerprint' => $fingerprint
                ]);
                if ($existing) {
                    return $existing->id;
                }
                throw $e;
            }
            
            if ($deviceid) {

                self::log_action($userid, $fingerprint, 'device_registered', [
                    'device_id' => $deviceid,
                    'is_first' => ($currentcount == 0),
                    'total_devices' => $currentcount + 1,
                    'timestamp' => time(),
                    'ip' => getremoteaddr(),
                    'platform' => $deviceinfo['platform'] ?? 'unknown',
                    'screen_resolution' => $deviceinfo['screen_resolution'] ?? 'unknown',
                    'browser_language' => $deviceinfo['browser_language'] ?? 'unknown',
                    'gpu' => $deviceinfo['gpu'] ?? 'unknown',
                    'cpu_cores' => $deviceinfo['cpu_cores'] ?? 'unknown'
                ]);
                
                // Notify user about new registered device
                if (function_exists('auth_devicelock_send_security_alert')) {
                    auth_devicelock_send_security_alert($userid, 'new_login', $deviceinfo);
                }
            }
            
            return $deviceid;
        } finally {
            $lock->release();
        }
    }
    
    /**
     * Get all devices for user
     * MODIFIED: Sorted chronologically by registration (created_at ASC) as requested
     */
    public static function get_user_devices($userid) {
        global $DB;
        return $DB->get_records('auth_devicelock_devices', ['userid' => $userid], 'id ASC');
    }
    
    /**
     * Get active device count for a user
     */
    public static function get_active_device_count($userid) {
        global $DB;
        return $DB->count_records('auth_devicelock_devices', [
            'userid' => $userid,
            'status' => 'active'
        ]);
    }
    
    /**
     * Get total active devices count (all users)
     */
    public static function get_total_active_devices() {
        global $DB;
        return $DB->count_records('auth_devicelock_devices', ['status' => 'active']);
    }
    
    /**
     * Log action for auditing
     */
    public static function log_action($userid, $fingerprint, $action, $details = []) {
        global $DB, $USER;
        
        if (!$DB->get_manager()->table_exists('auth_devicelock_logs')) {
            return false;
        }

        if (!is_array($details)) {
            $details = (array)$details;
        }

        // Automatic log cleanup: delete logs older than 3 weeks (21 days) opportunistically once per day
        $last_cleanup = get_config('auth_devicelock', 'last_log_cleanup');
        if (empty($last_cleanup) || (time() - (int)$last_cleanup) > 86400) {
            self::cleanup_old_logs(21 * 24 * 3600);
            set_config('last_log_cleanup', time(), 'auth_devicelock');
        }

        // Automatically capture admin email and ID if an admin/privileged user is performing this action
        if (!empty($USER) && !empty($USER->id)) {
            $is_admin = is_siteadmin($USER);
            if (!$is_admin && class_exists('context_system')) {
                $is_admin = has_capability('auth/devicelock:managedevices', \context_system::instance(), $USER);
            }
            if ($is_admin || ($USER->id != $userid && !empty($USER->email))) {
                if (empty($details['admin_email']) && !empty($USER->email)) {
                    $details['admin_email'] = $USER->email;
                }
                if (empty($details['admin_user'])) {
                    $details['admin_user'] = $USER->id;
                }
                if (empty($details['admin_name'])) {
                    $details['admin_name'] = fullname($USER);
                }
                // v3.9.0: also record the admin's username so the log row
                // identifies the acting admin by name, email AND username
                // (the bare numeric admin_user id confused admins - 'what
                // does Admin User: 2 even mean?').
                if (empty($details['admin_username']) && !empty($USER->username)) {
                    $details['admin_username'] = $USER->username;
                }
            }
        }
        
        $log = new stdClass();
        $log->userid = $userid;
        $log->device_fingerprint = $fingerprint;
        $log->action = $action;
        $log->ip_address = getremoteaddr();
        $log->user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $log->timestamp = time();
        $log->details = json_encode($details);
        
        $logid = $DB->insert_record('auth_devicelock_logs', $log);
        
        // v3.5.0: persistent security score - a logged violation lowers
        // the user's stored score (and can trigger the auto-ban threshold).
        // lib.php is required here (not at file top) so device_manager.php
        // can still be loaded standalone; require_once makes it a no-op
        // when lib.php is already loaded.
        if ($logid) {
            require_once(__DIR__ . '/lib.php');
            auth_devicelock_score_apply_violation($userid, $action, $details, $logid);
        }
        return $logid;
    }
    
    /**
     * Get users with devices
     */
    public static function get_users_with_devices($search = '', $limit = 0, $offset = 0) {
        global $DB;
        
        $params = [];
        $sql = "SELECT u.id, u.email, u.firstname, u.lastname, u.username,
                       COUNT(DISTINCT d.id) as device_count
                FROM {user} u
                LEFT JOIN {auth_devicelock_devices} d ON u.id = d.userid AND d.status = 'active'
                WHERE u.deleted = 0 AND u.suspended = 0";
        
        if ($search) {
            $sql .= " AND (u.email LIKE ? OR u.firstname LIKE ? OR u.lastname LIKE ? OR u.username LIKE ?)";
            $searchterm = "%$search%";
            $params = array_fill(0, 4, $searchterm);
        }
        
        $sql .= " GROUP BY u.id, u.email, u.firstname, u.lastname, u.username
                  ORDER BY u.lastname, u.firstname";
        
        if ($limit > 0) {
            return $DB->get_records_sql($sql, $params, $offset, $limit);
        }
        
        return $DB->get_records_sql($sql, $params);
    }

    
    /**
     * Count users with devices
     */
    public static function count_users_with_devices($search = '') {
        global $DB;
        
        $params = [];
        $sql = "SELECT COUNT(DISTINCT u.id)
                FROM {user} u
                WHERE u.deleted = 0 AND u.suspended = 0";
        
        if ($search) {
            $sql .= " AND (u.email LIKE ? OR u.firstname LIKE ? OR u.lastname LIKE ? OR u.username LIKE ?)";
            $searchterm = "%$search%";
            $params = array_fill(0, 4, $searchterm);
        }
        
        return $DB->count_records_sql($sql, $params);
    }
    
    /**
     * Get device by ID
     */
    public static function get_device($deviceid) {
        global $DB;
        return $DB->get_record('auth_devicelock_devices', ['id' => $deviceid]);
    }
    
    /**
     * Get device by fingerprint
     */
    public static function get_device_by_fingerprint($userid, $fingerprint) {
        global $DB;
        return $DB->get_record('auth_devicelock_devices', [
            'userid' => $userid,
            'device_fingerprint' => $fingerprint
        ]);
    }
    
    /**
     * Get GMT+2 time
     */
    public static function get_gmt2_time() {
        return time() + (2 * 3600);
    }
    
    /**
     * Format date in GMT+2
     */
    public static function format_gmt2_date($timestamp, $format = 'd M Y, H:i:s') {
        $gmt2_timestamp = $timestamp + (2 * 3600);
        return date($format, $gmt2_timestamp);
    }
    
    /**
     * Block all devices for a user
     */
    public static function block_user($userid) {
        return self::reset_user_devices($userid);
    }
    
    /**
     * Reset ALL devices for ALL users
     */
    public static function reset_all_users_devices() {
        global $DB, $CFG, $USER;
        
        $DB->delete_records('auth_devicelock_devices', []);
        $DB->delete_records('sessions', []);
        if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
            $DB->delete_records('auth_devicelock_session_tracking', []);
        }
        purge_all_caches();
        
        $sessionpath = session_save_path();
        if (empty($sessionpath) || $sessionpath == '') {
            $sessionpath = $CFG->dataroot . '/sessions';
        }
        
        if (is_dir($sessionpath)) {
            $files = glob($sessionpath . '/sess_*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    @unlink($file);
                }
            }
        }
        
        self::log_action(0, 'system', 'reset_all_users_devices', [
            'timestamp' => time(),
            'admin_user' => isset($USER) ? $USER->id : 0,
            'admin_email' => !empty($USER->email) ? $USER->email : '',
            'admin_name' => !empty($USER) ? fullname($USER) : '',
            'ip' => getremoteaddr()
        ]);
        
        return true;
    }
    
    private static function force_logout_user($userid) {
        global $DB;
        
        // 1. Delete session tracking
        if ($DB->get_manager()->table_exists('auth_devicelock_session_tracking')) {
            $DB->delete_records('auth_devicelock_session_tracking', ['userid' => $userid]);
        }
        
        // 2. Safely kill all active user sessions via core API
        \core\session\manager::kill_user_sessions($userid);
    }
}