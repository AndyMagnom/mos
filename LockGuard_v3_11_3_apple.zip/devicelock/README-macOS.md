# Native macOS Xcode 26.2 identity — plugin 3.11.3

The current Mac app uses automatic P-256 device-key enrollment. Mac App Attest
and administrator-approved enrollment are excluded from this client workflow.
iOS App Attest/DeviceCheck remains separate. No Apple server private key is
needed for automatic Mac enrollment.

Install `LockGuard_v3_11_3_apple.zip`, back up the database/config first and perform
Moodle's normal upgrade. The plugin is beta until real Moodle/native integration
passes. Version 2026101408 invalidates existing native bearer/challenge sessions.
Previously stored device keys/registrations remain; no UUID-based auto-merge is
performed. Restore database/plugin backups together for a rollback.

In Site administration → Lock Guard → Settings → Native macOS app, enable
**Enable native macOS app** and leave **Minimum macOS app build** at 2.
No CLI, config.php edit, or per-macOS-version approval is needed. Saved UI settings
supersede historical Mac config.php values. Install plugin 3.11.3 and rebuild the
Mac client together: the old client expects an exact OS allowlist.

Keep normal device/app-only restrictions enabled. No individual device grant,
`auth_devicelock_macos_approved_keys` map or Mac App Attest root/signing-id setup is
used by this build. The retired `mac_key_challenge` action is removed. Retired
administrator-grant sessions are rejected even if found after migration.
Historical Apple verifier support is retained in the shared backend for iOS and
older independently configured clients; it is not compiled into the Mac app.

## Protocol and trust boundary

`POST {action:"mac_device_challenge",keyID:"<base64 SHA256(P256 SPKI DER)>"}`
requires automatic Mac keys to be enabled before issuing a nonce. `verify` accepts
base64 publicKey (exact P-256 SPKI), DER ECDSA signature and the exact clientData
bytes. It checks key binding, signature, challenge/nonce/origin/platform, UUID
formats and current app-build policy. It rejects mixed Apple proof fields.

Challenges are single use, expire after two minutes, share the 120/IP/minute rate
limit and are consumed under key locks. Signature verification enrolls or renews
a key automatically. Five-minute random bearer sessions replace prior key
sessions; no reusable refresh token is used. Verified challenge issuance order prevents an
older delayed proof from retiring a newer valid bearer. Disabling automatic-key mode denies
both new proofs and outstanding sessions on their next server request.

Only Moodle's authenticated user binds the account, never a client-provided user
ID. A bound session cannot move to another account or register another account's
device. Account/device bans, suspension, registration and count limits remain.
`mac_` fingerprints are reserved against legacy-cookie/fuzzy-match impersonation.
The plugin marks this mode `apple_attested=false`.

Hardware UUID and Keychain UUID are signed claims; only their digests are stored.
The historical `appAttestKeyID` wire field contains the device-key digest in this
mode, not an Apple key ID. The public signing key defines device identity and
normally remains stable over OS updates. UUIDs never authenticate, prove app
integrity or automatically merge devices. Hardware/key loss needs administrator
recovery through existing device-registration controls, not automatic guessing.

Because the private software key resides on the Mac and there is no App Attest,
a modified client can enroll its own key, spoof metadata/OS and bypass local
checks. Server signatures establish key possession, not approved application
code. App authenticity is intentionally weaker under the user's selected policy.
Normal legacy Android/Windows authenticity limits also remain unchanged.

Privacy export/delete covers linked native key metadata for both Apple platforms.
Keys referenced by another account remain until those references are removed.
Moodle PHP/AJAX/file gates enforce current sessions and no-store headers; static
files and external CDN/media still require independent server controls. Signed
CDN delivery, DRM, encrypted offline caching and per-subresource App Attest are
not configured by this change.

New client telemetry types `external_display_detected` and `device_integrity_failed`
report local policy decisions. They do not certify capture, physical identity or
app integrity. Notification banners are local UI only. Never treat the absence
of a client report as proof that the device is clean.

## Administrator testing controls

In **Site administration → Lock Guard → Settings → SECURITY TESTING**, enable
the one-hour Mac test window, uncheck the individual PROTECTION rows to disable
them, and save. Checkboxes default ON; the master defaults OFF. Changing controls
invalidates Mac test bearers/challenges; reopen the app. Expiry restores normal
protections. Unsigned test keys cannot share a production device identity.
Moodle authentication, account ownership, suspension and strict input validation
remain enforced. Use staging only. Full switch guide: macos/SECURITY-TESTING.md.
