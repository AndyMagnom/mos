<?php
// Apple identity bootstrap is intentionally available before Moodle login.
define('AJAX_SCRIPT', true);
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/local/ios_identity.php');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405); throw new InvalidArgumentException('POST required');
    }
    if (parse_url($CFG->wwwroot, PHP_URL_SCHEME) !== 'https') {
        throw new RuntimeException('HTTPS is required');
    }
    $input = file_get_contents('php://input', false, null, 0, 65537);
    if (strlen($input) > 65536) { throw new InvalidArgumentException('Request too large'); }
    $body = json_decode($input, true, 16, JSON_THROW_ON_ERROR);
    if (!is_array($body)) { throw new InvalidArgumentException('JSON object required'); }
    if (!\auth_devicelock\local\ios_identity::bootstrap_allowed($body)) {
        throw new RuntimeException('Device protection is disabled');
    }
    if (($body['action'] ?? '') === 'policy') {
        // With a bearer, policy polling also checks its server-bound Moodle account.
        if (!empty($_SERVER['HTTP_AUTHORIZATION']) && !\auth_devicelock\local\ios_identity::session()) {
            throw new RuntimeException('Native session has expired or been revoked');
        }
        $session = !empty($_SERVER['HTTP_AUTHORIZATION']) ? \auth_devicelock\local\ios_identity::session() : null;
        $platform = $session['platform'] ?? ($body['platform'] ?? 'ios');
        if (!is_string($platform) || !in_array($platform, ['ios', 'macos'], true)) { throw new InvalidArgumentException('Invalid Apple platform'); }
        $policy = \auth_devicelock\local\ios_capture_policy::current($platform);
        if ($session) { $policy['watermark'] = 'Account ' . ($session['userid'] ?? 'pending') . ' / ' . substr($session['fingerprint'], 0, 16); }
        echo json_encode($policy, JSON_THROW_ON_ERROR);
        exit;
    }
    if (($body['action'] ?? '') === 'challenge') { \auth_devicelock\local\ios_identity::config($body['platform'] ?? 'ios'); }
    $result = match ($body['action'] ?? '') {
        'challenge' => \auth_devicelock\local\ios_identity::challenge($body['keyID'] ?? '', $body['platform'] ?? 'ios'),
        'mac_device_challenge' => \auth_devicelock\local\ios_identity::challenge($body['keyID'] ?? '', 'macos', true),
        'verify' => \auth_devicelock\local\ios_identity::verify($body),
        default => throw new InvalidArgumentException('Unknown action'),
    };
    echo json_encode($result, JSON_THROW_ON_ERROR);
} catch (Throwable $error) {
    if (http_response_code() < 400) { http_response_code(403); }
    // Never echo credentials, device signals or cryptographic inputs.
    error_log('LockGuard native device verification rejected: ' . $error->getMessage());
    echo json_encode(['error' => 'Device verification unavailable or rejected']);
}
