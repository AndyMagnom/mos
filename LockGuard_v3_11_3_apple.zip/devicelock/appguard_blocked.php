<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * App Guard - notice page shown to users whose web sign-in was blocked.
 *
 * The login observer / page hook / auth.php sign-in check redirect here
 * after terminating (or refusing) a browser sign-in for a restricted
 * user. The page needs no login - the visitor's session was just killed,
 * or never created in the first place.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$context = \core\context\system::instance();
$PAGE->set_context($context);
$PAGE->set_url('/auth/devicelock/appguard_blocked.php');
$PAGE->set_title('Sign in through the app');
$PAGE->set_heading('Sign in through the app');

// Consume the one-shot notice cookie (if present).
auth_devicelock_appguard_clear_notice_cookie();

echo $OUTPUT->header();

$message = trim((string)get_config('auth_devicelock', 'appguard_blockedmessage'));
if ($message === '') {
    $message = 'This account can only sign in through the official app. Please use the app to sign in.';
}

echo '<div class="card border-warning shadow-sm mx-auto my-4" style="max-width: 560px;">';
echo '<div class="card-body text-center p-4">';
echo '<i class="fa fa-mobile fa-3x text-warning mb-3" aria-hidden="true"></i>';
echo $OUTPUT->notification(format_text($message, FORMAT_HTML), \core\output\notification::NOTIFY_WARNING);
echo '</div></div>';

echo $OUTPUT->footer();
