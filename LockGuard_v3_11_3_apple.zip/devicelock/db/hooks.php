<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Hook registrations for Lock Guard plugin.
 *
 * before_http_headers: enforces the App Guard app-only sign-in
 * restriction on every rendered page. See
 * classes/hook/output/before_http_headers.php.
 *
 * before_http_headers (activity_logger): records the page the user
 * is currently viewing as a user-activity event. See
 * classes/hook/output/activity_logger.php.
 *
 * before_footer_html_generation (footer_beacon): appends the footer
 * script that beacons clicks on external links. See
 * classes/hook/output/footer_beacon.php.
 *
 * FORMAT NOTE: the hook manager includes this file and reads a variable
 * named $callbacks - a FLAT list of entries, each naming its hook class
 * under the 'hook' key. (A $hooks variable keyed by class name is silently
 * ignored by the hook manager - the hook would never register.)
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook' => \core\hook\after_config::class,
        'callback' => '\\auth_devicelock\\hook\\ios_request_gate::execute',
        'priority' => 100,
    ],
    [
        'hook'     => \core\hook\output\before_http_headers::class,
        'callback' => '\auth_devicelock\hook\output\before_http_headers::execute',
        'priority' => 100,
    ],
    [
        // v3.6.0: record the page the user is viewing as a user-activity
        // event. Lower priority than the App Guard enforcement above, so
        // when enforcement terminates a session the page is never logged.
        'hook'     => \core\hook\output\before_http_headers::class,
        'callback' => '\auth_devicelock\hook\output\activity_logger::execute',
        'priority' => 50,
    ],
    [
        // v3.6.0: footer script that beacons clicks on external links.
        'hook'     => \core\hook\output\before_footer_html_generation::class,
        'callback' => '\auth_devicelock\hook\output\footer_beacon::execute',
        'priority' => 100,
    ],
];
