// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Device fingerprint collection for Single Device Login plugin
 *
 * @module     auth_devicelock/fingerprint
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define(['jquery'], function($) {
    
    return {
        /**
         * Initialize fingerprint collection on login page
         */
        init: function() {
            var self = this;
            this.collectComprehensiveFingerprint();
            
            // Ensure form injection happens on DOM ready and before any form submit
            $(document).ready(function() {
                self.injectHiddenInputs();
                $('form').on('submit', function() {
                    self.injectHiddenInputs();
                });
            });
        },
        
        /**
         * Generate a 2D Canvas rendering fingerprint hash
         */
        getCanvasHash: function() {
            try {
                var canvas = document.createElement('canvas');
                canvas.width = 240;
                canvas.height = 60;
                var ctx = canvas.getContext('2d');
                if (!ctx) {
                    return 'unknown';
                }
                ctx.textBaseline = 'alphabetic';
                ctx.fillStyle = '#f60';
                ctx.fillRect(100, 1, 62, 20);
                ctx.fillStyle = '#069';
                ctx.font = '14pt Arial, sans-serif';
                ctx.fillText('DeviceLock Moodle Security', 2, 15);
                ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
                ctx.font = '18pt Arial, sans-serif';
                ctx.fillText('DeviceLock Moodle Security', 4, 17);
                var dataUrl = canvas.toDataURL();
                var hash = 0;
                for (var i = 0; i < dataUrl.length; i++) {
                    hash = ((hash << 5) - hash) + dataUrl.charCodeAt(i);
                    hash |= 0;
                }
                return ('00000000' + (hash >>> 0).toString(16)).slice(-8);
            } catch (e) {
                return 'unknown';
            }
        },

        /**
         * Generate an audio dynamics compressor fingerprint
         */
        getAudioHash: function(callback) {
            try {
                var AudioContextClass = window.OfflineAudioContext || window.webkitOfflineAudioContext;
                if (!AudioContextClass) {
                    if (callback) {
                        callback('unknown');
                    }
                    return 'unknown';
                }
                var context = new AudioContextClass(1, 44100, 44100);
                var oscillator = context.createOscillator();
                oscillator.type = 'triangle';
                oscillator.frequency.setValueAtTime(10000, context.currentTime);
                var compressor = context.createDynamicsCompressor();
                compressor.threshold.setValueAtTime(-50, context.currentTime);
                compressor.knee.setValueAtTime(40, context.currentTime);
                compressor.ratio.setValueAtTime(12, context.currentTime);
                compressor.attack.setValueAtTime(0, context.currentTime);
                compressor.release.setValueAtTime(0.25, context.currentTime);
                oscillator.connect(compressor);
                compressor.connect(context.destination);
                oscillator.start(0);
                context.startRendering();
                context.oncomplete = function(event) {
                    try {
                        var samples = event.renderedBuffer.getChannelData(0);
                        var sum = 0;
                        for (var i = 4500; i < 5000; i++) {
                            sum += Math.abs(samples[i]);
                        }
                        var hashStr = Math.round(sum * 1000000).toString(16);
                        if (callback) {
                            callback(hashStr);
                        }
                    } catch (e) {
                        if (callback) {
                            callback('unknown');
                        }
                    }
                };
            } catch (e) {
                if (callback) {
                    callback('unknown');
                }
                return 'unknown';
            }
        },

        /**
         * Generate a fresh random UUID v4
         */
        generateUUID: function() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },

        /**
         * Clear browser data and regenerate clean token when reset was triggered
         */
        wipeAndResetToken: function() {
            try {
                localStorage.removeItem('auth_devicelock_token');
                sessionStorage.clear();
            } catch (e) {}

            var past = "expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            document.cookie = "auth_devicelock_token=;" + past;
            document.cookie = "auth_devicelock_hw=;" + past;
            document.cookie = "auth_devicelock_fallback=;" + past;

            var newToken = this.generateUUID();
            try {
                localStorage.setItem('auth_devicelock_token', newToken);
            } catch (e) {}

            var d = new Date();
            d.setTime(d.getTime() + (10 * 365 * 24 * 60 * 60 * 1000));
            document.cookie = "auth_devicelock_token=" + encodeURIComponent(newToken) + ";expires=" + d.toUTCString() + ";path=/;SameSite=Lax";

            if (this.fingerprintData) {
                this.fingerprintData.auth_devicelock_token = newToken;
            }

            this.injectHiddenInputs();

            if (this.fingerprintData) {
                this.sendBundledFingerprint(this.fingerprintData);
            }
        },
        
        collectComprehensiveFingerprint: function() {
            var self = this;

            // 1. Persistent Browser Token (UUID)
            var browserToken = '';
            try {
                browserToken = localStorage.getItem('auth_devicelock_token');
            } catch (e) {
                // Ignore localStorage errors (e.g. private browsing mode)
            }
            
            if (!browserToken) {
                var cookieMatch = document.cookie.match(/(?:^|; )auth_devicelock_token=([^;]*)/);
                if (cookieMatch && cookieMatch[1]) {
                    browserToken = decodeURIComponent(cookieMatch[1]);
                } else {
                    browserToken = this.generateUUID();
                }
                try {
                    localStorage.setItem('auth_devicelock_token', browserToken);
                } catch (e) {}
            }
            
            // Ensure cookie is alive for 10 years
            var d = new Date();
            d.setTime(d.getTime() + (10 * 365 * 24 * 60 * 60 * 1000));
            document.cookie = "auth_devicelock_token=" + encodeURIComponent(browserToken) + ";expires=" + d.toUTCString() + ";path=/;SameSite=Lax";
            
            // 2. Hardware and environment attributes
            var screenInfo = 'unknown';
            var availScreen = 'unknown';
            var colorDepth = 'unknown';
            if (window.screen) {
                var sw = window.screen.width || 0;
                var sh = window.screen.height || 0;
                if (sw && sh) {
                    screenInfo = Math.min(sw, sh) + 'x' + Math.max(sw, sh);
                }
                var aw = window.screen.availWidth || 0;
                var ah = window.screen.availHeight || 0;
                if (aw && ah) {
                    availScreen = Math.min(aw, ah) + 'x' + Math.max(aw, ah);
                }
                colorDepth = window.screen.colorDepth || window.screen.pixelDepth || 'unknown';
            }
            
            var timezoneOffset = (new Date()).getTimezoneOffset();
            var tzName = 'unknown';
            try {
                if (window.Intl && Intl.DateTimeFormat) {
                    tzName = Intl.DateTimeFormat().resolvedOptions().timeZone || 'unknown';
                }
            } catch (e) {}

            var pixelRatio = window.devicePixelRatio || 1;
            var language = navigator.language || navigator.userLanguage || navigator.browserLanguage || 'unknown';
            var platform = navigator.platform || 'unknown';
            
            // WebGL GPU Renderer & Vendor
            var gpu = 'unknown';
            var gpuVendor = 'unknown';
            try {
                var canvas = document.createElement('canvas');
                var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
                if (gl) {
                    var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
                    if (debugInfo) {
                        gpu = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'unknown';
                        gpuVendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || 'unknown';
                    } else {
                        gpu = gl.getParameter(gl.RENDERER) || 'unknown';
                        gpuVendor = gl.getParameter(gl.VENDOR) || 'unknown';
                    }
                }
            } catch (e) {}

            // User-Agent Client Hints brands
            var brands = 'unknown';
            try {
                if (navigator.userAgentData && navigator.userAgentData.brands) {
                    brands = navigator.userAgentData.brands.map(function(b) {
                        return b.brand + ':' + b.version;
                    }).join('|');
                }
            } catch (e) {}

            // Canvas Hash
            var canvasHash = this.getCanvasHash();

            var concurrency = navigator.hardwareConcurrency || 'unknown';
            var memory = navigator.deviceMemory || 'unknown';
            var hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0);
            
            // 3. Compact hardware payload stored in cookie for server-side instantaneous access
            var hwPayload = {
                token: browserToken,
                screen: screenInfo,
                avail_screen: availScreen,
                depth: colorDepth,
                timezone: timezoneOffset,
                tzname: tzName,
                platform: platform,
                gpu: gpu,
                gpu_vendor: gpuVendor,
                brands: brands,
                canvas: canvasHash,
                concurrency: concurrency,
                touch: hasTouch ? '1' : '0',
                language: language
            };
            try {
                document.cookie = "auth_devicelock_hw=" + encodeURIComponent(JSON.stringify(hwPayload)) + ";expires=" + d.toUTCString() + ";path=/;SameSite=Lax";
            } catch (e) {}
            
            // Store payload on object for form injection
            this.fingerprintData = {
                auth_devicelock_token: browserToken,
                auth_devicelock_screen: screenInfo,
                auth_devicelock_avail_screen: availScreen,
                auth_devicelock_colordepth: colorDepth,
                auth_devicelock_timezone: timezoneOffset,
                auth_devicelock_tzname: tzName,
                auth_devicelock_pixelratio: pixelRatio,
                auth_devicelock_language: language,
                auth_devicelock_platform: platform,
                auth_devicelock_gpu: gpu,
                auth_devicelock_gpu_vendor: gpuVendor,
                auth_devicelock_brands: brands,
                auth_devicelock_canvas: canvasHash,
                auth_devicelock_audio: 'unknown',
                auth_devicelock_concurrency: concurrency,
                auth_devicelock_memory: memory,
                auth_devicelock_touch: hasTouch ? '1' : '0',
                auth_devicelock_cookies: navigator.cookieEnabled ? '1' : '0',
                auth_devicelock_online: navigator.onLine ? '1' : '0'
            };
            
            // 4. Inject hidden inputs into login forms
            this.injectHiddenInputs();
            
            // 5. Send single bundled AJAX request
            this.sendBundledFingerprint(this.fingerprintData);

            // Asynchronously resolve Audio hash and update if available
            this.getAudioHash(function(audioHash) {
                if (audioHash && audioHash !== 'unknown' && self.fingerprintData) {
                    self.fingerprintData.auth_devicelock_audio = audioHash;
                    self.injectHiddenInputs();
                }
            });
        },
        
        /**
         * Inject hidden form inputs into login and authentication forms
         */
        injectHiddenInputs: function() {
            if (!this.fingerprintData) {
                return;
            }
            
            var forms = $('form#login, form[action*="login"], form[action*="reset_password"], form');
            if (!forms.length) {
                return;
            }
            
            var data = this.fingerprintData;
            forms.each(function() {
                var $form = $(this);
                var action = $form.attr('action') || '';
                var isAuthForm = $form.is('#login') || 
                                action.indexOf('login') !== -1 || 
                                action.indexOf('reset_password') !== -1 ||
                                $form.find('input[type="password"]').length > 0;
                
                if (isAuthForm) {
                    for (var key in data) {
                        if (data.hasOwnProperty(key)) {
                            var $input = $form.find('input[name="' + key + '"]');
                            if ($input.length) {
                                $input.val(data[key]);
                            } else {
                                $('<input>').attr({
                                    type: 'hidden',
                                    name: key,
                                    value: data[key]
                                }).appendTo($form);
                            }
                        }
                    }
                }
            });
        },
        
        /**
         * Send single unified AJAX request to store fingerprint data in session
         */
        sendBundledFingerprint: function(data) {
            var self = this;
            $.ajax({
                url: M.cfg.wwwroot + '/auth/devicelock/ajax.php',
                method: 'POST',
                data: {
                    action: 'setfingerprint',
                    sesskey: M.cfg.sesskey || '',
                    data: JSON.stringify(data)
                },
                dataType: 'json',
                timeout: 5000
            }).done(function(res) {
                if (res && res.wipe) {
                    self.wipeAndResetToken();
                }
            }).fail(function(jqXHR, textStatus) {
                // Fallback: cookies and POST hidden fields are already in place
            });
        }
    };
});