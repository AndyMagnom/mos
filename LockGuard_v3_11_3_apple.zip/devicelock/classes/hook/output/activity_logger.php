<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Activity logging hook (v3.6.0): runs before any page's headers are
 * sent, on every rendered page, and records what the user is viewing
 * (site navigation, courses, activities, profiles, files) as
 * user-activity events in the Lock Guard log.
 *
 * All the actual logic lives in lib.php
 * (auth_devicelock_activity_log_current_page()) so this hook stays a
 * thin shim, exactly like the App Guard hook in this folder. Like the
 * sibling, this class deliberately does not "implement" the core hook
 * class - the hook manager only needs the public static method named
 * in db/hooks.php.
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\hook\output;

defined('MOODLE_INTERNAL') || die();

// Autoloading only loads THIS class - the shared activity logging
// function it calls lives in the plugin's lib.php.
require_once(dirname(__DIR__, 3) . '/lib.php');

class activity_logger {

    public static function execute(\core\hook\output\before_http_headers $hook): void {
        auth_devicelock_activity_log_current_page();
    }
}
