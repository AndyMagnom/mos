<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Scheduled task for pruning plugin logs: security events older
 * than 3 weeks, user-activity events older than the plugin's
 * activity-retention setting (activitylog_retention).
 *
 * @package    auth_devicelock
 * @copyright  2024
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace auth_devicelock\task;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../device_manager.php');

/**
 * Scheduled task class for log cleanup
 */
class cleanup_logs_task extends \core\task\scheduled_task {

    /**
     * Get task name
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_cleanup_logs', 'auth_devicelock');
    }

    /**
     * Execute the task: prunes security logs older than 3 weeks and
     * activity logs older than the activity-retention setting.
     */
    public function execute() {
        // 3 weeks = 21 days = 1,814,400 seconds
        $three_weeks_seconds = 21 * 24 * 3600;
        
        $deleted = \device_manager::cleanup_old_logs($three_weeks_seconds);
        
        // Also cleanup old session tracking
        if (class_exists('\\auth_devicelock\\session_manager')) {
            \auth_devicelock\session_manager::cleanup_old_tracking();
        }
        
        mtrace("auth_devicelock: Pruned {$deleted} log records (security events older than 3 weeks; activity events older than the activity-retention setting).");
    }
}
