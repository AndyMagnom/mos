<?php
namespace auth_devicelock\local;
require_once(__DIR__ . '/apple_cbor.php');

/** Apple validation, without accepting a client-selected trust anchor. */
final class apple_attest {
    public static function base64(string $value, int $max = 32768): string {
        $data = base64_decode($value, true);
        if ($data === false || strlen($data) > $max || base64_encode($data) !== $value) {
            throw new \RuntimeException('Invalid base64');
        }
        return $data;
    }
    public static function pem(string $der): string {
        return "-----BEGIN CERTIFICATE-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END CERTIFICATE-----\n";
    }
    private static function cert(string $pem): \OpenSSLCertificate {
        $cert = openssl_x509_read($pem);
        $info = $cert ? openssl_x509_parse($cert) : false;
        if (!$info || ($info['validFrom_time_t'] ?? PHP_INT_MAX) > time() ||
            ($info['validTo_time_t'] ?? 0) < time()) {
            throw new \RuntimeException('Invalid or expired certificate');
        }
        return $cert;
    }
    // DER node reader: only definite, minimally encoded lengths are accepted.
    private static function node(string $data, int &$offset): array {
        if ($offset + 2 > strlen($data)) { throw new \RuntimeException('Truncated DER'); }
        $tag = ord($data[$offset++]);
        $length = ord($data[$offset++]);
        if ($length & 128) {
            $count = $length & 127;
            if ($count < 1 || $count > 4 || $offset + $count > strlen($data) || ord($data[$offset]) === 0) {
                throw new \RuntimeException('Invalid DER length');
            }
            $length = 0;
            for ($i = 0; $i < $count; $i++) { $length = ($length << 8) | ord($data[$offset++]); }
            if ($length < 128) { throw new \RuntimeException('Non-minimal DER'); }
        }
        if ($length > strlen($data) - $offset) { throw new \RuntimeException('Truncated DER node'); }
        $value = substr($data, $offset, $length);
        $offset += $length;
        return [$tag, $value];
    }
    private static function children(string $data): array {
        $nodes = []; $offset = 0;
        while ($offset < strlen($data)) { $nodes[] = self::node($data, $offset); }
        return $nodes;
    }
    private static function nonceExtension(string $der, string $oidhex = '2a864886f763640802'): string {
        $offset = 0;
        [$tag, $certificate] = self::node($der, $offset);
        if ($tag !== 0x30 || $offset !== strlen($der)) { throw new \RuntimeException('Invalid certificate DER'); }
        $parts = self::children($certificate);
        if (($parts[0][0] ?? null) !== 0x30) { throw new \RuntimeException('Invalid certificate body'); }
        foreach (self::children($parts[0][1]) as [$tag, $body]) {
            if ($tag !== 0xa3) { continue; }
            $sequence = self::children($body);
            if (count($sequence) !== 1 || $sequence[0][0] !== 0x30) { throw new \RuntimeException('Invalid extensions'); }
            $found = null;
            foreach (self::children($sequence[0][1]) as [$extensiontag, $extension]) {
                if ($extensiontag !== 0x30) { throw new \RuntimeException('Invalid extension'); }
                $fields = self::children($extension);
                // 1.2.840.113635.100.8.2, Apple's App Attest nonce extension.
                if (($fields[0][0] ?? null) === 6 && $fields[0][1] === hex2bin($oidhex)) {
                    $last = $fields[count($fields) - 1];
                    if ($found !== null || $last[0] !== 4) { throw new \RuntimeException('Duplicate or invalid nonce'); }
                    $found = $last[1];
                }
            }
            if ($found !== null) { return $found; }
        }
        throw new \RuntimeException('Missing App Attest nonce');
    }
    public static function attestation(string $object, string $keyid, string $clienthash,
                                       string $appid, string $rootpem, bool $development, string $platform = 'ios', ?string $build = null): array {
        $decoded = apple_cbor::decode($object);
        if (!is_array($decoded) || ($decoded['fmt'] ?? '') !== 'apple-appattest') {
            throw new \RuntimeException('Invalid attestation format');
        }
        $chain = $decoded['attStmt']['x5c'] ?? null;
        $auth = $decoded['authData'] ?? null;
        $receipt = $decoded['attStmt']['receipt'] ?? null;
        if (!is_array($chain) || count($chain) !== 2 || !is_string($chain[0]) || !is_string($chain[1]) ||
            !is_string($auth) || strlen($auth) < 55 || !is_string($receipt) || strlen($receipt) > 16384) {
            throw new \RuntimeException('Invalid attestation structure');
        }
        $root = self::cert($rootpem);
        $intermediate = self::cert(self::pem($chain[1]));
        $leaf = self::cert(self::pem($chain[0]));
        if (openssl_x509_verify($intermediate, openssl_pkey_get_public($root)) !== 1 ||
            openssl_x509_verify($leaf, openssl_pkey_get_public($intermediate)) !== 1 ||
            strpos(openssl_x509_parse($intermediate)['extensions']['basicConstraints'] ?? '', 'CA:TRUE') === false) {
            throw new \RuntimeException('Untrusted App Attest certificate chain');
        }
        $nonce = hash('sha256', $auth . $clienthash, true);
        if (!hash_equals(hex2bin('3024a1220420') . $nonce, self::nonceExtension($chain[0]))) {
            throw new \RuntimeException('Attestation nonce mismatch');
        }
        if ($platform === 'macos') {
            $acl = self::octet(self::nonceExtension($chain[0], '2a864886f763640806'));
            $expectedacl = base64_decode('MEAMAjExMDowCQwCb2uhAwEB/zAJDAJvYaEDAQH/MAsMBG9kZWyhAwEB/zAVDARvc2duoAYMBHJzZWMwBaYDAgEB', true);
            if (!hash_equals($expectedacl, $acl)) { throw new \RuntimeException('Mac key does not require SIP and Full Security'); }
        }
        $public = openssl_pkey_get_public($leaf);
        $details = $public ? openssl_pkey_get_details($public) : false;
        if (!$details || ($details['ec']['curve_name'] ?? '') !== 'prime256v1') {
            throw new \RuntimeException('Invalid App Attest public key');
        }
        $x = str_pad($details['ec']['x'], 32, "\0", STR_PAD_LEFT);
        $y = str_pad($details['ec']['y'], 32, "\0", STR_PAD_LEFT);
        $keybytes = self::base64($keyid, 32);
        if (strlen($keybytes) !== 32 || !hash_equals($keybytes, hash('sha256', "\x04" . $x . $y, true))) {
            throw new \RuntimeException('App Attest key ID mismatch');
        }
        self::authenticator($auth, $appid);
        $aaguid = $development ? 'appattestdevelop' : 'appattest' . str_repeat("\0", 7);
        $credentialsize = unpack('n', substr($auth, 53, 2))[1];
        if (($platform !== 'macos' && (ord($auth[32]) & 0x40) === 0) || self::counter($auth) !== 0 ||
            !hash_equals($aaguid, substr($auth, 37, 16)) || $credentialsize !== 32 ||
            !hash_equals($keybytes, substr($auth, 55, 32))) {
            throw new \RuntimeException('Invalid attested credential');
        }
        $consumed = 0;
        $cose = apple_cbor::decode_prefix(substr($auth, 87), $consumed);
        $extensions = self::extensions(substr($auth, 87 + $consumed), $development, $platform, $build);
        if (!is_array($cose) || ($cose[1] ?? null) !== 2 || ($cose[3] ?? null) !== -7 ||
            ($cose[-1] ?? null) !== 1 || ($cose[-2] ?? null) !== $x || ($cose[-3] ?? null) !== $y) {
            throw new \RuntimeException('Credential public key mismatch');
        }
        return ['publickey' => $details['key'], 'receipt' => base64_encode($receipt),
            'mac_acl_verified' => $platform === 'macos', 'attested_extensions' => $extensions];
    }
    private static function octet(string $der): string {
        for ($depth = 0; $depth < 5; $depth++) {
            $offset = 0; [$tag, $value] = self::node($der, $offset);
            if ($offset !== strlen($der)) { throw new \RuntimeException('Invalid ACL DER'); }
            if ($tag === 0x04) { return $value; }
            if (($tag & 0x20) === 0) { break; }
            $der = $value;
        }
        throw new \RuntimeException('Missing ACL octet string');
    }
    private static function extensions(string $bytes, bool $development, string $platform, ?string $build): array {
        if ($bytes === '') {
            if ($platform === 'macos') { throw new \RuntimeException('Mac signed extensions required'); }
            return [];
        }
        if ((ord($bytes[0]) >> 5) !== 5) { throw new \RuntimeException('Invalid authenticator extensions'); }
        $map = apple_cbor::decode($bytes);
        $category = $map['apple_validation_category_01'] ?? null;
        if (is_string($category) && strlen($category) === 4) { $category = unpack('V', $category)[1]; }
        $allowed = $development ? [3] : ($platform === 'macos' ? [2, 4, 6] : [2, 4, 5]);
        $version = $map['apple_bundle_version_01'] ?? null;
        if (!is_int($category) || !in_array($category, $allowed, true) || !is_string($version) ||
            !preg_match('/^[0-9]{1,9}$/D', $version) || ($build !== null && $version !== $build)) {
            throw new \RuntimeException('App signing category or bundle version rejected');
        }
        return ['validation_category' => $category, 'bundle_version' => $version];
    }
    private static function authenticator(string $auth, string $appid): void {
        if (strlen($auth) < 37 || !hash_equals(hash('sha256', $appid, true), substr($auth, 0, 32))) {
            throw new \RuntimeException('Wrong App Attest app ID');
        }
    }
    private static function counter(string $auth): int { return unpack('N', substr($auth, 33, 4))[1]; }
    public static function assertion(string $object, string $clienthash, string $appid,
                                     string $publickey, int $previouscounter, bool $development = false, string $platform = 'ios', ?string $build = null): int {
        $decoded = apple_cbor::decode($object);
        $auth = $decoded['authenticatorData'] ?? null;
        $signature = $decoded['signature'] ?? null;
        if (!is_string($auth) || strlen($auth) < 37 || strlen($auth) > 4096 || !is_string($signature) || strlen($signature) > 80) {
            throw new \RuntimeException('Invalid assertion structure');
        }
        self::authenticator($auth, $appid);
        self::extensions(substr($auth, 37), $development, $platform, $build);
        $counter = self::counter($auth);
        if ($counter <= $previouscounter || openssl_verify(hash('sha256', $auth . $clienthash, true),
                $signature, $publickey, OPENSSL_ALGO_SHA256) !== 1) {
            throw new \RuntimeException('Invalid or replayed assertion');
        }
        return $counter;
    }
}
