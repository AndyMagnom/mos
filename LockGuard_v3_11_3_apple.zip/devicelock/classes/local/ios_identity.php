<?php
namespace auth_devicelock\local;
defined('MOODLE_INTERNAL') || die();
require_once(__DIR__ . '/apple_attest.php');
require_once(__DIR__ . '/ios_capture_policy.php');

/** Server-owned Apple identity and short-lived bearer sessions. */
final class ios_identity {
    public static function config(string $platform = 'ios'): array {
        global $CFG;
        if (!in_array($platform, ['ios', 'macos'], true)) { throw new \InvalidArgumentException('Invalid Apple platform'); }
        $config = $platform === 'macos' ? ($CFG->auth_devicelock_macos ?? []) : ($CFG->auth_devicelock_ios ?? []);
        foreach ($platform === 'macos' ? ['team_id', 'bundle_id', 'signing_id', 'app_attest_root_ca'] :
            ['team_id', 'bundle_id', 'devicecheck_key_id', 'devicecheck_private_key', 'app_attest_root_ca'] as $key) {
            if (empty($config[$key]) || !is_string($config[$key])) {
                throw new \RuntimeException('Apple identity is not configured');
            }
        }
        // File paths are set by the server administrator, never by HTTP callers.
        if (($platform === 'ios' && !is_readable($config['devicecheck_private_key'])) || !is_readable($config['app_attest_root_ca'])) {
            throw new \RuntimeException('Apple verification keys are unavailable');
        }
        return $config;
    }
    /** Automatic Mac key possession is explicitly weaker than Apple attestation. */
    public static function device_keys_enabled(): bool {
        global $CFG;
        $enabled = get_config('auth_devicelock', 'macos_enabled');
        if ($enabled !== false) { return (string)$enabled === '1'; }
        return ($CFG->auth_devicelock_macos_device_keys['enabled'] ?? false) === true;
    }
    /** A staging Mac bootstrap still works with the normal device/app-only guards OFF. */
    public static function bootstrap_allowed(array $body): bool {
        global $DB;
        if (get_config('auth_devicelock', 'enabled') || get_config('auth_devicelock', 'appguard_enabled')) { return true; }
        if (!macos_testing::active()) { return false; }
        if (($body['action'] ?? '') === 'mac_device_challenge') { return true; }
        if (($body['action'] ?? '') === 'policy') {
            return !empty($_SERVER['HTTP_AUTHORIZATION']) ? (self::session()['platform'] ?? '') === 'macos' :
                ($body['platform'] ?? 'ios') === 'macos';
        }
        if (($body['action'] ?? '') !== 'verify') { return false; }
        $id = $body['challengeID'] ?? '';
        if (!is_string($id) || !preg_match('/^[a-f0-9]{64}$/D', $id)) { return false; }
        $record = $DB->get_record('auth_devicelock_ios_state', ['kind' => 'challenge', 'lookuphash' => hash('sha256', $id)]);
        if (!$record || $record->expires <= time()) { return false; }
        $challenge = json_decode($record->payload, true, 16, JSON_THROW_ON_ERROR);
        return ($challenge['platform'] ?? '') === 'macos' && ($challenge['deviceKey'] ?? false) === true;
    }
    public static function permits_user(array $session, int $userid): bool {
        // Retired administrator-grant sessions cannot cross the policy migration.
        return !isset($session['approvedKeyHash']) && (empty($session['userid']) || (int)$session['userid'] === $userid);
    }
    public static function is_apple_fingerprint($value): bool {
        return is_string($value) && preg_match('/^(?:ios|mac)_/i', $value) === 1;
    }
    public static function is_request(): bool {
        return !empty($_COOKIE['MedPrepIOS']) ||
            preg_match('/(?:MedPrepIOS|MedPrepMac|MedoPrepo2121\/[^ ]+ iOS)/i', $_SERVER['HTTP_USER_AGENT'] ?? '') === 1;
    }
    private static function token(): string {
        $authorization = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        $token = preg_match('/^Bearer ([a-f0-9]{64})$/D', $authorization, $matches) ? $matches[1] : ($_COOKIE['MedPrepIOS'] ?? '');
        return is_string($token) && preg_match('/^[a-f0-9]{64}$/D', $token) ? $token : '';
    }
    public static function session(): ?array {
        global $DB;
        $token = self::token();
        if ($token === '') { return null; }
        $record = $DB->get_record('auth_devicelock_ios_state', ['kind' => 'session', 'lookuphash' => hash('sha256', $token)]);
        if (!$record || $record->expires <= time()) { return null; }
        $session = json_decode($record->payload, true, 16, JSON_THROW_ON_ERROR);
        if (isset($session['approvedKeyHash']) ||
            (isset($session['deviceKeyHash']) && !self::device_keys_enabled())) { return null; }
        if (($session['platform'] ?? 'ios') === 'macos' &&
            ($session['testingPolicy'] ?? '') !== macos_testing::stamp()) { return null; }
        if (!ios_capture_policy::allows($session['osVersion'] ?? null, $session['build'] ?? null, $session['platform'] ?? 'ios')) { return null; }
        if (!empty($session['userid'])) {
            $user = $DB->get_record('user', ['id' => $session['userid']]);
            if (!$user || !empty($user->suspended) || !empty($user->deleted)) { return null; }
            if (!empty($session['restricted']) && !(($session['platform'] ?? 'ios') === 'macos' && macos_testing::disabled('device_rules'))) {
                $device = $DB->get_record('auth_devicelock_devices',
                    ['userid' => $session['userid'], 'device_fingerprint' => $session['fingerprint']]);
                if (!$device || $device->status !== 'active' || !empty($device->browser_limit_exceeded)) { return null; }
            }
        }
        return $session;
    }
    /** Bind the native session to the Moodle-authenticated account, never a client claim. */
    public static function bind_user(int $userid, bool $restricted): bool {
        global $DB;
        $token = self::token();
        if ($token === '' || $userid < 1) { return false; }
        $hash = hash('sha256', $token);
        $lock = \core\lock\lock_config::get_lock_factory('auth_devicelock_ios')->get_lock('session_' . $hash, 5);
        if (!$lock) { return false; }
        try {
            $session = self::session();
            if (!$session || !self::permits_user($session, $userid) || (!empty($session['userid']) && $session['userid'] !== $userid)) { return false; }
            $record = $DB->get_record('auth_devicelock_ios_state', ['kind' => 'session', 'lookuphash' => $hash]);
            if (!$record || $record->expires <= time()) { return false; }
            $session['userid'] = $userid; $session['restricted'] = $restricted;
            $record->payload = json_encode($session, JSON_THROW_ON_ERROR);
            $DB->update_record('auth_devicelock_ios_state', $record);
            return true;
        } finally { $lock->release(); }
    }
    /** A capture report can invalidate only its own authenticated bearer. */
    public static function revoke_for_capture(string $type, mixed $captureactive = null): bool {
        if ($type !== 'screenshot_attempt' &&
            !($type === 'screen_recording_detected' && $captureactive === true)) { return false; }
        $token = self::token();
        if ($token === '') { return false; }
        $hash = hash('sha256', $token);
        $lock = \core\lock\lock_config::get_lock_factory('auth_devicelock_ios')->get_lock('session_' . $hash, 5);
        if (!$lock) { throw new \RuntimeException('Session revocation is busy'); }
        try {
            $session = self::session();
            if (!$session || (($session['platform'] ?? 'ios') === 'macos' && macos_testing::disabled('capture_revocation'))) { return false; }
            global $DB;
            $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'session', 'lookuphash' => $hash]);
            return true;
        } finally { $lock->release(); }
    }
    private static function insert(string $kind, string $hash, array $payload, int $expires): void {
        global $DB;
        $fingerprint = match ($kind) {
            'key' => (($payload['platform'] ?? 'ios') === 'macos' ? 'mac_' : 'ios_') . substr($hash, 0, 60),
            'challenge' => (($payload['platform'] ?? 'ios') === 'macos' ? 'mac_' : 'ios_') . substr(hash('sha256', $payload['keyID']), 0, 60),
            'session' => $payload['fingerprint'],
            default => '',
        };
        $DB->insert_record('auth_devicelock_ios_state', (object)[
            'fingerprint' => $fingerprint, 'kind' => $kind, 'lookuphash' => $hash, 'payload' => json_encode($payload, JSON_THROW_ON_ERROR),
            'created' => time(), 'expires' => $expires,
        ]);
    }
    public static function challenge(string $keyid, string $platform = 'ios', bool $devicekey = false): array {
        global $DB;
        if (!in_array($platform, ['ios', 'macos'], true)) { throw new \InvalidArgumentException('Invalid Apple platform'); }
        if (strlen(apple_attest::base64($keyid, 32)) !== 32) { throw new \InvalidArgumentException('Invalid key ID'); }
        if ($devicekey && ($platform !== 'macos' || !self::device_keys_enabled())) {
            throw new \RuntimeException('Mac automatic device keys are disabled');
        }
        $iphash = hash('sha256', getremoteaddr());
        $lock = \core\lock\lock_config::get_lock_factory('auth_devicelock_ios')->get_lock('ip_' . $iphash, 5);
        if (!$lock) { throw new \RuntimeException('Verification is busy'); }
        try {
            $DB->delete_records_select('auth_devicelock_ios_state', 'kind <> ? AND expires < ?', ['key', time()]);
            if ($DB->count_records_select('auth_devicelock_ios_state', 'kind = ? AND lookuphash = ?', ['rate', $iphash]) === 0) {
                self::insert('rate', $iphash, ['count' => 0], time() + 60);
            }
            $rate = $DB->get_record('auth_devicelock_ios_state', ['kind' => 'rate', 'lookuphash' => $iphash], '*', MUST_EXIST);
            $count = json_decode($rate->payload, true)['count'];
            if ($count >= 120 && !($platform === 'macos' && macos_testing::disabled('challenge_rate'))) { throw new \RuntimeException('Too many verification attempts'); }
            $rate->payload = json_encode(['count' => $count + 1]);
            $DB->update_record('auth_devicelock_ios_state', $rate);
            $keyhash = hash('sha256', $keyid);
            $requires = !$devicekey && !$DB->record_exists('auth_devicelock_ios_state', ['kind' => 'key', 'lookuphash' => $keyhash]);
            $id = bin2hex(random_bytes(32));
            $nonce = base64_encode(random_bytes(32));
            self::insert('challenge', hash('sha256', $id), ['nonce' => $nonce, 'keyID' => $keyid, 'requiresAttestation' => $requires, 'platform' => $platform, 'deviceKey' => $devicekey, 'testingPolicy' => $platform === 'macos' ? macos_testing::stamp() : ''],
                time() + ($platform === 'macos' && macos_testing::disabled('challenge_expiry') ? 3600 : 120));
            return ['id' => $id, 'nonce' => $nonce, 'requiresAttestation' => $requires];
        } finally { $lock->release(); }
    }
    private static function b64url(string $bytes): string { return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '='); }
    // OpenSSL produces ASN.1 ECDSA signatures; Apple's ES256 JWT requires R || S.
    private static function jwt(array $config): string {
        $header = self::b64url(json_encode(['alg' => 'ES256', 'kid' => $config['devicecheck_key_id']]));
        $claims = self::b64url(json_encode(['iss' => $config['team_id'], 'iat' => time()]));
        $private = openssl_pkey_get_private(file_get_contents($config['devicecheck_private_key']));
        $details = $private ? openssl_pkey_get_details($private) : false;
        if (!$details || ($details['ec']['curve_name'] ?? '') !== 'prime256v1' ||
            !openssl_sign($header . '.' . $claims, $signature, $private, OPENSSL_ALGO_SHA256)) {
            throw new \RuntimeException('Invalid DeviceCheck signing key');
        }
        $offset = 2;
        if (strlen($signature) > 72 || ord($signature[0]) !== 0x30 || ord($signature[1]) !== strlen($signature) - 2) {
            throw new \RuntimeException('Invalid ECDSA signature');
        }
        $raw = '';
        for ($i = 0; $i < 2; $i++) {
            if (ord($signature[$offset++]) !== 2) { throw new \RuntimeException('Invalid ECDSA integer'); }
            $length = ord($signature[$offset++]);
            if ($length < 1 || $length > 33 || $offset + $length > strlen($signature)) {
                throw new \RuntimeException('Invalid ECDSA length');
            }
            $integer = ltrim(substr($signature, $offset, $length), "\0");
            if (strlen($integer) > 32) { throw new \RuntimeException('Invalid ECDSA integer size'); }
            $raw .= str_pad($integer, 32, "\0", STR_PAD_LEFT); $offset += $length;
        }
        if ($offset !== strlen($signature)) { throw new \RuntimeException('Trailing ECDSA data'); }
        return $header . '.' . $claims . '.' . self::b64url($raw);
    }
    private static function devicecheck(array $config, string $token): array {
        global $CFG;
        require_once($CFG->libdir . '/filelib.php');
        $host = !empty($config['development']) ? 'api.development.devicecheck.apple.com' : 'api.devicecheck.apple.com';
        $jwt = self::jwt($config);
        $call = static function(string $action, array $extra = []) use ($host, $jwt, $token): array {
            $curl = new \curl();
            $curl->setHeader(['Content-Type: application/json', 'Authorization: Bearer ' . $jwt]);
            $body = json_encode(array_merge(['device_token' => $token,
                'transaction_id' => bin2hex(random_bytes(16)), 'timestamp' => (int)floor(microtime(true) * 1000)], $extra));
            $response = $curl->post('https://' . $host . '/v1/' . $action, $body,
                ['CURLOPT_TIMEOUT' => 15, 'CURLOPT_CONNECTTIMEOUT' => 5, 'CURLOPT_FOLLOWLOCATION' => false,
                 'CURLOPT_SSL_VERIFYPEER' => true, 'CURLOPT_SSL_VERIFYHOST' => 2]);
            $info = $curl->get_info();
            if ($curl->get_errno()) { throw new \RuntimeException('DeviceCheck is unavailable'); }
            return [(int)($info['http_code'] ?? 0), $response];
        };
        [$status] = $call('validate_device_token');
        if ($status !== 200) { throw new \RuntimeException('DeviceCheck rejected the token'); }
        [$status, $body] = $call('query_two_bits');
        $bits = $status === 200 ? json_decode($body, true) : null;
        // Apple reports this precise error for a device with no bit history.
        if ($status === 400 && trim($body) === 'Failed to find bit state') { $bits = ['bit0' => false, 'bit1' => false]; }
        if (!is_array($bits) || !isset($bits['bit0'], $bits['bit1']) ||
            !is_bool($bits['bit0']) || !is_bool($bits['bit1'])) {
            throw new \RuntimeException('DeviceCheck bit state is unavailable');
        }
        // Bits are vendor-wide metadata, not a device identifier. Existing team
        // conventions remain untouched; no automatic device merge or bit write.
        return $bits;
    }
    public static function verify(array $body): array {
        global $DB, $CFG, $USER;
        $id = $body['challengeID'] ?? '';
        if (!is_string($id) || !preg_match('/^[a-f0-9]{64}$/D', $id)) { throw new \InvalidArgumentException('Invalid challenge ID'); }
        $challenge = $DB->get_record('auth_devicelock_ios_state', ['kind' => 'challenge', 'lookuphash' => hash('sha256', $id)]);
        if (!$challenge || $challenge->expires <= time()) { throw new \RuntimeException('Challenge expired'); }
        $expected = json_decode($challenge->payload, true, 16, JSON_THROW_ON_ERROR);
        $platform = $expected['platform'] ?? 'ios';
        $devicekey = ($expected['deviceKey'] ?? false) === true;
        if (isset($expected['approvedKey']) && $expected['approvedKey'] === true) { throw new \RuntimeException('Retired enrollment mode'); }
        $config = $devicekey ? [] : self::config($platform);
        if ($platform === 'macos' && ($expected['testingPolicy'] ?? '') !== macos_testing::stamp()) {
            throw new \RuntimeException('Mac testing policy changed; request a fresh challenge');
        }
        $skipSignature = $devicekey && $platform === 'macos' && macos_testing::disabled('device_signature');
        $keyid = $expected['keyID'];
        // Unsigned testing identity cannot collide with a production device key.
        $keyhash = hash('sha256', ($skipSignature ? 'macos-unsigned-test:' : '') . $keyid);
        $lock = \core\lock\lock_config::get_lock_factory('auth_devicelock_ios')->get_lock('key_' . $keyhash, 10);
        if (!$lock) { throw new \RuntimeException('Verification is busy'); }
        try {
            // Recheck and consume under the same lock as the assertion counter.
            $challenge = $DB->get_record('auth_devicelock_ios_state', ['kind' => 'challenge', 'lookuphash' => hash('sha256', $id)]);
            if (!$challenge || $challenge->expires <= time()) { throw new \RuntimeException('Challenge already used'); }
            $DB->delete_records('auth_devicelock_ios_state', ['id' => $challenge->id]);
            $clientdata = apple_attest::base64($body['clientData'] ?? '', 16384);
            $claims = json_decode($clientdata, true, 16, JSON_THROW_ON_ERROR);
            $signals = $claims['signals'] ?? null;
            $site = parse_url($CFG->wwwroot);
            if (($site['scheme'] ?? '') !== 'https' || empty($site['host'])) {
                throw new \RuntimeException('Invalid server HTTPS origin');
            }
            $expectedorigin = 'https://' . strtolower($site['host']);
            if (($site['port'] ?? 443) !== 443) { $expectedorigin .= ':' . $site['port']; }
            if (($claims['origin'] ?? '') !== $expectedorigin || (($signals['platform'] ?? 'ios') !== $platform) || !is_array($signals) || ($claims['challengeID'] ?? '') !== $id ||
                ($claims['nonce'] ?? '') !== $expected['nonce'] || ($signals['appAttestKeyID'] ?? '') !== $keyid ||
                !is_string($signals['keychainUUID'] ?? null) ||
                !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD', $signals['keychainUUID']) ||
                (isset($signals['idfv']) && (!is_string($signals['idfv']) || !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD', $signals['idfv']))) ||
                (isset($signals['hardwareUUID']) && ($platform !== 'macos' || !is_string($signals['hardwareUUID']) ||
                    !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD', $signals['hardwareUUID']))) ||
                !is_string($signals['deviceCheckToken'] ?? null) || strlen($signals['deviceCheckToken']) > 8192) {
                throw new \RuntimeException('Device claims do not match the challenge');
            }
            ios_capture_policy::require_allowed($signals['osVersion'] ?? null, $signals['build'] ?? null, $platform);
            if ($platform === 'ios') { apple_attest::base64($signals['deviceCheckToken'], 6144); }
            $hash = hash('sha256', $clientdata, true);
            $record = $DB->get_record('auth_devicelock_ios_state', ['kind' => 'key', 'lookuphash' => $keyhash]);
            if ($devicekey) {
                $der = apple_attest::base64($body['publicKey'] ?? '', 256);
                $enrollmenthash = hash('sha256', $der);
                if ($platform !== 'macos' || !hash_equals(base64_encode(hash('sha256', $der, true)), $keyid) ||
                    !self::device_keys_enabled() || !empty($body['attestation']) || !empty($body['assertion'])) {
                    throw new \RuntimeException('Device key does not match challenge');
                }
                // Exactly the standard P-256 SPKI encoding; no RSA, explicit curves or trailing bytes.
                $prefix = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200');
                if (strlen($der) !== 91 || !hash_equals($prefix, substr($der, 0, 26)) || ord($der[26]) !== 4) {
                    throw new \RuntimeException('Invalid P-256 public key');
                }
                $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
                if (openssl_pkey_get_public($pem) === false) { throw new \RuntimeException('Invalid P-256 public key'); }
                if (!$skipSignature && openssl_verify($clientdata, apple_attest::base64($body['signature'] ?? '', 80), $pem, OPENSSL_ALGO_SHA256) !== 1) {
                    throw new \RuntimeException('Invalid enrolled device signature');
                }
                // Only verified proofs advance issuance order. An unsigned challenge
                // flood cannot retire a valid bearer; a delayed old proof cannot
                // replace the session issued by a newer valid challenge.
                $previous = $record ? json_decode($record->payload, true, 16, JSON_THROW_ON_ERROR) : [];
                if ((int)$challenge->id <= (int)($previous['lastverifiedchallengeid'] ?? 0)) {
                    throw new \RuntimeException('A newer device proof has already been verified');
                }
                $verified = ['platform' => 'macos', 'deviceKeyHash' => $enrollmenthash, 'publickey' => $pem,
                    'lastverifiedchallengeid' => (int)$challenge->id, 'apple_attested' => false, 'proof_verified' => !$skipSignature];
            } else {
            $appid = $config['team_id'] . '.' . ($platform === 'macos' ? $config['signing_id'] : $config['bundle_id']);
            if (!$record) {
                if (!$expected['requiresAttestation'] || empty($body['attestation']) || !empty($body['assertion'])) {
                    throw new \RuntimeException('Attestation required');
                }
                $verified = apple_attest::attestation(apple_attest::base64($body['attestation']), $keyid, $hash,
                    $appid, file_get_contents($config['app_attest_root_ca']), !empty($config['development']), $platform, (string)$signals['build']);
                $verified['platform'] = $platform;
                $verified['counter'] = 0;
                $verified['appid'] = $appid;
                $verified['development'] = !empty($config['development']);
            } else {
                if ($expected['requiresAttestation'] || empty($body['assertion']) || !empty($body['attestation'])) {
                    throw new \RuntimeException('Assertion required');
                }
                $verified = json_decode($record->payload, true, 16, JSON_THROW_ON_ERROR);
                if (($platform === 'macos' && ($verified['mac_acl_verified'] ?? false) !== true) || ($verified['platform'] ?? 'ios') !== $platform || ($verified['appid'] ?? '') !== $appid ||
                    ($verified['development'] ?? null) !== !empty($config['development'])) {
                    throw new \RuntimeException('Stored App Attest environment does not match this server');
                }
                $verified['counter'] = apple_attest::assertion(apple_attest::base64($body['assertion']), $hash,
                    $appid, $verified['publickey'], (int)$verified['counter'], !empty($config['development']), $platform, (string)$signals['build']);
                // Corroborating UUID/IDFV metadata may rotate. Only the verified
                // hardware-backed key controls the canonical device identity.
            }
            }
            $verified['devicecheck'] = $platform === 'ios' ? self::devicecheck($config, $signals['deviceCheckToken']) : null;
            $verified['lastverified'] = time();
            $verified['hardwareuuidhash'] = isset($signals['hardwareUUID']) ? hash('sha256', strtolower($signals['hardwareUUID'])) : null;
            $verified['uuidhash'] = hash('sha256', $signals['keychainUUID']);
            $verified['idfvhash'] = isset($signals['idfv']) ? hash('sha256', $signals['idfv']) : null;
            // UUID and IDFV are corroborating claims, NEVER automatic merge keys.
            $fingerprint = ($platform === 'macos' ? 'mac_' : 'ios_') . substr($keyhash, 0, 60);
            $sessionclaims = ['platform' => $platform, 'fingerprint' => $fingerprint, 'keyhash' => $keyhash,
                'osVersion' => $signals['osVersion'], 'build' => $signals['build']];
            if ($platform === 'macos') { $sessionclaims['testingPolicy'] = macos_testing::stamp(); }
            if ($devicekey) { $sessionclaims['deviceKeyHash'] = $enrollmenthash; }
            // These values come from Moodle's authenticated cookie, not Apple client JSON.
            if (!empty($USER->id) && !isguestuser()) {
                require_once(__DIR__ . '/../../auth.php');
                $restricted = \auth_plugin_devicelock::should_restrict_user_static($USER);
                if (!self::permits_user($sessionclaims, (int)$USER->id)) { throw new \RuntimeException('Native session belongs to another account'); }
                if (!empty($USER->suspended) || !empty($USER->deleted)) {
                    throw new \RuntimeException('Moodle account is unavailable');
                }
                if ($restricted && !($platform === 'macos' && macos_testing::disabled('device_rules'))) {
                    $device = $DB->get_record('auth_devicelock_devices',
                        ['userid' => $USER->id, 'device_fingerprint' => $fingerprint]);
                    if (!$device || $device->status !== 'active' || !empty($device->browser_limit_exceeded)) {
                        throw new \RuntimeException('Moodle device registration is unavailable');
                    }
                }
                $sessionclaims['userid'] = (int)$USER->id; $sessionclaims['restricted'] = $restricted;
            }
            $transaction = $DB->start_delegated_transaction();
            if ($record) {
                $record->payload = json_encode($verified, JSON_THROW_ON_ERROR);
                $DB->update_record('auth_devicelock_ios_state', $record);
            } else { self::insert('key', $keyhash, $verified, 0); }
            // A full fresh Apple proof replaces the previous short-lived bearer.
            // There is no reusable refresh token. Retired bearers cannot renew.
            $DB->delete_records('auth_devicelock_ios_state', ['kind' => 'session', 'fingerprint' => $fingerprint]);
            $token = bin2hex(random_bytes(32));
            self::insert('session', hash('sha256', $token), $sessionclaims,
                time() + ($platform === 'macos' && macos_testing::disabled('session_expiry') ? 3600 : 300));
            $transaction->allow_commit();
            return ['sessionToken' => $token, 'capturePolicy' => ios_capture_policy::current($platform)];
        } finally { $lock->release(); }
    }
}
